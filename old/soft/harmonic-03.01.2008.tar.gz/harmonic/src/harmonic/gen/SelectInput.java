/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.gen;

import org.w3c.dom.*;
import java.util.*;

public class SelectInput extends Input
{
    public class Option implements Generator
    {
	String m_text = null;
	String m_value = null;
	boolean m_selected = false;
	
	Option() {}

	Option(String value) {
	    m_value = value;
	}

	Option(String value, boolean selected) {
	    m_value = value;
	    m_selected = selected;
	}

	public void setText(String text) {
	    m_text = text;
	}
	
	public Node generate(Document doc)
	{
	    Element el = doc.createElement("option");
	    
	    if (m_value != null)
		el.setAttribute("value", m_value);
	    if (m_selected)
		el.setAttribute("selected", "selected");
	    if (m_text != null)
		el.appendChild(doc.createTextNode(m_text));

	    return el;
	}
    }

    List<Option> m_opts = new LinkedList<Option>();

    public SelectInput() {}

    public SelectInput(String name) {
	super.setName(name);
    }
    
    public Option addOption(String value) {
	Option op = new Option(value); 
	m_opts.add(op);
	return op;
    }

    public Option addOption(String value, boolean selected) {
	Option op = new Option(value, selected);
	m_opts.add(op);
	return op;
    }

    public Option addOption() {
	Option op = new Option();
	m_opts.add(op);
	return op;
    }
    
    public Node generate(Document doc)
    {
	Element el = doc.createElement("select");
	fillInputAttributes(el);

	Iterator it = m_opts.iterator();
	while(it.hasNext())
	    el.appendChild(((Option)it.next()).generate(doc));
	
	return el;
    }
}
