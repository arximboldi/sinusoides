/*
   Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
  
   This file is part of MemberManager.
  
   MemberManager is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
  
   Django-graph is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY, without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
*/

drop table if exists mm_member;
drop table if exists mm_payment;
drop table if exists mm_control;

create table mm_control 
(
	version int
); 

create table mm_member
(
	id		int not null auto_increment,
	nif		varchar (9),
	comname		varchar (128),
	surname		varchar (128),	
	up_date		date,
	down_date	date,	
	birth_date	date,

	address		varchar (128),
	zip		varchar (128),
	city		varchar (128),
	province	varchar (128),
	phone		varchar (10),
	mobile		varchar (10),
	email		varchar (128),
	web		varchar (128),

	bank		varchar (128),
	notes   	varchar (4096),
	picture		varchar (1024),

	primary key (id)
);

create table mm_payment
(
	member_id	int references mm_member (id),
	pay_date	date,
	amount		decimal (9, 2),
	notes		varchar (512),
	
	primary key (member_id, pay_date, amount, notes)
);

insert into mm_control (version) values (1);

