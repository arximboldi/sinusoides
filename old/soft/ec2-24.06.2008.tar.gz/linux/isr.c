/*
 * Driver de sonido para Linux 2.6
 *
 * Autores:
 *   Juan Pedro Bolívar Puente
 *   Francisco Manuel Herrero Pérez
 */

#include "isr.h"

asmlinkage long
get_interrupt_gate (long n)
{
  long gate;
  __asm__ __volatile__
    (
     "subl $8, %%esp \n\t"
     "sidt (%%esp) \n\t"
     "movl 2(%%esp), %%eax \n\t"
     "addl $8, %%esp \n\t"
     "leal (%%eax,%1,8), %%ebx \n\t"
     "movl 4(%%ebx), %%eax \n\t"
     "movw (%%ebx), %%ax \n\t"
     : "=a" (gate) : "b" (n)
     );
  return gate;
}

asmlinkage void
set_interrupt_gate (long n, long addr)
{
  __asm__ __volatile__
    (
     "cli \n\t"
     "subl $8, %%esp \n\t"
     "sidt (%%esp) \n\t"
     "movl 2(%%esp), %%eax \n\t"
     "addl $8, %%esp \n\t"
     "leal (%%eax,%0,8), %%ebx \n\t"
     "movw %%cx, (%%ebx) \n\t"
     "shrl $16, %%ecx \n\t"
     "movw %%cx, 6(%%ebx) \n\t"
     "sti \n\t"         
     : /* no devuelve nada */ : "b"(n), "c" (addr) : "%eax"
     );
}
