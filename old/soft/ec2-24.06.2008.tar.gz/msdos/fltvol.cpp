
#include "fltvol.h"

void FilterVolume::process(Sample* buf, int n_samples)
{
  while (n_samples--)
    *buf++ *= m_ampl;
}
