/*
 * sdl_simple.c
 *
 * Juan Pedro Bolívar Puente
 *
 * Librería para el manejo sencillo de la SDL y SDL_ttf, orientada a usar
 * SDL desde ensamblador.
 *
 * Se pretende que el usuario utilice también la SDL y SDL_ttf, pero evitando
 * aquellas funciones que requieran de macros (sólo accesibles desde C) o
 * de estructuras complejas.
 */

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>

#define ENABLE_TTF 1

enum event_types {
  EV_UNKNOWN,
  EV_KEY_DOWN,
  EV_KEY_UP,
  EV_MOUSE_DOWN,
  EV_MOUSE_UP,
  EV_MOUSE_MOVE,
  EV_QUIT,
  NUM_EV
};

static SDL_Event    curr_event;
static SDL_Surface* screen;

void init_sdl(int w, int h, int bpp, int fullscreen);
void close_sdl();
void set_caption(char* string);
void update_screen();
void update_screen_rect(int x, int y, int w, int h);
Uint32 map_colour(int r, int g, int b);
void lock_screen();
void unlock_screen();
void blit_surface(SDL_Surface* s, int x, int y);
void* get_screen_memory();
int get_screen_pitch();
int next_event();
int wait_event();
SDL_Event* get_event();
int get_event_type();
Uint16 get_key_event_ascii();
Uint16 get_mouse_motion_x();
Uint16 get_mouse_motion_y();

void init_sdl(int w, int h, int bpp, int fullscreen)
{
  int flags;
  
  if (SDL_Init(SDL_INIT_VIDEO) < 0) {
    fprintf(stderr, "No se puede iniciar SDL: %s\n", SDL_GetError());
    exit(-1);
  }

  flags = SDL_SWSURFACE;
  if (fullscreen)
    flags |= SDL_FULLSCREEN;
  
  screen = SDL_SetVideoMode(w, h, bpp, flags);

  if (screen == NULL) {
    fprintf(stderr, "No se puedo inicializar la pantalla: %s\n",
	    SDL_GetError());
    SDL_Quit();
    exit(-1);
  }

#ifdef ENABLE_TTF
  if(TTF_Init() < 0) {
    printf("Error al inicializar las fuentes: %s\n", TTF_GetError());
    exit(2);
  }
#endif
  
  atexit(close_sdl);
}

void close_sdl()
{
#ifdef ENABLE_TTF
  TTF_Quit();
#endif
  
  SDL_Quit();
}

void set_caption(char* string)
{
  SDL_WM_SetCaption(string, 0);
}


void blit_surface(SDL_Surface* s, int x, int y)
{
  SDL_Rect dest;
  dest.x = x;
  dest.y = y;
  dest.w = s->w;
  dest.h = s->h;
  
  SDL_BlitSurface(s, NULL, screen, &dest);
}

void update_screen()
{
  SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
}

void update_screen_rect(int x, int y, int w, int h)
{
  SDL_UpdateRect(screen, x, y, w, h);
}

Uint32 map_colour(int r, int g, int b)
{
  return SDL_MapRGB(screen->format, r, g, b);
}

void lock_screen()
{
  if (SDL_MUSTLOCK(screen))
    SDL_LockSurface(screen);
}

void unlock_screen()
{
  if (SDL_MUSTLOCK(screen))
    SDL_UnlockSurface(screen);
}

void* get_screen_memory() 
{
  return screen->pixels;
}

int get_screen_pitch()
{
  return screen->pitch;
}

int next_event()
{
  return SDL_PollEvent(&curr_event);
}

int wait_event()
{
  return SDL_WaitEvent(&curr_event);
}

SDL_Event* get_event()
{
  return &curr_event;
}

int get_event_type()
{
  switch (curr_event.type) {
  case SDL_KEYUP:
    return EV_KEY_UP;

  case SDL_KEYDOWN:
    return EV_KEY_DOWN;

  case SDL_MOUSEBUTTONDOWN:
    return EV_MOUSE_DOWN;

  case SDL_MOUSEBUTTONUP:
    return EV_MOUSE_UP;

  case SDL_MOUSEMOTION:
    return EV_MOUSE_MOVE;

  case SDL_QUIT:
    return EV_QUIT;
    
  default:
    return EV_UNKNOWN;
  }
}

Uint16 get_key_event_ascii()
{
  return curr_event.key.keysym.unicode;
}

Uint16 get_mouse_motion_x()
{
  return curr_event.motion.x;
}

Uint16 get_mouse_motion_y()
{
  return curr_event.motion.y;
}
