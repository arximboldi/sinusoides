/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.dao;

import java.sql.*;
import java.util.*;

public class OraclePersonDAO extends OracleDAOBase implements PersonDAO
{
    private java.sql.Date getCurrentDate()
    {
	Calendar cal = Calendar.getInstance(); 
	return new java.sql.Date(cal.getTime().getTime());
    }
    
    public Person create()
	throws Exception
    {
	Person person = null;
	
	try {
	    java.sql.Date date = getCurrentDate();
	    Connection conn = getConnection();
	    Statement st = conn.createStatement();
	    ResultSet rs = st.executeQuery("select hm_person_id_seq.nextval from dual");
	    int id = 0;
	    if (rs.next())
		id = rs.getInt(1);
	    else
		throw new Exception("Person creation internal error.");
	    
	    PreparedStatement ps = conn.prepareStatement
		("insert into hm_person values (?, ?)");
	    ps.setInt(1, id);
	    ps.setDate(2, date);
	    ps.executeUpdate();
	    ps.close();

	    person = new Person(id, new java.util.Date(date.getTime()));
	} catch (Exception e) {
	    System.out.println("INSERT EXCEPTION: " + e.toString());
	    throw new Exception("Person creation internal error.");
	} finally {
	    closeConnection();
	}
		
	return person;
    }
    
    public void delete(Person p)
	throws Exception
    {
	try {
	    Connection conn = getConnection();
	    PreparedStatement ps = conn.prepareStatement
		("delete from hm_person where id = ?");
	    ps.setInt(1, p.id);
	    ps.executeUpdate();
	    ps.close();
	} catch (Exception e) {
	    System.out.println("DELETE EXCEPTION: " + e.toString());
	    throw new Exception("Error while deleting person.");
	} finally {
	    closeConnection();
	}
    }
}
