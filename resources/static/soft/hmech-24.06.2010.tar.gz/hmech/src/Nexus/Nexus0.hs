--
--  File:       Nexus0.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Tue Mar 31 16:21:16 2009
--  Time-stamp: <2009-05-29 20:55:44 raskolnikov>
--
--  Bot estúpido util para hacer pruebas.
--

module Nexus.Nexus0 where

import qualified Mech.Warrior as W
import qualified Mech.Action  as A

import Nexus.Path

data Nexus0 = Nexus0 deriving (Show, Read)

instance W.Warrior Nexus0 where
    playMovement w _ = (A.defaultMovement, w)
    playReaction w _ = (A.defaultReaction, w)
    playWeapons  w _ = (A.defaultWeapons, w)
    playPhisical w _ = (A.defaultPhisical, w)
    playEnd      w _ = (A.defaultEnd, w)
    warName      _   = "nexus0"

--
-- Constructor
--
warrior :: Nexus0
warrior = Nexus0


