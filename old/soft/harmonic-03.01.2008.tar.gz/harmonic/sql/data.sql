
/*
  Algunos datos por defecto.
*/

insert into hm_user values ('raskolnikov', '1234', 'magnicida@gmail.com', 'code1');
insert into hm_user values ('luca', 'conesa', 'mefisto88@msn.com', 'code2');
