package harmonic;

import harmonic.gen.*;

public class FrontpageQuery extends BasicQuery
{
    public static class Factory implements QueryFactory {
	public Query create() {
	    return new FrontpageQuery();
	}
    }

    public Page execute(QueryHandler hdl)
    {
	Page result = super.execute(hdl);

	Division blk = new Division("block");
	result.getContent().addContent(blk);
	blk.addContent(new Header(1, "Welcome to Harmonic!"));

	blk.addContent(new Paragraph("Welcome to Harmonic, the greatest music comunity on the net!"
				     + " Start browsing our huge music library and share your tastes with other users."
				     + " Also get dynamically generated online radios automaticalled generated for and your musical tastes based on the music you scrobbled."));
	
	return result;
    }
}
