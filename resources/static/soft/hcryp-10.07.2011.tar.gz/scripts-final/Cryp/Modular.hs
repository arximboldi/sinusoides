--
--  File:       Modular.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Thu Apr  7 16:02:35 2011
--  Time-stamp: <2011-07-10 19:11:38 raskolnikov>
--
--  First script of the Cryptography course held in Universidad de
--  Granada in 2011.
--

{-# LANGUAGE TupleSections #-}

module Cryp.Modular where

import qualified Data.Map as M
import Data.List (genericTake, mapAccumL)
import Data.Tuple (swap)
import Data.Maybe (mapMaybe)
import Data.Sequence (iterateN)
import Data.Bits
import System.Environment (getArgs)
import System.CPUTime (getCPUTime)
import Control.DeepSeq (NFData, rnf)
import Control.Exception (evaluate)
import Random
import Control.Exception (assert)
import Control.Monad (void, liftM2)
import Debug.Trace (trace, traceShow)

debug x = traceShow x x 

gtake n = genericTake n

-- |
-- 
-- Baby-step giant-step algorithm for computing discrete logarithms
--
-- Note that we use a Map to store a table. We believe that we can
-- more efficiently use an inmutable hash table instead. However,
-- there is no simple library for this and we are too lazy to build
-- our own :)
--

intLog :: (Integral a, Bits a) => a -> a -> a -> a
intLog n a b = safeHead . mapMaybe inTable $ gtake m $
               zip ([0..]) $ iterate ((`mod`n).(*a')) b
  where
    m       = ceiling $ sqrt $ fromIntegral n
    a'      = expMod n a (n-m-1)
    table   = M.fromList [(expMod n a j, j) | j <- [0..m-1] ]
    inTable (i, y) = fmap (\j -> i * m + j) $ M.lookup y table
    
    safeHead [] = error "No logarithm!"
    safeHead (a:_) = a

mainIntLog = mainI 3 calc usage
  where calc (n:a:b:_) = return $ intLog n a b
        usage = "Usage: intlog n a b"

-- |
--
-- Miller robin primality test for a given base a.
--

maybePrime :: (Integral a, Bits a) => a -> a -> Bool
maybePrime p a' | abs a == 1 = True
                | otherwise  = any (<0) $ take 1 $ dropWhile ((1/=).abs) pows
  where (s, u) = until (odd.fst) (\(s, u) -> (s `div` 2, u+1)) (p-1, 0)
        unitPow k a = let r = expMod p a k in if r == p - 1 then -1 else r 
        a = unitPow s a'
        pows = drop 1 $ take u $ iterate (unitPow (2 :: Int)) a

-- | 
-- 
-- Repeats the Miller Robin primality test with m random bases tanken
-- from stdGen.
--

maybePrimeGen :: (Bits a, Integral a, Random a, RandomGen g) => 
                 g -> a -> a -> (Bool, g)
maybePrimeGen g p m = (res, gen')
  where
    (gen', randoms) = mapAccumL (\g _ -> swap $ randomR (2, p - 2) g) g [0..m-1] 
    res = all (maybePrime p) randoms 

maybePrimeIO :: (Bits a, Integral a, Random a) => a -> a -> IO Bool
maybePrimeIO p m = do
  gen <- getStdGen
  let (res, gen') = maybePrimeGen gen p m
  setStdGen gen'
  return res

mainMaybePrime = mainI 2 calc usage
  where calc (p:m:_) = maybePrimeIO p m
        usage = "Usage: maybeprime n m"

-- |
--
-- Extended Greatest Commmon Divisor
--
-- Recursive version based on the code found here:
-- htttp://www.cse.chalmers.se/edu/course/TDA351/lect05.pdf
--
-- Differences include: we uncurrified the parameters (i.e. more
-- idiomatic Haskell) and use divMod instead of two separate
-- operations for better performance.
--
-- This implementation is not tail recursive, thus, it has O(ln n)
-- space complexity.
--

gcde' :: (Integral a) => a -> a -> (a, a, a)
gcde' a 0 = (a, 1, 0)
gcde' a b = (d, t, s - q*t)
  where (q, r)    = divMod a b
        (d, s, t) = gcde' b r

mainGcde' = mainI 2 calc usage
  where calc (a:b:_) = return $ gcde' a b
        usage = "Usage: gcde2 a b"

-- |
--
-- Extended Greatest Commmon Divisor
--
-- This implementation is based on the algorithm in the "Handbook of
-- Applied Cryptography".
-- 
-- This implementation is tail recursive and thus theoretically better
-- performant than the previous.
--

gcde :: (Integral a) => a -> a -> (a, a, a)
gcde a 0 = (a, 1, 0)
gcde a b = go a b 0 1 1 0
  where go a 0 x y x2 y2 = (a, x2, y2)
        go a b x y x2 y2 = 
          let (q, r) = divMod a b
          in go b r (x2 - q * x) (y2 - q * y) x y

mainGcde = mainI 2 calc usage
  where calc (a:b:_) = return $ gcde a b
        usage = "Usage: gcde a b"

-- |
--
-- Computes a^k in Z_n.
--
-- Uses the repeated square-and-multiply algorithm for exponentiation
-- in Z_n, as in "Handbook of Applied Cryptography"
--

expMod :: (Integral a, Bits b) => a -> a -> b -> a
expMod n a k = go a 1 k 
  where go a b 0 = b
        go a b k = go (a * a `mod` n) b' (shiftR k 1)
          where b' = if testBit k 0 then a * b `mod` n else b

mainExpMod = mainI 3 calc usage
  where calc (n:a:k:_) = return $ expMod n a k
        usage = "Usage: expmod n a k"

-- |
--
-- Computes the inverse of a in Z_n.
--
-- This uses the tail recursive version of gcde and thus have the same
-- complexity.
--

invMod :: (Integral a) => a -> a -> a
invMod n a = let (d, x, y) = gcde n a
             in if d == 1 then 
                  if y < 0 then n + y
                  else y
                else error "Not invertible."

mainInvMod = mainI 2 calc usage
  where calc (a:b:_) = return $ invMod a b
        usage = "Usage: invmod n a"

-- |
--
-- Generic main for two arguments
--

mainI :: (NFData a, Show a) => Int -> ([Integer] -> IO a) -> String -> IO Int
mainI n fn usage = do
  args <- getArgs
  if length args /= n
    then do putStrLn usage
            return 1 
    else do let !ints = map (read) args
            evaluate $! rnf ints
            t <- getCPUTime
            res <- fn ints
            evaluate $! rnf res
            t' <- getCPUTime
            let dt = (fromIntegral (t' - t) * 1e-12) :: Double
            putStrLn ("Time:     " ++ show dt)
            putStrLn ("Result:   " ++ show res)
            return 0

-- |
-- 
-- Performance test
--

oneTest (name, testfn) (a, b) = do
  dt <- testfn (snd a) (snd b)
  putStrLn ("-- " ++ name ++ 
            "  t: " ++ show dt ++ 
            "  p: " ++ (show $ fst b) ++ 
            "  d: " ++ (show $ numDigits 10 $ snd b))

perfTest2 fn a b = do
  evaluate $! rnf a
  evaluate $! rnf b
  t <- getCPUTime
  res <- return $! fn a b
  evaluate $! rnf $! res
  t' <- getCPUTime
  return (fromIntegral (t' - t) * 1e-12) :: IO Double
  
mainPerfTest = do
  let mersenne = [ (p, 2^p-1) | p <- [
                      7, 13, 17, 19, 31, 89, 127
                      , 521, 1279, 2203, 4253 
                      , 9689, 11213, 19937, 23209
                      , 44497, 110503, 756839, 1257787
                      ]]
  let testIn  :: [((Integer, Integer), (Integer, Integer))]
      testIn   = zip mersenne $ tail mersenne
  let k        = 37 :: Integer
  let tests   :: [(String, (Integer -> Integer -> IO Double))]
      tests    = [("maybePrime", perfTest2 $ \a b -> maybePrime b 1), 
                  ("gcde'",      perfTest2 $ \a b -> gcde' b a),
                  ("gcde",       perfTest2 $ \a b -> gcde b a),
                  ("expMod",     perfTest2 $ \a b -> expMod b a k),
                  ("invMod",     perfTest2 $ \a b -> invMod b a),
                  ("intLog",     perfTest2 $ \a b -> intLog b (a+1) 2)]
  sequence_ $ liftM2 oneTest tests testIn
  return 0

--   evaluate $! rnf mersenne
  
--   return 0

numDigits b n = 1 + fst (ilog b n) 
  where ilog b n | n < b     = (0, n)
                 | otherwise = let (e, r) = ilog (b*b) n
                               in  if r < b then (2*e, r) 
                                   else (2*e+1, r `div` b)
