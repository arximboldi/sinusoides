
#ifndef FILTERVOLUME_H
#define FILTERVOLUME_H

#include "filter.h"

class FilterVolume : public Filter
{
  float m_ampl;
  
 public:
 FilterVolume(float ampl) :
  m_ampl(ampl)
  {}
  
  void process(Sample* buf, int n_samples);
};

#endif /* FILTERVOLUME_H */
