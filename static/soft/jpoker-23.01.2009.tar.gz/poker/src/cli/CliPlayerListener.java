/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package cli;

import java.util.Collection;
import java.util.List;

import game.Card;
import game.Player;
import game.PlayerListener;

/**
 * Escucha los eventos de un jugador y los visualiza por un flujo de texto.
 * 
 * @author raskolnikov
 */
public class CliPlayerListener implements PlayerListener 
{
	/**
	 * Constructor.
	 * @param out El flujo a usar para la salida.
	 * @param pub Si es cierto, se mostrarán los valores de las cartas.
	 */
	public CliPlayerListener (CliPrinter out, boolean pub)
	{
		m_out    = out;
		m_public = pub;
	}
	
	/**
	 * Maneja la apuesta de un jugador.
	 * 
	 * {@inheritDoc}
	 */
	@Override
	public void handlePlayerBet (Player p, double bet)
	{
		m_out.println(p.getName () + ": bets " + bet);
	}

	/**
	 * Maneja la devolución de cartas de un jugador.
	 * 
	 * {@inheritDoc}
	 */
	@Override
	public void handlePlayerDrop (Player p, Collection<Card> cards)
	{
		m_out.print (p.getName () + ": drops ");
		
		if (cards.isEmpty ())
			m_out.println ("nothing");
		else if (m_public) {
			for (Card c : cards) {
				m_out.print (c.toString ());
			}
			m_out.println ();
		} else
			m_out.println (cards.size () + " cards");
	}
	
	/**
	 * Maneja la devolución forzosa de todas las cartas de un jugador.
	 * 
	 * {@inheritDoc}
	 */
	@Override
	public void handlePlayerDropAll (Player p, List<Card> cards)
	{
		m_out.print (p.getName () + ": returned all ");
		if (m_public) {
			for (Card c : cards) {
				m_out.print (c.toString ());
			}
			m_out.println ();
		} else
			m_out.println (cards.size () + " cards");
	}

	/**
	 * Maneja el recibo de cartas por parte de un jugador.
	 * 
	 * {@inheritDoc}
	 */
	@Override
	public void handlePlayerTake (Player p, Card c)
	{
		m_out.println(p.getName () + ": gets a " + (m_public ? c : "card"));
	}
	
	@Override
	public void handlePlayerUpdateSavings(Player p, double diff)
	{
		/* Si son pérdidas se deduce ya de las apuestas. */
		if (diff > 0) {
			m_out.println (p.getName() + ": received " + diff + " euros");
		}
	}
	
	/** El stream de salida. */
	private CliPrinter m_out = new CliStreamPrinter (System.out);
	
	/** Si la partida es pública */
	private boolean m_public  = false;
}
