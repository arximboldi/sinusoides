/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

/**
 * Portador de la información necesaria por la interfaz para construir un
 * jugador.
 * 
 * @author raskolnikov
 */
class PlayerInfo
{
	/**
	 * Tipo de jugador.
	 * @author raskolnikov
	 *
	 */
	public enum Type
	{
		BOT_SIMPLE, /**< Bot sencillo con parametros aleatorios */
		BOT_DUMB,   /**< Bot estupido */
		HUMAN       /**< Humano */
	}
	
	/** El nombre del jugador */
	public String name;
	/** Las ganancias del jugador */
	public double savings;
	/** El tipo del jugador */
	public Type   type;
	
	/**
	 * Constructor.
	 */
	PlayerInfo () {}
	
	/**
	 * Constructor.
	 * @param n El nombre.
	 * @param s Las ganancias.
	 * @param t El tipo.
	 */
	PlayerInfo (String n, double s, Type t)
	{
		name = n;
		savings = s;
		type = t;
	}
}
