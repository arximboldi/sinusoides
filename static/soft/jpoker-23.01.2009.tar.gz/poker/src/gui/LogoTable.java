/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * Mesa de poker estupida que realmente no juega sino que simplemente muestra el
 * logo del programa.
 * 
 * @author raskolnikov
 * 
 */
public class LogoTable implements GameTable
{
	/**
	 * Construye la mesa.
	 * @param parent La clase padre.
	 */
	LogoTable (Shell parent)
	{
		GridData data = new GridData (GridData.HORIZONTAL_ALIGN_FILL | 
				   GridData.GRAB_HORIZONTAL | GridData.VERTICAL_ALIGN_FILL | 
				   GridData.GRAB_VERTICAL);
		data.horizontalAlignment = SWT.CENTER;
		
		m_bg = new Composite (parent, SWT.NONE);
		m_bg.setLayoutData (new GridData (GridData.HORIZONTAL_ALIGN_FILL | 
				   GridData.GRAB_HORIZONTAL | GridData.VERTICAL_ALIGN_FILL | 
				   GridData.GRAB_VERTICAL));
		m_bg.setBackground (ColorFactory.getTable ());
		m_bg.setBackgroundMode (SWT.INHERIT_DEFAULT);
		m_bg.setLayout (new GridLayout ());
		
		Label pic = new Label (m_bg, SWT.NONE);
		pic.setImage (ImageFactory.getLogo ());
		pic.setLayoutData (data);
		
		m_bg.pack ();
	}
	
	/**
	 * Elimina la mesa.
	 */
	public void dispose ()
	{	
		m_bg.dispose ();
	}

	/**
	 * {@inheritDoc}
	 */
	public void iterate ()
	{	
	}
	
	private Composite m_bg = null;
}
