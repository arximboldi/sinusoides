/**
 *  Time-stamp:  <2010-11-25 15:34:20 raskolnikov>
 *
 *  @file        main_seq.cpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Wed Nov 17 21:49:09 2010
 *
 *  Algoritmo de floyd secuencial.
 */

#include "full_dist_graph.hpp"
#include "generic_floyd.hpp"

int main (int argc, char** argv)
{
    return pdp::generic_floyd_main<pdp::full_dist_graph<double> > (argc, argv);
}
