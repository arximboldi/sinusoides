%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       blockmatch_fast.m
%  Time-stamp: <2011-01-28 08:00:30 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Detección de offset de blocks rápido.
%

function field_offset = blockmatch_fast (...
    block_size, max_offset, mse_or_msa, f_now, f_prev)

    if mse_or_msa
        mse_or_msa = @ (b0, b1) sum (sum ((double (b1) - double (b0)).^2));
    else
        mse_or_msa = @ (b0, b1) sum (sum (abs (double(b1) - double (b0))));
    end

    [rows cols]  = size (f_now);
    field_offset = zeros (rows, cols);

    num_blocks_v = floor (rows / block_size);
    num_blocks_h = floor (cols / block_size);
    
    for i = 1 : num_blocks_v
        for j = 1 : num_blocks_h
            f_inic = ((i-1)*block_size)+1;
            c_inic = ((j-1)*block_size)+1;
            
            block = f_now(f_inic:f_inic+block_size-1, ...
                          c_inic:c_inic+block_size-1);
            
            prev_block = f_prev(f_inic:f_inic+block_size-1, ...
                                c_inic:c_inic+block_size-1);
            
            min_criteria = mse_or_msa (prev_block, block);
            dist = ceil (max_offset / 2);
            
            faux = f_inic;
            caux = c_inic;
            
            criteria_f = 0;
            criteria_c = 0;
            criteria_ffinal = 0;
            criteria_cfinal = 0;
            
            fin_bucle = false;
            
            while ~fin_bucle
                if dist == 1
                    fin_bucle = true;
                end
                
                for u = - dist:dist:dist
                    if ((faux+u >=1) && (faux+block_size+u-1 ...
                                         <= size(f_now,1)))
                        for v = -dist:dist:dist
                            if ((caux+v>=1) && (caux+block_size+v-1 ...
                                                <=  size(f_now,2)))
                                prev_block = f_prev(faux+u:faux+u+ ...
                                                    block_size-1, ...
                                                    caux+v:caux+v+block_size-1);
                                
                                criteria = mse_or_msa (prev_block, block);
                                
                                if min_criteria > criteria
                                    min_criteria = criteria;
                                    criteria_f = u;
                                    criteria_c = v;
                                end
                            end
                        end %end v
                    end
                end 
                % end u
                
                if (dist / 2) < 1
                    dist = 0;             
                else
                    dist = ceil (dist / 2);
                end
                
                criteria_ffinal = criteria_ffinal + criteria_f;
                criteria_cfinal = criteria_cfinal + criteria_c;
                
                faux = faux + criteria_f;
                caux = caux + criteria_c;
            end %final de while

            field_offset(f_inic:f_inic+block_size-1, ...
                         c_inic:c_inic+block_size-1) ...
                = complex(criteria_ffinal,criteria_cfinal);
        end %Fin j
    end %Fin  i
