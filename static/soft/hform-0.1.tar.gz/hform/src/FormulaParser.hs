--------------------------------------------------------------------------------
--
-- Fichero:    FormulaParser.hs
-- Autor:      Juan Pedro Bolivar Puente
-- Time-stamp: <2009-02-02 07:50:27 raskolnikov>
--
--------------------------------------------------------------------------------

-- |
-- Módulo para parsear expresiones de tipo Formula
--
module FormulaParser where

import System.IO.Error
import Control.Exception

import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Expr
import Text.ParserCombinators.Parsec.Token

import Formula

-- |
-- Una bonita utilidad para parsear con excepciones.
--
parseIO :: String -> Parser a ->  IO a
parseIO f p = case parse p "" f of
                  Left e  -> ioError (userError (show e))
                  Right r -> return r

-- |
-- Parser combinador para leer formulas
-- 
-- De regalo, un chiste leido en el canal #haskell de Freenode a las 7 AM:
--
-- <llayland> So, I was reading "Real World Haskell" earlier, and my fever got to be a bit much so I took a nap.  I dreamed that I was coding and it did affect the real world.  Unfortunately I wasn't any better in my dreams
-- <llayland> very weird stuff
-- <jrockway> llayland: obviously your dream took place in the IO monad
-- <jrockway> "impure thoughts" if you will

formulaParser :: Parser a -> Parser (Formula a)
formulaParser atom = buildExpressionParser table (factor atom) <?> "expression"

-- |
-- Parser combinador para leer enteros
--
numberParser :: Parser Integer
numberParser = do { ds <- many1 digit; return (read ds) } <?> "number"

--
-- Utilidades
--

table = [ [monop "~"   N]
        , [binop "|"   (:|)   AssocLeft]
        , [binop "&"   (:&)   AssocLeft]
	, [binop "->"  (:->)  AssocLeft]
        , [binop "<->" (:<->) AssocLeft] ]
  where
    monop s f = Prefix (do { string s; return f })
    binop s f assoc = Infix (do { string s; return f }) assoc

factor atom = do { char '('; x <- (formulaParser atom); char ')'; return x }
              <|> do { char 'T'; return (V True) }
              <|> do { char 'F'; return (V False) }
	      <|> do { x <- atom; return (A x) }
              <?> "simple expression"

