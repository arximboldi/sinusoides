/**
 * @file   render.cpp
 * @author Juan Pedro Bol�var Puente
 * @date   April 2007
 * 
 * Copyright (C) 2007 by Juan Pedro Bol�var Puente
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <iostream>
#include <SDL/SDL_image.h>

#include "glmorph.h"
#include "render.h"
#include "SDL_2dgl.h"

using namespace std;

/* A nice tool for texture blitting*/
static int power_of_two(int input)
{
  int value = 1;

  while ( value < input ) {
    value <<= 1;
  }
  return value;
}

/*
 * Some SDL_2dgl extensions that I havent decided to merge yet.
 * Actually some more changes are to be made at SDL_2dgl.c as it is a bit
 * outdated and some changes would be cool (i.e.: changing the float interface
 * to int) ...
 */

void GL2D_DrawPoint(float x, float y, int size, Uint8 r, Uint8 g, Uint8 b, Uint8 a)
{
	glEnable(GL_BLEND);
	glPointSize(size);
	
	glBegin(GL_POINTS);
	glColor4f(r/255, g/255, b/255, a/255);
	glVertex2f(x, y);
	glEnd();
	glDisable(GL_BLEND);
}

bool initSDL()
{
    if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
        cerr << _("ERROR: SDL_Init did not work because: %s\n") << SDL_GetError();
    	return false;
    }
    
	atexit(SDL_Quit);
	
	return true;
}

GL2D_SurfaceGL* loadPicture(const char* path)
{
	SDL_Surface* tmp = IMG_Load(path);
	GL2D_SurfaceGL* surf = NULL;
	
	if (tmp == NULL)
		return NULL;
	
	surf = GL2D_CreateSurfaceGL(tmp, GL_LINEAR);
	
	SDL_FreeSurface(tmp);
	
	return surf;
}

void drawWarpedPic(const GL2D_SurfaceGL* src, const Mesh2D &m1, const Mesh2D &m2, Uint8 alpha)
{
	int i, j;
	
	float pw = power_of_two(src->w);
	float ph = power_of_two(src->h);	

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			
	glColor4ub(alpha, alpha, alpha, alpha);
	glBindTexture(GL_TEXTURE_2D, src->tex);
	
	for (i = 0; i < m1.width()-1; i++) {
		for (j = 0; j < m1.height()-1; j++) {	
			glBegin(GL_QUADS);
			glTexCoord2f( m1.get(i, j).x/pw , m1.get(i, j).y/ph );
			glVertex2f  ( m2.get(i, j).x , m2.get(i, j).y );
			
			glTexCoord2f( m1.get(i+1, j).x/pw, m1.get(i+1, j).y/ph );
			glVertex2f  ( m2.get(i+1, j).x, m2.get(i+1, j).y );
			
			glTexCoord2f( m1.get(i+1, j+1).x/pw, m1.get(i+1, j+1).y/ph );
			glVertex2f  ( m2.get(i+1, j+1).x, m2.get(i+1, j+1).y );
			
			glTexCoord2f( m1.get(i, j+1).x/pw, m1.get(i, j+1).y/ph );
			glVertex2f  ( m2.get(i, j+1).x, m2.get(i, j+1).y );
			glEnd();
		}
	}
	
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
}

void drawMesh2D(const Mesh2D& m)
{
	int i, j;
	Point2D p1;
	Point2D p2;
	
	for (i = 0; i < m.width()-1; i++) {
		for (j = 0; j < m.height()-1; j++) {
			p1 = m.get(i, j);
			p2 = m.get(i, j+1);
			GL2D_DrawLine(p1.x, p1.y, p2.x, p2.y, MESH_RED, MESH_GREEN, MESH_BLUE, 255);
			p2 = m.get(i+1, j);
			GL2D_DrawLine(p1.x, p1.y, p2.x, p2.y, MESH_RED, MESH_GREEN, MESH_BLUE, 255);
		}
	}
	
	for (i = 0; i < m.width()-1; i++) {
		p1 = m.get(i,   m.height()-1);
		p2 = m.get(i+1, m.height()-1);
		GL2D_DrawLine(p1.x, p1.y, p2.x, p2.y, MESH_RED, MESH_GREEN, MESH_BLUE, 255);
	}
	for (i = 0; i < m.height()-1; i++) {
		p1 = m.get(m.width()-1,  i);
		p2 = m.get(m.width()-1, i+1);
		GL2D_DrawLine(p1.x, p1.y, p2.x, p2.y, MESH_RED, MESH_GREEN, MESH_BLUE, 255);
	}
	
	for (i = 0; i < m.width(); i++) {
		for (j = 0; j < m.height(); j++) {
			p1 = m.get(i, j);
			GL2D_DrawPoint(p1.x, p1.y, POINT_SIZE, MESH_RED, MESH_GREEN, MESH_BLUE, 255);
		}
	}
}



