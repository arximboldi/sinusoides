--
--  File:       Debug.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon Mar 30 14:20:06 2009
--  Time-stamp: <2009-03-30 14:22:53 raskolnikov>
--
--  Herramientas de depuración
--

module Nexus.Debug (trace, debug, debugs) where

-- Debug
import Debug.Trace

debug x = trace (show x) x
debugs s x = trace (s ++ show x) x




