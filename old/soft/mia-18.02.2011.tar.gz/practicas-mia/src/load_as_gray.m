%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  (c) 2010-2011 Juan Pedro Bolívar Puente
%
%  Time-stamp: <2011-01-23 06:19:58 raskolnikov>
%  Autor:      Juan Pedro Bolívar Puente
%  File:       load_as_gray.m
%
    
function img = load_as_gray (filename)
    [img, mapa] = imread (filename);

    info = imfinfo (filename);
    tam  = size (img);
    
    switch info.ColorType
      case 'truecolor'
        img = rgb2gray (img);
      case 'indexed'
        img = ind2gray (img, mapa);
      otherwise
    end
end

    
    