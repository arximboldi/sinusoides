--
--  File:       Util.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Wed May 27 10:58:39 2009
--  Time-stamp: <2009-05-30 22:56:08 raskolnikov>
--
--  Funciones varias de utilitarios.
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Mech.Util where

best :: (a -> a -> Bool) -> [a] -> [a]
best comp []     = []
best comp (x:xs) = go xs [x]
    where
      go [] ac     = ac
      go (x:xs) ac | comp x (head ac) = if comp (head ac) x 
                                        then go xs (x:ac)
                                        else go xs [x]
                   | otherwise        = go xs ac

