/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import game.DelegatedPokerPlayer;
import game.DumbPokerPlayer;
import game.Game;
import game.GameException;
import game.GameListener;
import game.Player;
import game.PokerGame;
import game.SimplePokerPlayer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import cli.CliGameListener;
import cli.CliPlayerListener;

/**
 * La vista de una partida de poker.
 * @author raskolnikov
 *
 */
public class GameView implements GameTable, GameListener
{
	/**
	 * Constructor.
	 * @param parent La ventana sobre la que instalar la vista.
	 * @param log Un control sobre el que emitir los mensajes.
	 * @param info La información de la partida a crear.
	 * @throws GameException
	 */
	GameView (Shell parent, Text log, GameInfo info)
		throws GameException
	{
		m_game_info = info;
		
		m_grid = new Composite (parent, SWT.NONE);
		m_grid.setLayoutData (new GridData (GridData.HORIZONTAL_ALIGN_FILL | 
				   GridData.GRAB_HORIZONTAL));
		GridLayout lay = new GridLayout (2, true);
		m_grid.setLayout (lay);
		m_grid.setBackground (ColorFactory.getTable ());
		
		/* Crear la partida y los jugadores */
		m_game = new PokerGame (info.min_bet);
		m_game.addListener (new CliGameListener (new SwtTextPrinter (log)));
		
		for (PlayerInfo pi : info.players) {
			Player p;
			PlayerView view = null;
			
			switch (pi.type) {
			case HUMAN:
				p = new DelegatedPokerPlayer (pi.name, pi.savings);
				view = new InteractivePlayerView (m_grid, p);
				((DelegatedPokerPlayer) p).setExternal ((InteractivePlayerView) view);
				break;
				
			case BOT_SIMPLE:
				Random r = new Random ();
				p = new SimplePokerPlayer (pi.name, pi.savings, r.nextDouble(), r.nextDouble());
				break;
				
			default:
				p = new DumbPokerPlayer (pi.name, pi.savings);
				break;
			}
			
			if (view == null)
				view = new PassivePlayerView (m_grid, p, info.public_cards);
			view.build ();
			m_player_views.add (view);
			
			p.addListener (new CliPlayerListener (new SwtTextPrinter (log),
					info.public_cards));
			
			m_game.join (p);
		}
		
		m_game.addListener (this);
		
		GridData gdata = new GridData (GridData.HORIZONTAL_ALIGN_FILL | 
				   GridData.GRAB_HORIZONTAL);
		gdata.horizontalSpan = info.players.size ();
		Composite c = new Composite (m_grid, SWT.NONE);
		c.setLayout (new GridLayout (2, false));
		c.setLayoutData (gdata);
		
		/* Etiqueta del bote */
		gdata = new GridData ();
		m_pot_label = new Label (c, SWT.NONE);
		m_pot_label.setText ("Pot: 0");
		m_pot_label.setForeground (ColorFactory.getPot ());
		gdata.widthHint = 60;
		m_pot_label.setLayoutData (gdata);
		
		SwtUtils.setBackgroundRecursive (c, ColorFactory.getTable ());
		
		/* Boton de continuar */
		gdata = new GridData (GridData.HORIZONTAL_ALIGN_FILL | 
				   GridData.GRAB_HORIZONTAL);
		m_continue_but = new Button (c, SWT.PUSH);
		m_continue_but.setText ("Continue!");
		m_continue_but.setLayoutData (gdata);
		m_continue_but.addSelectionListener (
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				GameView.this.m_must_continue = true;
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
		c.pack ();
		
		/* Comenzar la partida */
		m_game.start ();
		m_grid.pack ();
		updateState ();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void iterate ()
	{
		if (m_must_continue || m_game_info.non_stop) {
			if (!m_game_info.non_stop) {
				m_must_continue = false;
				m_continue_but.setEnabled (false);
			}
			
			try {
				if (m_game.getState () != PokerGame.State.FIRST_BET && 
					m_game.getState () != PokerGame.State.SECOND_BET)
					resetBets ();
				m_finished = m_game.playRound ();
				updateState ();
			} catch (Exception e) {
				if (m_grid != null && !m_grid.isDisposed ()) {
					SwtUtils.errorMessage ((Shell) m_grid.getParent (), e.getMessage ());
					e.printStackTrace();
				}
			}
			
			if (!m_game_info.non_stop && !m_continue_but.isDisposed () && !m_finished)
				m_continue_but.setEnabled (true);
		}
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void dispose ()
	{
		if (m_game != null)
			try {
				m_game.stop ();
				m_game = null;
			} catch (Exception e) {}
		
		if (m_grid != null)
			m_grid.dispose();
			m_grid = null;
	}

	private void updateState ()
	{
		switch (m_game.getState ())
		{
		case RESULTS:
			for (PlayerView p : m_player_views)
				p.showCards ();
			break;
		case DROP_CARDS:
			for (PlayerView p : m_player_views)
				p.hideCards();
			break;
		default:
			break;
		}
		m_continue_but.setText ("Continue: " + 
				m_game.getState ().toString ().replace('_', ' '));
		m_pot_label.setText ("Pot: " + m_game.getPot ());
	}
	
	private void resetBets ()
	{
		for (PlayerView p : m_player_views)
			p.resetBet ();
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void handleGameFinish(Game g)
	{	
		SwtUtils.infoMessage(m_grid.getShell (), "¡La partida ha terminado!\n Ganador: " 
				+ ((PokerGame)g).getAlivePlayers ().get (0).getName ());
	}

	/**
	 * {@inheritDoc}
	 */
	public void handleGameJoin(Game g, Player p)
	{	
	}

	/**
	 * {@inheritDoc}
	 */
	public void handleGameLeave(Game g, Player p)
	{
	}

	/**
	 * {@inheritDoc}
	 */
	public void handleGameRound(Game g, List<Player> winner)
	{
	}

	public void handleGameStart(Game g)
	{	
	}

	private boolean m_finished = false;
	private boolean m_must_continue = false;
	private Button m_continue_but;
	private PokerGame m_game;
	private GameInfo m_game_info;
	private Composite m_grid;
	private Label m_pot_label;
	private LinkedList<PlayerView> m_player_views = new LinkedList<PlayerView> ();
}
