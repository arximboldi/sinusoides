
#ifndef DOUBLEBUFFER_H
#define DOUBLEBUFFER_H

#include <cstdlib>

/**
 * T must be a basic type.
 */
template <class T>
class DoubleBuffer
{
  T* m_readbuf;
  T* m_writebuf;
  int m_writepos;
  int m_readpos;
  int m_maxreadpos;
  int m_size;

  void allocate();
  void liberate();
  
 public:
  DoubleBuffer(int size);
  ~DoubleBuffer();

  T pop();
  void push(T* data, int n_samples);

  int readable() {
    return m_maxreadpos - m_readpos;
  }
  
  int writeable() {
    return m_size - m_writepos;
  }
    
  int size() {
    return m_size;
  };
};

template<class T>
void DoubleBuffer<T>::allocate()
{
  m_readbuf = new T[ 2 * m_size * sizeof(T) ];
  m_writebuf = m_readbuf + m_size;
  memset(m_readbuf, 0, sizeof(T) * m_size * 2);
}

template<class T>
void DoubleBuffer<T>::liberate()
{
  delete [] min(m_readbuf, m_writebuf);
  m_readbuf = m_writebuf = 0;
}

template<class T>
DoubleBuffer<T>::DoubleBuffer(int size) :
  m_writepos(0),
  m_readpos(0),
  m_maxreadpos(0),
  m_size(size)
{
  allocate();
}

template<class T>
DoubleBuffer<T>::~DoubleBuffer()
{
  liberate();
}

template<class T>
T DoubleBuffer<T>::pop()
{
  if (m_readpos >= m_maxreadpos) {
    //std::cout << "swap: " << m_readpos << std::endl;
    //std::cout << "      " << m_maxreadpos << std::endl;
    m_readpos = 0;
    m_maxreadpos = m_writepos;
    m_writepos = 0;
    swap(m_readbuf, m_writebuf);
  }

  /* hack */
  if (m_readpos >= m_maxreadpos) {
    return T(0);
  }

  return m_readbuf[m_readpos++];
}

template<class T>
void DoubleBuffer<T>::push(T* data, int n_samples)
{
  memcpy(m_writebuf + m_writepos, data, sizeof(T) * n_samples);
  m_writepos += n_samples;
}

#endif /* DOUBLEBUFFER_H */
