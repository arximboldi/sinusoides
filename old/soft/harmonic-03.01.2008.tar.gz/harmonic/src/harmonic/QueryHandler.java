/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic;

import harmonic.gen.*;
import harmonic.dao.*;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;
import java.util.*;

public class QueryHandler
{
    HttpServletRequest m_request = null;
    HttpServletResponse m_response = null;
    QueryFactoryManager m_factory = null;
    UserSession m_user_session = null;
    
    public static class Exception extends java.lang.Exception
    {
	Exception() {}

	Exception(java.lang.Throwable cause) {
	    super(cause);
	}

	Exception(String msg, java.lang.Throwable cause) {
	    super(msg, cause);
	}

	Exception(String msg) {
	    super(msg);
	}
    }
    
    QueryHandler(QueryFactoryManager factory,
		 HttpServletRequest request,
		 HttpServletResponse response) {
	m_factory = factory;
	m_request = request;
	m_response = response;
	m_user_session = new UserSession(request.getSession(true));
    }

    public DAOFactory getDAOFactory()
    {
	return DAOFactory.getDAOFactory(DAOFactory.ORACLE);
    }

    /* FIXME */
    public String extractQueryName()
    {
	String path = m_request.getServletPath();
	return path.substring(path.indexOf('/'));
    }

    /* FIXME */
    public String extractQueryParam()
    {
	String path = m_request.getServletPath();
	return path.substring(path.indexOf('/', 1), path.length());
    }

    public String extractQuery()
    {
	return m_request.getServletPath();
    }

    public void redirect(String location)
    {
	try {
	    m_response.sendRedirect(location);
	} catch (java.lang.Exception e) {
	    //throw new Exception(e);
	}
    }

    public UserSession getUserSession() {
	return m_user_session;
    }

    public String getParameter(String name) {
	return m_request.getParameter(name);
    }
    
    public void run()
	throws Exception
    {
	try {
	    String name = extractQueryName();
	    Query query = m_factory.create(name);
	    if (query == null)
		query = new ErrorQuery();

	    Page page = query.execute(this);

	    if (page != null) {
		Document doc = createDocument();
		doc.appendChild(page.generate(doc));
		printDocument(doc);
	    }
	} catch (java.lang.Exception e) {
	    throw new Exception(e);
	}
    }

    private Document createDocument()
	throws ParserConfigurationException
    {
	DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
	DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
	
	return docBuilder.newDocument();
    }
    
    private void printDocument(Document doc)
	throws TransformerConfigurationException,
	       TransformerException,
	       IOException
    {
	PrintWriter out = m_response.getWriter();
	TransformerFactory trans_fact = TransformerFactory.newInstance();
	trans_fact.setAttribute("indent-number", 4);
	Transformer trans = trans_fact.newTransformer();
	
	trans.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "-//W3C//DTD XHTML 1.1//EN");
	trans.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd");
	trans.setOutputProperty(OutputKeys.INDENT, "yes");
	trans.setOutputProperty(OutputKeys.ENCODING, "UTF-8");	
	trans.setOutputProperty(OutputKeys.VERSION, "1.0");	
	
	/* Seria mas eficiente pasarle 'out' directamente al StreamResult, sin
	   embargo eso hace que si se lanza la excepción obtenemos un salida corrupta
	   y no podemos generar una página de error amable para el usuario. */
	StringWriter res = new StringWriter();
	trans.transform(new DOMSource(doc), new StreamResult(res));

	out.print(res.toString());
    }
}
