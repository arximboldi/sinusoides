%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  (c) 2010-2011 Juan Pedro Bolívar Puente
%
%  Time-stamp: <2011-01-23 06:47:24 raskolnikov>
%  Autor:      Juan Pedro Bolívar Puente
%  File:       image_diff.m
%
%

function mse = compute_mse (imga, imgb)
    if size (imga) ~= size (imgb)
        errordlg(['Images must have the same size in order to calculate ' ...
                  'the MSE.'], 'Bad Input','modal');
        mse = NaN;
    else
        s     = size (imga);
        error = double (imga) - double (imgb);
        mse   = norm (error (:))^2 / (s(1) * s(2));
    end
end
