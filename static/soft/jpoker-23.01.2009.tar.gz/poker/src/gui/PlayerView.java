/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import java.util.Collection;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;

import game.Card;
import game.DumbPokerPlayer;
import game.Player;
import game.PlayerListener;
import game.SimplePokerPlayer;

/**
 * Base de las vistas de un jugador. Crea un marco sobre el que muestra y
 * actualiza automáticamente los datos básicos delegando en las subclases
 * algunas operaciones.
 * 
 * @author raskolnikov
 * 
 */
public abstract class PlayerView implements PlayerListener
{
	public abstract void showCards ();
	public abstract void hideCards ();
	public abstract void buildGui (Composite parent);
	
	/**
	 * Constructor.
	 * @param parent El marco dónde insertar al jugador.
	 * @param player El jugador a visualizar.
	 */
	PlayerView (Composite parent, Player player)
	{
		m_player = player;
		player.addListener (this);
		
		m_group = new Group (parent, SWT.SHADOW_OUT);
		m_group.setLayout (new GridLayout ());
		GridData data = new GridData ();
		data.verticalAlignment = SWT.TOP;
		data.horizontalAlignment = SWT.CENTER;
		m_group.setLayoutData (data);
		
		Label name_label = new Label (m_group, SWT.NONE);
		name_label.setText ("Name: " + player.getName ());
		name_label.setForeground (ColorFactory.getName ());
		
		Label type_label = new Label (m_group, SWT.NONE);
		type_label.setText ("Type: Unknown");
		if (player instanceof DumbPokerPlayer)
			type_label.setText ("Type: Dumb bot");
		else if (player instanceof SimplePokerPlayer)
			type_label.setText ("Type: Simple bot");
		else
			type_label.setText ("Type: Human");
		
		m_savings_label = new Label (m_group, SWT.NONE);
		m_savings_label.setText ("Savings: " + player.getSavings ());
		m_accum_bet_label = new Label (m_group, SWT.NONE);
		m_accum_bet_label.setText ("Bet: " + m_accum_bet);	
	}
	
	/**
	 * Construye la interfaz.
	 * @return El propio obejto.
	 */
	public PlayerView build ()
	{
		buildGui (m_group);
		SwtUtils.setBackgroundRecursive (m_group, ColorFactory.getPlayer ());
		m_group.pack ();
		return this;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void handlePlayerBet (Player p, double bet)
	{
		m_accum_bet += bet;
		updateAccumBet ();
	}

	/**
	 * {@inheritDoc}
	 */
	public void handlePlayerDrop(Player p, Collection<Card> d)
	{
	}

	/**
	 * {@inheritDoc}
	 */
	public void handlePlayerDropAll(Player p, List<Card> c)
	{
	}

	/**
	 * {@inheritDoc}
	 */
	public void handlePlayerTake(Player p, Card c)
	{
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void handlePlayerUpdateSavings(Player p, double diff)
	{
		m_savings_label.setText ("Savings: " + p.getSavings ());
	}
	
	/**
	 * Resetea el contador de la apuesta acumulada.
	 */
	public void resetBet ()
	{
		m_accum_bet = 0.0;
		updateAccumBet ();
	}
	
	/**
	 * Devuelve el jugador que está visualizando.
	 * @return
	 */
	public Player getPlayer ()
	{
		return m_player;
	}
	
	private void updateAccumBet ()
	{
		m_accum_bet_label.setText ("Bet: " + m_accum_bet);		
	}
	
	private double m_accum_bet = 0.0;
	private Label m_accum_bet_label;
	private Label m_savings_label;
	private Player m_player;
	private Group m_group;
}
