/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.*;

/**
 * Modela el comportamiento elemental de un jugador de poker. Las toma de
 * decisiones las delega en clases derivadas.
 * 
 * @author raskolnikov
 */
public abstract class PokerPlayer extends Player
{
	/**
	 * Construye un jugador de poker.
	 * @param name El nombre del jugador.
	 * @param savings Las ganancias iniciales del jugador.
	 */
	public PokerPlayer (String name, double savings)
	{
		super (name, savings);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public double points ()
	{
		PokerEvaluator eval = new NaivePokerEvaluator (m_cards);
		eval.evaluate ();
		return eval.points ();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void take (Card c)
	{
		m_cards.add (c);
		notifyTake (this, c);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public double bet ()
	{
		double bet = chooseBet ();
		bet = java.lang.Math.min(getSavings (), bet);
		addSavings (-bet);
		notifyBet (this, bet);
		return bet;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public double forceBet (double bet)
	{
		bet = java.lang.Math.min(getSavings (), bet);
		addSavings (-bet);
		notifyBet (this, bet);
		return bet;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Collection<Card> drop ()
	{
		Collection<Card> d = chooseDrop ();
		m_cards.removeAll(d);
		notifyDrop (this, d);
		
		return d;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Card> dropAll ()
	{
		List<Card> d = m_cards;
		m_cards = new Vector<Card> (5);
		notifyDropAll (this, d);
		
		return d;
	}
	
	/**
	 * Elije la apuesta actual.
	 * @return La apuesta actual.
	 */
	public abstract double chooseBet ();
	
	/**
	 * Elije las cartas a devolver en el punto actual.
	 * @return Las cartas a devolver.
	 */
	public abstract Collection<Card> chooseDrop ();
	
	/** Las cartas del jugador. */
	protected Vector<Card> m_cards = new Vector<Card> (5);
}
