/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * La ventana principal del programa.
 * @author raskolnikov
 */
public class MainWindow
{
	/**
	 * Ejecuta el programa del poker.
	 */
	public void run ()
	{
	    Display display = new Display();
	    
	    ImageFactory.setDevice (display);
	    ColorFactory.setDevice (display);
	    
	    m_shell = new Shell (display);
	    m_shell.setLayout (new GridLayout ());
	    
	    m_shell.setMenuBar (buildMenu ());
	    buildLog ();
	    m_game_grid = new LogoTable (m_shell);
	    
	    m_shell.setText ("Gui Poker");
	    m_shell.pack ();
	    m_shell.open ();
	    
	    while (!m_shell.isDisposed () && !m_must_quit) {
	    	if (!display.readAndDispatch ())
	    		display.sleep ();
	    	
	    	if (m_game_grid != null) {
	    		m_game_grid.iterate ();
	    	}
	    }
	    
	    display.dispose();
	}
	
	private Menu buildMenu ()
	{
		Menu menu = new Menu (m_shell, SWT.BAR);
		
	    Menu file_menu = new Menu (menu);
	    
	    /* File menu */
	    MenuItem file_item = new MenuItem (menu, SWT.CASCADE);
	    file_item.setText ("File");
	    file_item.setMenu (file_menu);

	    /* Opciones del menu File */
	    MenuItem new_item = new MenuItem(file_menu, SWT.NONE);
	    new_item.setText("New Game");
	    new MenuItem(file_menu, SWT.SEPARATOR);
	    MenuItem quit_item = new MenuItem(file_menu, SWT.NONE);
	    quit_item.setText("Quit");
	    
	    quit_item.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				m_must_quit = true;
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
	    new_item.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				NewGameDialog win = new NewGameDialog (MainWindow.this.m_shell);
	    				GameInfo gi = (GameInfo) win.open ();
	    				if (gi != null)
	    					MainWindow.this.startNewGame (gi);
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
	    
	    return menu;
	}
	
	private void buildLog ()
	{
		m_log = new Text (m_shell, SWT.MULTI | SWT.READ_ONLY | SWT.BORDER | SWT.V_SCROLL);
		m_log.setText ("Welcome to the paradise of computer poker!\n\n");
		GridData gdata = new GridData (GridData.HORIZONTAL_ALIGN_FILL | 
				  					   GridData.GRAB_HORIZONTAL | 
				  					   GridData.VERTICAL_ALIGN_FILL |
				  					   GridData.GRAB_VERTICAL);
		gdata.heightHint = 60;
		m_log.setLayoutData(gdata);
	}
	
	private void startNewGame (GameInfo gi)
	{
		try {
			if (m_game_grid != null)
				m_game_grid.dispose ();
		
			m_game_grid = new GameView (m_shell, m_log, gi);
			m_shell.pack ();
			m_shell.pack ();
		} catch (Exception e) {
			e.printStackTrace();
			SwtUtils.errorMessage (m_shell, e.toString ());
		}	
	}
	
	private boolean m_must_quit = false;
	private Shell m_shell;
	private Text  m_log;
	private GameTable m_game_grid = null;
}
