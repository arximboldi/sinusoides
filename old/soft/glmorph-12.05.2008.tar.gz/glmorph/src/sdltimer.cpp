/**
 * @file   sdltimer.cpp
 * @author Juan Pedro Bolívar Puente
 * @date   April 2007
 */

#include "sdltimer.h"

using namespace std;

SDLtimer::SDLtimer()
{
	framecount = 0;
    rate = -1;
    rateticks = 1;
    mscount = lastticks = SDL_GetTicks();
    totalms = ms = 0;
}

SDLtimer::SDLtimer(int fpsrate)
{
	framecount = 0;
    rate = fpsrate;
    rateticks = (1000.0 / rate);
    mscount = lastticks = SDL_GetTicks();
    totalms = ms = 0;
}

SDLtimer::~SDLtimer()
{
}

void SDLtimer::update()
{
    Uint32 current_ticks;
    Uint32 target_ticks;
    Uint32 the_delay;
    Uint32 currms;
    
    if (rate > 0) {
        framecount++;
    
        currms = current_ticks = SDL_GetTicks();
        ms = currms - mscount;
        mscount = currms;
        
        target_ticks = lastticks + Uint32(framecount * rateticks);
    
        if (current_ticks <= target_ticks) {
            the_delay = target_ticks - current_ticks;
            SDL_Delay(the_delay);
        } else {
            framecount = 0;
            lastticks = SDL_GetTicks();
        }
    } else { /* Dont limit FPS */
        currms = SDL_GetTicks();
        ms = currms - mscount;
        mscount = currms;
    }
}

void SDLtimer::setFPS(int fpsrate)
{
	framecount = 0;
	rate = fpsrate;
	rateticks = (1000.0 / (float) rate);
}
