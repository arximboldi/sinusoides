--
--  File:       OneWay.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Wed May 25 18:41:48 2011
--  Time-stamp: <2011-06-07 11:13:18 raskolnikov>
--
--  Second script of the Cryptography course held in Universidad de
--  Granada in 2011.
--

module Cryp.OneWay where

import Random
import Data.List (find, mapAccumL, foldl')
import Data.Tuple (swap)
import Data.Bits
import System.IO.Unsafe
import System.Environment (getArgs)
import Data.Binary (encode, decode)
import Data.Maybe
import Control.Arrow (first)

import qualified Data.ByteString.Lazy as B
import qualified Data.ByteString as BS
import qualified Data.ByteString.Base64 as B64

import Cryp.Modular (maybePrimeGen, invMod, expMod, mainI)
import Cryp.Random (bitsToBool, bitsToBool, boolToBits, debug)

-- Hackish random number gen, but ok for our purpose
nextPrime x = fromJust $ find isPrime [x+1 ..]
  where isPrime x = fst $ maybePrimeGen (mkStdGen 1) x 1

bsToBool = concatMap bitsToBool . B.unpack

boolToBs = B.pack . map boolToBits . groupIn 8

groupIn _ [] = []
groupIn n l = take n l : groupIn n (drop n l)

splitBack n xs = go xs (drop n xs) 
  where go as [] = ([], as) 
        go (a:as) (b:bs) = first (a:) $ go as bs

dropBack n = fst . splitBack n
takeBack n = snd . splitBack n

-- Returns (t, s) such that t*2^s and t is odd
powerOfTwoTimesOdd a = until (odd.fst) (\(s, u) -> (s `div` 2, u+1)) (a, 0)

bsToStrict = BS.pack . B.unpack

------------------------------------------------------------------------
--  Exercise 1
------------------------------------------------------------------------

type KnapsackPublicKey  = [Integer]
type KnapsackPrivateKey = ([Integer], Integer, Integer)
type KnapsackKey = (KnapsackPublicKey, KnapsackPrivateKey)

nextSuperInc x = 1 + sum x

superInc [] _ = []
superInc (x:xs) ac = let new = x + ac 
                     in new : superInc xs (ac + new)

-- |
--
-- Generates a random key for a knapsack based encryption system from
-- generator gen. The two parameters are:
--
-- * The number of items in the knapsack 
-- * The maximum number added on each term of the superincreasing
-- sequence.
--

genKnapsackKey :: (RandomGen g) => Int -> Integer -> g -> (KnapsackKey, g)
genKnapsackKey len maxstep gen = ((public, (private, n, u)), gen'')
  where
    (gen', rand1 : rand2 : randoms) = 
      mapAccumL (\g _ -> swap $ randomR (0, maxstep) g) gen [0..len+1]
    
    private    = superInc randoms rand1
    n          = nextPrime (nextSuperInc private + rand2)
    (u, gen'') = randomR (1, n-1) gen'
    public     = map (\a -> (a * u) `mod` n) private

genKnapsackKeyIO len maxstep = do
  gen <- getStdGen
  let (key, gen') = genKnapsackKey len maxstep gen
  setStdGen gen'
  return key

mainKnapsackKey :: IO Int
mainKnapsackKey = do
  args <- getArgs
  if length args /= 2
    then do putStrLn "Usage: knapsack-key len maxstep"
            return 1 
    else do let len     = read (args !! 0)
                maxstep = read (args !! 1)
            (public, private) <- genKnapsackKeyIO len maxstep
            putStrLn ("Public:   " ++ show public)
            putStrLn ("Private:  " ++ show private)
            return 0

enumToNum = fromIntegral . fromEnum

knapsackEncode :: KnapsackPublicKey -> [Bool] -> Integer
knapsackEncode key datum | length key /= length datum = 
  error "Knapsack key and amount of data do not match"
                         | otherwise = sum $ zipWith (*) key $ map enumToNum datum

-- | 
--
-- Because the size of the file might not be a multiplier of the key
-- size, we add any necesary trailing zeroes at the end, and take that
-- into account.
--
knapsackEncodeFile :: KnapsackPublicKey -> B.ByteString -> (Int, [Integer])
knapsackEncodeFile key = mapAccumL encodeChunk 0 . groupIn n . bsToBool
  where 
    n = length key
    encodeChunk ac chunk 
      | length chunk == n = (ac, knapsackEncode key chunk)
      | otherwise = let diff = n - length chunk
                    in (diff, knapsackEncode key (chunk ++ replicate diff False))
                        -- this should be the case of the last chunk only

mainKnapsackEncode :: IO Int
mainKnapsackEncode = do
  args <- getArgs
  if length args /= 1
    then do putStrLn "Usage: knapsack-encode publickey"
            return 1 
    else do let key = read $ head args                
            B.interact (encode . knapsackEncodeFile key) 
            return 0

knapsackDecode :: KnapsackPrivateKey -> Integer -> [Bool]
knapsackDecode (key, n, u) datum = reverse $ go (reverse key) $ datum'
  where
    datum'      = invMod n u * datum `mod` n
    go []     0 = []
    go []     n = error ("Wrong encryption key, excess: " ++ show n)
    go (x:xs) space | x <= space = True : go xs (space - x) 
                    | otherwise  = False : go xs space

knapsackDecodeFile :: KnapsackPrivateKey -> (Int, [Integer]) -> B.ByteString
knapsackDecodeFile key (offst, vals) = 
  boolToBs $ dropBack offst $ concatMap (knapsackDecode key) vals 

mainKnapsackDecode :: IO Int
mainKnapsackDecode = do
  args <- getArgs
  if length args /= 1
    then do putStrLn "Usage: knapsack-decode privatekey"
            return 1 
    else do let key = read $ head args
            B.interact (knapsackDecodeFile key . decode) 
            return 0

------------------------------------------------------------------------
--  Exercise 2
------------------------------------------------------------------------

--
-- Let my id be 48971569, the next prime is 48941573 and a
-- generator \alpha is 2. (Found with gap PrimitiveRootMod, it can be
-- checked that let p_i be all factors of \phi(p),
-- 2^{\frac{\phi(p)}{p_i}} is always non-one).
--
-- Let f (x) = \alpha ^ x, the inverse of my date of birth 19880504,
-- can be computed using the logMod function developed in the first
-- script. This yields f^{-1} (19880504) = 27226319
--

------------------------------------------------------------------------
--  Exercise 3
------------------------------------------------------------------------

-- |
-- Computes the jacobi symbol (a/n)
--

jacobi n 0 = 0
jacobi n 1 = 1
jacobi n a | a1 == 1   = s'
           | otherwise = s' * jacobi a1 n1
  where
    (a1, e) = powerOfTwoTimesOdd a
    s | even e || mod8 == 1 || mod8 == 7 = 1
      | otherwise = -1
        where mod8 = n `mod` 8
    s' | n `mod` 4 == 3  && a1 `mod` 4 == 3 =  -s
       | otherwise = s
    n1 = n `mod` a1

-- |
--
-- Computes the sqrt for of a modulo p, with p prime.
--
-- (Note: we translated the algorithm in [3] $3.34, which is a simpler
-- description of the suggested [1] $2.3.4)
--

primeSqrt :: (Integral a, Bits a) => a -> a -> (a, a)
primeSqrt p a 
  | legendre == -1 = error "No square root" 
  | otherwise      = go 1 r c 
  where
    legendre = jacobi p a -- legendre = jacobi when n is prime
    
    -- this should be random!
    b = fromJust $ find (\b -> jacobi p b == -1) [1 .. p-1]
    (t, s) = powerOfTwoTimesOdd (p - 1)
    
    a' = invMod p a
    c  = expMod p b t
    r  = expMod p a ((t+1) `div` 2)
    
    go i r c | i == s    = (r, p-r) 
             | otherwise = go (i+1) r' c'
      where d = expMod p (r * r * a') (2^(s-i-1) :: Int)
            r' | d == p-1  = r * c `mod` p
               | otherwise = r
            c' = c * c `mod` p

mainPrimeSqrt = mainI 2 calc usage
  where calc (p:a:_) = return $ primeSqrt p a
        usage = "Usage: primesqrt p a"


------------------------------------------------------------------------
--  Exercise 4
------------------------------------------------------------------------
 
factorSqrt :: (Integral a, Bits a) => [a] -> a -> [a]
factorSqrt f a = map solve systems
  where
    -- We could abstract the Gauss CRT algorithm into a different
    -- function but we would be recalculating these coeffs too many
    -- times.
    num = product f
    n   = map (div num) f
    d   = zipWith invMod f n
    
    sqrts = map (`primeSqrt` a) f
    
    -- sequence, for the list monad, does the cartesian product. 
    systems = sequence $ map (\(a, b) -> [a, b]) sqrts
    solve sys = sum (zipWith3 (\a b c -> a*b*c) n d sys) `mod` num
    
mainFactorSqrt :: IO Int
mainFactorSqrt = do
  args <- getArgs
  if length args /= 2
    then do putStrLn "Usage: factorssqrt f a"
            return 1 
    else do let f = read (args !! 0) :: [Integer]
                a = read (args !! 1) :: Integer
                res = factorSqrt f a
            putStrLn ("Result:   " ++ show res)
            return 0

factorSqrt2 f b = factorSqrt f (b*b `mod` product f)

mainFactorSqrt2 :: IO Int
mainFactorSqrt2 = do
  args <- getArgs
  if length args /= 2
    then do putStrLn "Usage: factorssqrt2 f a"
            return 1 
    else do let f = read (args !! 0) :: [Integer]
                a = read (args !! 1) :: Integer
                res = factorSqrt2 f a
            putStrLn ("Result:   " ++ show res)
            return 0
            

------------------------------------------------------------------------
--  Exercise 5
------------------------------------------------------------------------

factorFromRoot :: (Integral a) => a -> a -> a -> (a, a)
factorFromRoot n a b = let p = gcd (a-b `mod` n) n
                           q = n `div` p
                       in (p, q)

mainFactorFromRoot = mainI 3 calc usage
  where calc (n:a:b:_) = return $ factorFromRoot n a b
        usage = "Usage: factorfromroot n a b"

-- Input:  48478872564493742276963 12 37659670402359614687722
-- Result: (159497098847,303948303229)

------------------------------------------------------------------------
--  Exercise 6
------------------------------------------------------------------------

gmrH :: (Integral a) => a -> a -> a -> Bool -> a -> a
gmrH n a0 a1 b x = let a = if b then a0 else a1
                    in x * x * a `mod` n

genGmrH :: (Integral a, Random a, RandomGen g) => 
           a -> g -> (a, a, Bool -> a -> a, g)
genGmrH n g = (a0', a1', gmrH n a0' a1', g'')
  where (a0, g')  = until ((==1) . gcd n . fst) 
                          (randomR (1, n-1) . snd) (n, g)
        (a1, g'') = until (\(a, _) -> a /= a0 && gcd n a == 1) 
                          (randomR (1, n-1) . snd) (a0, g')
        a0' = a0 * a0 `mod` n
        a1' = a1 * a1 `mod` n

genGmrHIO n = do
  gen <- getStdGen
  let (a0, a1, fun, gen') = genGmrH n gen
  setStdGen gen'
  return (a0, a1, fun)

gmrToMd f fb input = f (toEnum $ fromIntegral input) fb

bitsToBool' :: (Bits a) => Int -> a -> [Bool]
bitsToBool' n x = [ testBit x i | i <- [0 .. n-1] ]

mdHash :: (Integral a, Bits a) => (a -> a -> a) -> Int -> Int -> a 
          -> B.ByteString -> B.ByteString
mdHash f m n iv = boolToBs . bitsToBool' n . hash . blocks
  where
    blocks = map boolToBits . groupIn m . bsToBool
    hash   = foldl' f iv

mainGmrHash :: IO Int
mainGmrHash = do
  args <- getArgs
  if length args /= 1 && length args /= 3
    then do putStrLn "Usage: gmrhash nbits [a0 a1]"
            return 1 
    else do let n  = read (args !! 0) :: Int
            let n' = 2^n
            let a0 = read (args !! 1) :: Integer
            let a1 = read (args !! 2) :: Integer 
                
            fun <- if length args == 1
                   then do 
                     (a0, a1, fun) <- genGmrHIO n' 
                     putStrLn ("Generated: " ++ show (a0, a1)) 
                     return fun
                   else return $ gmrH n' a0 a1
            
            B.interact (B.fromChunks . (:[]) . B64.encode . bsToStrict . 
                        mdHash (gmrToMd fun) 1 n 1)
            
            putStrLn ""
            return 0

------------------------------------------------------------------------
--  Exercise 7
------------------------------------------------------------------------

-- Let my id be 48971569, the next prime is p = 48941573 Let my birth
-- date be 19880405 the next prime is q = 19880417. 
-- 
-- \lambda(N = pq) = lcm (p-1) (q-1) = 486788014209270
-- 
-- let e = fromJust $ find ((1==).gcd lam) [2..]
-- e == 7
--
-- let d = invMod lam e
-- d == 347705724435193
--
-- We know that let f(x) = x^e, then f^{-1}(x) = x^d all in Z_n
--
-- f (1234567890) = 898086445615619
-- f^{-1} (898086445615619) = 1234567890
--

exercise7 
  | a' == input = () 
  | otherwise   = error "Something went wrong!"
    where
      p = nextPrime 48971569 :: Integer
      q = nextPrime 19880417 :: Integer
      n = p * q
      
      phi = (p-1) * (q-1)
      lam = lcm (p-1) (q-1)
      
      e = fromJust $ find ((1==).gcd lam) [2..]
      d = invMod lam e
      
      f x = expMod n x e
      f' x = expMod n x d
      
      input = 1234567890
      a = f input
      a' = f' a


------------------------------------------------------------------------
--  Exercise 8
------------------------------------------------------------------------

factorFromRSA n e d 
  | gcd x n /= 1            = (x, n `div` x)
  | abs y == 1 || y == n-1  = error "No solution."
  | otherwise               = (gcd n (z-1), gcd n (z+1))
    where
      (b, a) = powerOfTwoTimesOdd (d * e - 1)
      x      = (n+1) `div` 2
      y      = expMod n x b
      z      = go y (y*y `mod` n)
      go z y | y == n-1 = error "No solution."
             | y == 1   = z
             | otherwise = go y (y*y `mod` n)

mainFactorFromRSA = mainI 3 calc usage
  where calc (n:e:d:_) = return $ factorFromRSA n e d
        usage = "Usage: factorfromroot n e d"

--
-- We know:
-- n = 50000000385000000551
-- e = 5
-- d = 10000000074000000101
-- 
-- Result: (10000000019,5000000029)
-- 

