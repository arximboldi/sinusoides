%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       add_feature.m
%  Time-stamp: <2011-01-29 06:41:31 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Anade una capa coloreada de una feature a una imagen.
%

function img = add_feature (img, feat, color)
    color = double (color);
    feat = double (feat);
    img  = double (img);
    img = cat(3, ...
              uint8 (feat .* color(1) + img), ...
              uint8 (feat .* color(2) + img), ...
              uint8 (feat .* color(3) + img));
end
