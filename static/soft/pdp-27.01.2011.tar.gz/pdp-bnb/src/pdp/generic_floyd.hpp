/**
 *  Time-stamp:  <2011-01-15 16:28:05 raskolnikov>
 *
 *  @file        generic_floyd.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Sun Nov 21 01:25:45 2010
 *
 *  Implementación genérica de floyd.
 */

#ifndef PDP_GENERIC_FLOYD_H_
#define PDP_GENERIC_FLOYD_H_

#include "generic_graph_main.hpp"

namespace pdp
{

/**
 * El algoritmo de floyd lo podemos implementar de forma generica
 * porque sólo cambian el algoritmo de distribución. Al usar
 * plantillas no existe perdida de eficiencia por añadir llamadas
 * vacías, ya que el compilador las evita cuando están vacías.
 */
template <typename DistGraph>
struct generic_floyd_algo
{
    typedef DistGraph dist_graph;
    typedef bool      return_type;
    
    static return_type apply (dist_graph& g)
    {
	for (size_t k = 0; k < g.size (); k++)
	{
	    g.bcast_row (k);
	    g.bcast_col (k);
	    
	    for (size_t i = g.local_row_begin (); i < g.local_row_end (); ++i)
		for (size_t j = g.local_col_begin (); j < g.local_col_end (); j++)
		    g (i, j) = std::min (g (i, j), g (i, k) + g (k, j));
	}

        return true;
    }
};

template <class DistGraph>
int generic_floyd_main (int argc, char** argv)
{
    return generic_graph_main<generic_floyd_algo<DistGraph> > (argc, argv);
}

} /* namespace pdp */

#endif /* PDP_GENERIC_FLOYD_H_ */
