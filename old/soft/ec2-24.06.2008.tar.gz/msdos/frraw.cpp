
#include <iostream>
#include "frraw.h"

using namespace std;

bool FileReaderRaw::open(const char* file)
{
  if (isOpen())
    close();

  m_file.open(file, ios::binary);
  setIsOpen(m_file.is_open());
  m_pos = 0;
  
  return isOpen();
}

void FileReaderRaw::seek(size_t pos)
{
  m_file.seekg(pos);
}

int FileReaderRaw::read(Sample* buf, int n_samples)
{
  int new_pos, n_read;

  m_file.read((char*)buf, n_samples);

  new_pos = m_file.tellg();
  n_read = new_pos - m_pos;
  m_pos = new_pos;

  return n_read;
}

void FileReaderRaw::close()
{
  if (isOpen()) {
    m_file.close();
    setIsOpen(false);
  }
}

