#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade
import gobject
import ConfigParser

from birthday_window import *
from about_window import *
from connect_window import *
from edit_window import *
from gui_tools import *
from member import *
import common
from dao import *

class MainWindow (GladeWindow):
    def __init__(self):
        GladeWindow.__init__ (self, common.GUI_MAIN, 'main-window')
        self.create_tree_view ()
        self._status1 = self.get_widget ('status1')
        self._status1_id = self._status1.get_context_id ('Action status')
        self._status2 = self.get_widget ('status2')
        self._status2_id = self._status2.get_context_id ('Connection status')
        self._status1.push (self._status1_id, '')
        self._status2.push (self._status2_id, '')

    def create_tree_view (self):
        store = gtk.ListStore (int, str, str, str, str, str, str)
        
        tree = self.get_widget ('tree-members')
        tree.set_model (store)
        
        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('#', cellp)
        col.set_attributes (cellp, text=0)
        col.set_sort_column_id (0)
        tree.append_column (col)
        
        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('Surname', cellp)
        col.set_attributes (cellp, text=1)
        col.set_sort_column_id (1)
        tree.append_column (col)
        
        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('Name', cellp)
        col.set_attributes (cellp, text=2)
        col.set_sort_column_id (2)
        tree.append_column (col)

        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('ID', cellp)
        col.set_attributes (cellp, text=3)
        col.set_sort_column_id (3)
        tree.append_column (col)

        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('Join date', cellp)
        col.set_attributes (cellp, text=4)
        col.set_sort_column_id (4)
        tree.append_column (col)
        store.set_sort_func (4, sort_func_date)

        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('Leave date', cellp)
        col.set_attributes (cellp, text=5)
        col.set_sort_column_id (5)
        tree.append_column (col)
        store.set_sort_func (5, sort_func_date)

        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('Birth date', cellp)
        col.set_attributes (cellp, text=6)
        col.set_sort_column_id (6)
        tree.append_column (col)
        store.set_sort_func (6, sort_func_date)

        tree.get_selection ().set_mode (gtk.SELECTION_MULTIPLE)
        tree.set_search_column (1)

        self._tree_store = store
        self._tree_view = tree

    def read_config (self):
        self._cfg = ConfigParser.ConfigParser ()
        self._cfg.add_section ('connection')
        self._cfg.set ('connection', 'host', 'localhost')
        self._cfg.set ('connection', 'user', '')
        self._cfg.set ('connection', 'database', '')

        try:
            self._cfg.readfp (open (common.CONFIG_FILE))
        except Exception, e:
            print "Error, couldn't read config  ", e.strerror
            return
    
    def write_config (self):
        self._cfg.set ('connection', 'user', self._conwin.get_user ())
        self._cfg.set ('connection', 'host', self._conwin.get_host ())
        self._cfg.set ('connection', 'database', self._conwin.get_database ())
        self._cfg.write (open (common.CONFIG_FILE, 'w'))
    
    def do_init (self):
        self.read_config ()

        self._conwin = ConnectWindow (self._cfg.get ('connection', 'user'),
                                      self._cfg.get ('connection', 'host'),
                                      self._cfg.get ('connection', 'database'))

        self._group_one = [
            self.get_widget ('tool-add'),
            self.get_widget ('tool-delete'),
            self.get_widget ('tool-edit'),
            self.get_widget ('tool-refresh'),
            self.get_widget ('tool-birthday'),
            self.get_widget ('menu-edit'),
            self.get_widget ('menu-view'),
            self.get_widget ('menu-disconnect'),
            self.get_widget ('menu-reinstall'),
            self.get_widget ('menu-uninstall'),
            self.get_widget ('tree-container')
            ]
        self._group_two = [
            self.get_widget ('menu-connect')
            ]
        
        self.set_connected (False)
        self.show ()

        pass

    def do_finish (self):
        self.write_config ()
        
    def run (self):
        self.do_init ()
        gtk.main()
        self.do_finish ()
    
    def set_connected (self, con):
        if (con):
            filter (set_sensitive, self._group_one)
            filter (unset_sensitive, self._group_two)
            self.get_widget ('tool-connect').set_stock_id (gtk.STOCK_DISCONNECT)
            self._connected = True
            self._status2.pop (self._status2_id)
            self._status2.push (self._status2_id, 'Connected')
        else:
            filter (unset_sensitive, self._group_one)
            filter (set_sensitive, self._group_two)
            self.get_widget ('tool-connect').set_stock_id (gtk.STOCK_CONNECT)
            self._connected = False
            self._status2.pop (self._status2_id)
            self._status2.push (self._status2_id, 'Not connected')
            self._status1.pop (self._status2_id)
            self._status1.push (self._status1_id, '')

    def handle_connect (self, win):
        if self._connected is False:
            res = gtk.RESPONSE_REJECT
            while res == gtk.RESPONSE_REJECT:
                res = self._conwin.run ()
            self._conwin.hide ()
            if DaoFactoryMgr().is_connected ():
                self.set_connected (True)
                self.do_refresh ()
            
        else:
            DaoFactoryMgr().disconnect ()
            self.set_connected (False)

    def handle_quit (self, win):
        self.destroy ()

    def handle_destroy (self, win):
        gtk.main_quit ()

    def handle_birthday (self, win):
        BirthdayWindow ()

    def handle_about (self, win):
        aboutwin = AboutWindow ()
        aboutwin.run ()
        aboutwin.destroy ()
    
    def handle_reinstall_db (self, win):
        res = show_yesno_dialog ('<b>This operation will delete any previously stored members.</b>\n\nDo you want to continue?')
        if res == gtk.RESPONSE_YES:
            DaoFactoryMgr ().install_db ()
            self.do_refresh ()

    def handle_remove_db (self, win):
        res = show_yesno_dialog ('<b>This operation will delete any previously stored members.</b>\n\nDo you want to continue?')
        if res == gtk.RESPONSE_YES:
            DaoFactoryMgr ().uninstall_db ()
            DaoFactoryMgr ().disconnect ()
            self.set_connected (False)
        
    def do_refresh (self):
        dao = DaoFactoryMgr ().create_member_dao ()
        li = dao.list ()
        self._tree_store.clear ()
        for i in li:
            self._tree_store.append ([i.id, i.surname, i.name, i.nif, 
                                      none_strftime (i.up_date), 
                                      none_strftime (i.down_date), 
                                      none_strftime (i.birth_date)])

    def handle_refresh (self, win):
        self.do_refresh ()

    def do_edit_member (self, member):
        EditWindow (member, self)

    def handle_add_member (self, win):
        self.do_edit_member (None)
            
    def handle_delete_member (self, win):
        try:
            dao = DaoFactoryMgr ().create_member_dao ()
            model, rows = self._tree_view.get_selection().get_selected_rows ()
            refs = []
            for row in rows:
                refs.append (gtk.TreeRowReference (model, row))
            for ref in refs:
                iter = model.get_iter (ref.get_path ())
                id = model.get_value (iter, 0)
                dao.delete (id)
                model.remove (iter)
                            
        except Exception, e:
            show_error_dialog ('Error while deleting', str (e))

    def handle_row_activated (self, win, path, view_column):
        iter = self._tree_store.get_iter (path)
        id = self._tree_store.get_value (iter, 0)
        try:
            dao = DaoFactoryMgr ().create_member_dao ()
            member = dao.find (id)
        except Exception, e:
            show_error_dialog ('Can not edit member', str (e))
        else:
            self.do_edit_member (member)

    def handle_edit_member (self, win):
        dao = DaoFactoryMgr ().create_member_dao ()
        model, rows = self._tree_view.get_selection().get_selected_rows ()
        for row in rows:
            iter = model.get_iter (row)
            id = model.get_value (iter, 0)
            try:
                member = dao.find (id)
            except Exception, e:
                show_error_dialog ('Can not edit member', str (e))
            else:
                self.do_edit_member (member)

    def add_member (self, member):
        self._tree_store.append ([member.id, member.surname, member.name, member.nif,
                                  none_strftime (member.up_date),
                                  none_strftime (member.down_date),
                                  none_strftime (member.birth_date)])        
        self._status1.pop (self._status1_id)
        self._status1.push (self._status1_id, 'Member added')

    def update_member (self, member):
        iter = self._tree_store.get_iter_first ()
        while iter:
            if member.id == self._tree_store.get (iter, 0)[0]:
                self._tree_store.set (iter, 
                                      1, member.surname, 
                                      2, member.name,
                                      3, member.nif,
                                      4, none_strftime (member.up_date),
                                      5, none_strftime (member.down_date),
                                      6, none_strftime (member.birth_date))
            iter = self._tree_store.iter_next (iter)        
        self._status1.pop (self._status1_id)
        self._status1.push (self._status1_id, 'Member edited')

    def delete_member (self, member):
        iter = self._tree_store.get_iter_first ()
        while iter:
            it2 = iter
            iter = self._tree_store.iter_next (iter)
            if member.id == self._tree_store.get (it2, 0)[0]:
                self._tree_store.erase (it2)
        self._status1.pop (self._status1_id)
        self._status1.push (self._status1_id, 'Member deleted')
        
    
