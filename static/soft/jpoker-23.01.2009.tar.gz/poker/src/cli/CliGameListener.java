/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it 
 *  under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package cli;

import java.util.List;

import game.Game;
import game.GameListener;
import game.Player;
import game.PokerGame;

/**
 * Escucha los eventos de un jugador y los visualiza por un flujo de texto.
 * @author raskolnikov
 */
public class CliGameListener implements GameListener 
{
	/**
	 * Constructor. Se usará la salida estándar como stream.
	 */
	public CliGameListener () {}
	
	/**
	 * Constructor que especifica el stream a usar.
	 * @param out El stream a usar.
	 */
	public CliGameListener (CliPrinter out)
	{
		m_out = out;
	}
	
	/**
	 * Maneja el final de una partida.
	 * 
	 * {@inheritDoc}
	 */
	public void handleGameFinish (Game g) 
	{
		PokerGame pg = (PokerGame) g;
		List<Player> alive = pg.getAlivePlayers ();
		
		m_out.println ();
		m_out.println ("** Game finished. Abosolute winner: ");
		for (Player p : alive)
			m_out.print (" " + p.getName() + " (" + p.getSavings () + ")");
		m_out.println ();
		m_out.println ();
	}

	/**
	 * Maneja la unión de un jugador a una partida.
	 * 
	 * {@inheritDoc}
	 */
	public void handleGameJoin (Game g, Player p)
	{
		m_out.println ("** A player joined the game - " + p.getName ());
	}

	/**
	 * Maneja el fin de una ronda de la partida.
	 * 
	 * {@inheritDoc}
	 */
	public void handleGameRound (Game g, List<Player> winner) 
	{
		m_out.print ("** Game round finished with winner:");
		for (Player p : winner)
			m_out.print (" " + p.getName() + " (" + p.points () + ")");
		m_out.println ();
		m_out.println ();
	}
	
	/**
	 * Maneja el abandono de un jugador.
	 * 
	 * {@inheritDoc}
	 */
	public void handleGameLeave (Game g, Player p) 
	{
		m_out.println ("** A player left the game: " + p.getName ());
	}

	/**
	 * Maneja el principio de la partida.
	 * 
	 * {@inheritDoc}
	 */
	public void handleGameStart (Game g)
	{
		m_out.println ();
		m_out.println ("** Game started");
		m_out.println ();
	}

	/** El stream de salida */
	private CliPrinter m_out = new CliStreamPrinter (System.out);
}
