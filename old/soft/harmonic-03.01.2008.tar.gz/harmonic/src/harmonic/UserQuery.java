/*
  HARMONIC - Online music communities system
  ========
    
  Copyright (C) 2008  Juan Pedro Bolivar Puente,
  Luca Mefistofeles Conesa Martin-Aragon

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU Affero General Public License as
  published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Affero General Public License for more details.

  You should have received a copy of the GNU Affero General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic;

import harmonic.gen.*;
import harmonic.dao.*;

import java.util.*;
import java.text.*;

public class UserQuery extends BasicQuery
{
    static public class Factory implements QueryFactory
    {
	public Query create() {
	    return new UserQuery();
	}
    }

    private Generator userProfile(User user, User.Profile prf, QueryHandler hld)
    {
	Division blk = new Division("block");

	blk.addContent(new Header(1, user.nick + " profile"));
	TwoColumn col = new TwoColumn();
	blk.addContent(col);
	col.addLeft(new Header(3, "Avatar"));
	if (prf.avatar_url == null)
	    col.addRight(new Division("default_avatar"));
	else
	    col.addRight(new Image(prf.avatar_url));
	col.addLeft(new Header(3, "Real name"));
	col.addRight(new Text(prf.real_name == null ? "Unknown" : prf.real_name));
	col.addLeft(new Header(3, "Sex"));
	col.addRight(new Text(prf.sex == null ? "Unknown" : prf.sex.equals("M") ? "Male" : "Female"));
	col.addLeft(new Header(3, "Birth date"));
	if (prf.birth_date == null)
	    col.addRight(new Text("Unknown"));
	else {
	    DateFormat df = new SimpleDateFormat("d/M/yyyy");
	    col.addRight(new Text(df.format(prf.birth_date)));
	}
	col.addLeft(new Header(3, "Description"));
	col.addRight(new Text(prf.description == null ? "Unknown" : prf.description));
	col.addLeft(new Header(3, "Homepage"));
	if (prf.homepage_url == null)
	    col.addRight(new Text("Unknown"));
	else
	    col.addRight(new Link(prf.homepage_url, prf.homepage_url));
	
	
	return blk;
    }

    private Generator editUserForm(User user, User.Profile prf)
    {
	Form form = new Form("user");
	form.addContent(new Paragraph("Edit your personal information so other users can now a little bit about you"));
		    
	TwoColumn col = new TwoColumn();
	form.addContent(col);

	col.addLeft(new Text("Nick"));
	col.addRight(new Input("text", "edit_nick", user.nick, 20));
	    
	col.addLeft(new Text("Real name"));
	col.addRight(new Input("text", "edit_real_name", prf.real_name == null ? "" : prf.real_name, 20));

	col.addLeft(new Text("Description"));
	TextAreaInput txtarea = new TextAreaInput("edit_description");
	col.addRight(txtarea);
	if (prf.description != null)
	    txtarea.addContent(new Text(prf.description));
	
	col.addLeft(new Text("Sex"));
	SelectInput sel = new SelectInput("edit_sex");
	sel.addOption("", prf.sex == null).setText("None");
	sel.addOption("M", prf.sex != null && prf.sex.equals("M")).setText("Male");
	sel.addOption("F", prf.sex != null && prf.sex.equals("F")).setText("Female");
	col.addRight(sel);

	col.addLeft(new Text("Birth date"));
	if (prf.birth_date == null)
	    col.addRight(new Input("text", "edit_birth_date", "d/M/yyyy", 20));
	else {
	    DateFormat df = new SimpleDateFormat("d/M/yyyy");
	    String format = df.format(prf.birth_date);
	    col.addRight(new Input("text", "edit_birth_date", format == null ? "d/M/yyyy" : format));
	}
	
	col.addLeft(new Text("Avatar"));
	col.addRight(new Input("text", "edit_avatar_url", prf.avatar_url == null ? "http://" : prf.avatar_url, 20));

	col.addLeft(new Text("Homepage"));
	col.addRight(new Input("text", "edit_homepage_url", prf.homepage_url == null ? "http://" : prf.homepage_url, 20));

	form.addContent(new Input("submit", "submit", "edit"));
	form.addContent(new Input("hidden", "nick", user.nick));
	form.addContent(new Input("hidden", "action", "edit_user"));

	return form;
    }
    
    private Generator editUser(User user, User.Profile prf, QueryHandler hdl)
    {
	Division blk = new Division("block");
	blk.addContent(new Header(1, "Edit user"));

	String session_user = hdl.getUserSession().getID();
	if (session_user == null || !session_user.equals(user.nick)) {
	    blk.addContent(new Division("error", "You are not allowed to perform this action"));
	    return blk;
	}

	if (hdl.getParameter("submit") == null) {
	    blk.addContent(editUserForm(user, prf));
	} else {
	    User.Profile new_prf = new User.Profile();
	    User new_usr = user;
	    String par;

	    par = hdl.getParameter("edit_nick");
	    if (par != null && par.length() > 0)
		new_usr.nick = par;

	    par = hdl.getParameter("edit_real_name");
	    if (par != null && par.length() > 0)
		new_prf.real_name = par;

	    par = hdl.getParameter("edit_description");
	    if (par != null && par.length() > 0)
		new_prf.description = par;

	    par = hdl.getParameter("edit_avatar_url");
	    if (par != null && par.length() > 0 && !par.equals("http://"))
		new_prf.avatar_url = par;

	    par = hdl.getParameter("edit_homepage_url");
	    if (par != null && par.length() > 0 && !par.equals("http://"))
		new_prf.homepage_url = par;

	    par = hdl.getParameter("edit_sex");
	    if (par != null && par.length() > 0)
		new_prf.sex = par;
	    
	    par = hdl.getParameter("edit_birth_date");
	    if (par != null) {
		DateFormat df = new SimpleDateFormat("d/M/yyyy");
		try {
		    new_prf.birth_date = df.parse(par);
		} catch (Exception e) {
		    System.out.println("Error parsing date: " + par);
		}
	    }

	    UserDAO dao = hdl.getDAOFactory().getUserDAO();
	    boolean error = false;
	    try {
		dao.update(new_usr);
		hdl.getUserSession().setID(new_usr.nick);
	    } catch (Exception e) {
		error = true;
		blk.addContent(new Division("error", "There is another user with the same nick."));
	    }

	    try {
		dao.updateProfile(user, new_prf);
	    } catch (Exception e) {
		error = true;
		blk.addContent(new Division("error", "There was an error while updating your profile."));
	    }

	    if (!error)
		blk.addContent(new Paragraph("Your profile has been successfully updated!"));
	    else
		blk.addContent(editUserForm(user, new_prf));
	}
	
	return blk;
    }

    private Generator editPasswordForm(User user)
    {
	Form form = new Form("user");
	form.addContent(new Paragraph("Make sure that your new password is secure."));
	form.addContent(new Paragraph("Type your old password again for security."));
	TwoColumn col = new TwoColumn();
	form.addContent(col);

	col.addLeft(new Paragraph("Old password:"));
	col.addRight(new Input("password", "old_pass", "", 20));

	col.addLeft(new Text("New password:"));
	col.addRight(new Input("password", "new_pass", "", 20));

	col.addLeft(new Text("Repeat new password:"));
	col.addRight(new Input("password", "new_pass_2", "", 20));    

	form.addContent(new Input("submit", "submit", "edit"));
	form.addContent(new Input("hidden", "nick", user.nick));
	form.addContent(new Input("hidden", "action", "edit_password"));

	return form;
    }
    
    private Generator editPassword(User user, User.Profile prf, QueryHandler hdl)
    {
	Division blk = new Division("block");
	blk.addContent(new Header(1, "Change password"));

	String session_user = hdl.getUserSession().getID();
	if (session_user == null || !session_user.equals(user.nick)) {
	    blk.addContent(new Division("error", "You are not allowed to perform this action"));
	    return blk;
	}	

	String submit = hdl.getParameter("submit");

	if (submit == null) {
	    blk.addContent(editPasswordForm(user));
	} else {
	    String old_pass = hdl.getParameter("old_pass");
	    String new_pass = hdl.getParameter("new_pass");
	    String new_pass_2 = hdl.getParameter("new_pass_2");
	    boolean error = false;
	    
	    if (old_pass == null || !old_pass.equals(user.pass_hash)) {
		blk.addContent(new Division("error", "Wrong old password."));
		error = true;
	    }

	    if (new_pass == null || new_pass_2 == null || !new_pass.equals(new_pass_2)) {
		blk.addContent(new Division("error", "The new passwords do not match."));
		error = true;
	    }

	    if (!error) {
		user.pass_hash = new_pass;
		try {
		    UserDAO dao = hdl.getDAOFactory().getUserDAO();
		    dao.update(user);
		} catch (Exception e) {
		    blk.addContent(new Division("error", "Error while changing password."));
		    error = true;
		}
	    }

	    if (error)
		blk.addContent(editPasswordForm(user));
	    else
		blk.addContent(new Paragraph("Your password has been changed succesfully!"));
	}
	
	return blk;
    }

    private Generator deleteUserForm(User user)
    {
	Form form = new Form("user");
	form.addContent(new Paragraph("Note that deleting your account will erase all your information from our server and your charts and any other data will not be recuperable."));
	form.addContent(new Paragraph("Type your password again for security."));

	TwoColumn col = new TwoColumn();
	form.addContent(col);

	col.addLeft(new Paragraph("Password:"));
	col.addRight(new Input("password", "password", "", 20));

	form.addContent(new Input("submit", "submit", "yes, delete"));
	form.addContent(new Input("hidden", "nick", user.nick));
	form.addContent(new Input("hidden", "action", "delete"));

	return form;	
    }
    
    private Generator deleteUser(User user, User.Profile prf, QueryHandler hdl)
    {
	Division blk = new Division("block");
	blk.addContent(new Header(1, "Delete user"));

	String session_user = hdl.getUserSession().getID();
	if (session_user == null || !session_user.equals(user.nick)) {
	    blk.addContent(new Division("error", "You are not allowed to perform this action"));
	    return blk;
	}	

	String submit = hdl.getParameter("submit");
	if (submit == null) {
	    blk.addContent(deleteUserForm(user));
	} else {
	    String pass = hdl.getParameter("password");
	    boolean error = false;
	    if (pass == null || !pass.equals(user.pass_hash)) {
		blk.addContent(new Division("error", "Wrong password."));
		error = true;
	    } else {
		try {
		    hdl.getDAOFactory().getUserDAO().delete(user);
		    hdl.getUserSession().finish();
		} catch (Exception e) {
		    blk.addContent(new Division("error", "Error while deleting user."));
		    error = true;
		}
	    }
	    
	    if (!error)
		blk.addContent(new Paragraph("Your account has been successfully deleted."));
	    else
		blk.addContent(deleteUserForm(user));
	}

	return blk;
    }
    
    public Page execute(QueryHandler hdl)
    {
	String user_query = hdl.getParameter("nick");
	UserDAO dao = hdl.getDAOFactory().getUserDAO();
	User user;
	User.Profile prf;
	    
	Page result = super.execute(hdl);
	
	user = dao.find(user_query);
	prf = dao.profile(user);

	if (user == null || prf == null) {
	    result.getContent().addContent(new Division("error", "Could not find user: " + user_query));
	    return result;
	}
	
	String action = hdl.getParameter("action");
	if (action == null) {
	    result.getContent().addContent(userProfile(user, prf, hdl));
	} else if (action.equals("edit_user")) {
	    result.getContent().addContent(editUser(user, prf, hdl));
	} else if (action.equals("edit_password")) {
	    result.getContent().addContent(editPassword(user, prf, hdl));
	} else if (action.equals("delete")){
	    result.getContent().addContent(deleteUser(user, prf, hdl));
	}
	
	return result;
    }
}
