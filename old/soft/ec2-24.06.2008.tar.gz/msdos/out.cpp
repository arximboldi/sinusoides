
#include "out.h"

bool Output::gotoState(State target)
{
  if (target > m_state) {
    switch(m_state) {
    case NOTINIT:
      return open() && gotoState(target);
    case IDLE:
      return start() && gotoState(target);
    default:
      break;
    }
  }
	
  if (target < m_state) {
    switch(m_state) {
    case IDLE:
      return close() && gotoState(target);
    case RUNNING:
      return stop() && gotoState(target);
    default:
      break;
    }
  }
  
  return true;
}
