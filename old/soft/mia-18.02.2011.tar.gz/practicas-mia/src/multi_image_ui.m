%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  (c) 2010-2011 Juan Pedro Bolívar Puente
%  
%  Time-stamp: <2011-01-29 08:22:02 raskolnikov>
%  Autor:      Juan Pedro Bolívar Puente
%  File:       multi_image_ui.m
%
%  Este fichero contiene la interfaz gráfica. Como este fichero se
%  modifica automáticamente por GUIDE, intentamos delegar la
%  implementación a gui.m.
%

classdef multi_image_ui < handle

    properties
        handles;
        color_level;
        color_map;
        images;
        img_axes;
        colorbar;
        profile_plot_fn;
        profile_row;
        profile_mode;
        op_count;
        color;
    end
    
    methods
        function self = multi_image_ui (handles)
            self.handles = handles;
            
            self.color_level = 256;
            self.color_map   ='Gray';
            
            self.op_count = [0, 0, 0];
            self.images   = cell (1, 3);
            for idx = 1:3
                self.images {idx} = null_result;
            end
            self.img_axes = [ handles.axes1, handles.axes2, handles.axes3 ];
            self.colorbar = [ 0 0 0 ];
            
            self.profile_plot_fn = @plot;
            self.profile_row = 0;
            self.profile_mode = 0;
            
            self.color = [ 1 0 0 ];
        end
        
        function apply_one_image_operation(self, operation)
            src_idx = self.src_image_idx ();
            src_data = self.images {src_idx}.get_data ();
            result = operation (src_data);
            if ~isobject (result)
                result = image_result (result);
            end
            if ~result.isempty ()
                self.images {src_idx} = result;
                self.update_image (src_idx);
            end
        end
        
        function apply_two_image_operation(self, operation)
            src_idx = self.src_image_idx ();
            dst_idx = self.dst_image_idx ();
            
            if isempty (self.images {src_idx})
                errordlg ('You must enter an image in the source axes!', ...
                          'Bad Input', 'modal');
                return
            end
            
            src_data = self.images {src_idx}.get_data ();
            result = operation (src_data);
            if ~isobject (result)
                result = image_result (result);
            end
            if ~result.isempty ()
                self.images {dst_idx} = result;
                self.update_image (dst_idx);
            end
        end
        
        function apply_binary_image_operation(self, operation)
            src_idx = self.src_image_idx ();
            dst_idx = self.dst_image_idx ();
            third_idx = self.third_image_idx ();
            
            if src_idx == dst_idx
                errordlg ('Source and dest axes must be different!', ...
                          'Bad Input', 'modal');
                return
            end                
            
            if isempty (self.images {src_idx})
                errordlg ('You must enter an image in the source axes!', ...
                          'Bad Input', 'modal');
                return
            end
            
            if isempty (self.images {dst_idx})
                errordlg ('You must enter an image in the destiny axes!', ...
                          'Bad Input', 'modal');
                return
            end
            
            src_data = self.images {src_idx}.get_data ();
            dst_data = self.images {dst_idx}.get_data ();
            result   = operation (src_data, dst_data);
            if ~isobject (result)
                result = image_result (result);
            end
            if ~result.isempty
                self.images {third_idx} = result;
                self.update_image (third_idx); 
            end
        end
        
        function update_image (self, img_id)
            img  = self.images {img_id};
            data = img.get_data ();
            tam  = size (data);
            mini = round (min (min (data)));
            maxi = round (max (max (data)));
            
            switch img_id
              case 1
                set(self.handles.radio_img_a, ...
                    'String', strcat('Image A: ',...
                                     num2str(tam(2)), ' x ', num2str(tam(1)), ...
                                     ' [', num2str(mini), ', ', num2str(maxi),']'));
              case 2
                set(self.handles.radio_img_b, ...
                    'String', strcat('Image B: ',...
                                     num2str(tam(2)), ' x ', num2str(tam(1)), ...
                                     ' [', num2str(mini), ', ', num2str(maxi),']'));
              case 3
                set(self.handles.radio_img_c, ...
                    'String', strcat('Image C: ',...
                                     num2str(tam(2)), ' x ', num2str(tam(1)), ...
                                     ' [', num2str(mini), ', ', num2str(maxi),']'));
              otherwise
            end

            if self.profile_mode
                self.draw_profile (img_id);
            else
                self.draw_image (img_id);
            end
            
            self.op_count (img_id) = self.op_count (img_id) + 1;
        end
        
        function idx = dst_image_idx (self)
            switch get (self.handles.popup_dest, 'Value')
              case 1
                idx = self.src_image_idx ();
              case 2
                idx = mod (self.src_image_idx (),  3) + 1;
              otherwise
                idx = get (self.handles.popup_dest, 'Value') - 2;
            end
        end            
        
        function img = dst_image (self)
            img = self.images {self.dst_image_idx ()};
        end
        
        function idx = src_image_idx (self)
            tag = get (get (self.handles.group_image, 'SelectedObject'), 'Tag');
            switch tag
              case 'radio_img_a'
                idx = 1;
              case 'radio_img_b'
                idx = 2;
              case 'radio_img_c'
                idx = 3;
              otherwise
            end
        end            
        
        function img = src_image (self)
            img = self.images {self.src_image_idx ()};
        end

        function idx = third_image_idx (self)
            switch self.src_image_idx () + self.dst_image_idx ()
              case 1
                idx = 1;
              case 2
                idx = 2; % No se da
              case 3
                idx = 3;
              case 4
                idx = 2;
              case 5
                idx = 1;
              case 6
                idx = 3;
            end
        end
        
        function img = third_image (self)
            img = self.images {self.third_image_idx ()};
        end
        
        function toggle_colorbar (self)
            imgid = self.src_image_idx ();
            axes (self.img_axes (imgid));
            if self.colorbar (imgid)    
                colorbar ('off');
            else
                colorbar;
            end
            self.colorbar (imgid) = ~self.colorbar (imgid);
        end
        
        function draw_profile (self, idx)
            img = self.images {idx};
            if ~img.isempty ()
                axes (self.img_axes (idx));
                img.display_profile (self.profile_plot_fn, self.profile_row, ...
                                     self.color);
            end
        end

        function draw_image (self, idx)
            img = self.images {idx};
            if ~img.isempty ()
                axes (self.img_axes (idx));
                img.display (self.color_map, self.color);
            end
        end
        
        function update_all_images (self)
            for idx = 1:3
                self.update_image (idx);
            end
        end
        
        function toggle_profile_mode (self)
            self.profile_mode = ~self.profile_mode;
            self.update_all_images ();
        end
        
        function set_profile_plot_fn (self, fn)
            self.profile_plot_fn = fn;
            if self.profile_mode
                self.update_all_images ();
            end
        end
        
        function set_profile_row (self, row)
            self.profile_row = row;
            if self.profile_mode
                self.update_all_images ();
            end
        end
        
        function set_color (self, color)
            self.color = color;
            self.update_all_images ();
        end
        
        function set_mode_for (self, type, mode)
            for idx = 1:3
                img = self.images {idx};
                if strcmp (img.result_type, type)
                    img.mode = mode;
                    self.update_image (idx);
                end
            end
        end
    end
end
