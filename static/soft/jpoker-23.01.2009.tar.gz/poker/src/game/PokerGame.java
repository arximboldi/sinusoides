/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.*;

/**
 * Clase que implementa una partda de poker.
 * @author raskolnikov
 */
public class PokerGame extends Game 
{
	/**
	 * Distintos estados en los que puede estar la partida de poker. El estado
	 * indica lo que se está haciendo en esta ronda.
	 * 
	 * @author raskolnikov
	 */
	public enum State
	{
		GIVE_CARDS, /**< Entrega inicial de cartas. */
		FIRST_BET,  /**< Primera ronda de apuestas. */
		DROP_CARDS, /**< Cambio de cartas. */
		SECOND_BET, /**< Segunda ronda de apuestas. */
		RESULTS     /**< Devolucion de cartas y computo del resultado. */
	}
	
	/**
	 * Constructor.
	 */
	public PokerGame () {}
	
	/**
	 * Construye una partida de poker indicando la apuesta inicial.
	 * @param start_bet Apuesta inicial.
	 */
	public PokerGame (double start_bet)
	{
		m_start_bet = start_bet;
	}
	
	/**
	 * Un jugador se une a la partida. Notar que el máximo de jugadores es 5.
	 */
	@Override
	public void join(Player p) throws GameException
	{
		super.join (p);
		
		if (m_players.size () == 5)
			throw new GameException ("maximum number of players 5 reached");
		
		m_players.add (new PlayerHolder(p, 0.0));
		notifyJoin (this, p);
	}
	
	/**
	 * Se juega una ronda de la partida.
	 */
	@Override
	public boolean playRound () throws GameException
	{
		boolean finished = false;
		
		super.playRound ();
		
		switch (m_state) {
		case GIVE_CARDS:
			giveCardsRound ();
			break;
			
		case FIRST_BET:
			betRound (State.DROP_CARDS);
			break;
			
		case DROP_CARDS:
			dropCardsRound ();
			break;
			
		case SECOND_BET:
			betRound (State.RESULTS);
			break;
			
		case RESULTS:
			finished = resultsRound ();
			break;
		}
		
		return finished;
	}
	
	/**
	 * Se juega una ronda de entrega de cartas.
	 */
	private void giveCardsRound ()
	{
		m_cards = PokerDeck.getInstance ().create ();
		m_cards.shuffle ();
		
		m_num_fold = 0;
		m_pot = 0.0;
		
		for (PlayerHolder p : m_players) {
			if (!p.isLooser ()) {
				for (int i = 0; i < 5; ++i)
					p.player.take (m_cards.takeTop ());
				p.fold = false;
			}
			p.all_in = false;
		}
		
		m_state = State.FIRST_BET;
		
		startBets ();		
	}

	/**
	 * Se prepara una ronda de apuestas.
	 */
	private void startBets () 
	{
		m_can_check = true;
		m_min_bet = m_start_bet;
		
		m_num_fold = 0;
		for (PlayerHolder p : m_players) {
			if (!p.isLooser () && !p.fold) {
				p.bet = p.player.forceBet (m_start_bet);
				m_pot += p.bet;
			} else {
				p.bet = 0.0;
				++ m_num_fold;
			}
		}
	}

	/**
	 * Se ejecuta una ronda de apuestas.
	 * 
	 * @param next_state
	 *            El estado que habrá despues de las apuestas.
	 * @throws GameException
	 *             Un jugador ha violado las reglas del juego con alguna
	 *             apuesta, normalmente apostando menos de la apuesta mínima.
	 */
	private void betRound (State next_state) 
		throws GameException
	{
		int n_check_call = 0;
		double bet;
		
		for (PlayerHolder p : m_players) {
			if (p.canBet ()) {
				m_curr_min_bet = m_min_bet - p.bet;
				bet = p.player.bet ();
				
				if (bet == 0.0 && !m_can_check) {         /* fold */
					p.fold = true;
					++ m_num_fold;
				}
				else if (bet == 0.0 && m_can_check)       /* check */
					++ n_check_call;
				else if (bet >= m_curr_min_bet) {         /* legal bet */
					m_can_check = false;
					if (bet == m_curr_min_bet)            /* call else raise */
						++ n_check_call;
				}
				else if (p.player.getSavings () == 0.0) { /* all-in */
					p.all_in = true;
					++ m_num_fold;
				} 
				else throw new PokerRuleException (m_state, 
						"player must bet the minimum bet or all-in");
				
				p.bet += bet;
				m_pot += bet;
				
				if (m_min_bet < p.bet)
					m_min_bet = p.bet;
			}
		}
		
		if (m_num_fold + n_check_call + 1 >= m_players.size ())
			m_state = next_state;
	}
	
	/**
	 * Ronda de devolución de cartas.
	 * @throws GameException
	 */
	private void dropCardsRound () throws GameException
	{
		for (PlayerHolder p : m_players) {
			if (!p.fold) {
				Collection<Card> drop = p.player.drop ();
				if (drop.size () > 4)
					throw new PokerRuleException (m_state, 
							"a player can not drop more than 4 cards");
				for (int i = 0; i < drop.size (); ++i)
					p.player.take (m_cards.takeTop ());
			}
		}
		
		startBets ();
		m_state = State.SECOND_BET;
	}
	
	/**
	 * Ronda de resultados.
	 * @return Si ha terminado o no la partida al no quedar jugadores vivos.
	 * @throws GameException Si algun jugador viola las leyes del poker.
	 */
	private boolean resultsRound () throws GameException
	{
		List<Player> round_winner = new LinkedList<Player> ();
		double win_points = 0;
		double cur_points;
		int n_bankrupt = 0;
		
		for (PlayerHolder p : m_players) {
			if ((!p.isLooser () || p.all_in) && !p.fold) {
				cur_points = p.player.points ();
				if (cur_points > win_points) {
					round_winner.clear ();
					win_points = cur_points;
				}
				if (cur_points == win_points)
					round_winner.add (p.player);
			}
		}
		
		for (Player p : round_winner)
			p.addSavings (m_pot / round_winner.size ());
		
		notifyRound (this, round_winner);
		m_state = State.GIVE_CARDS;
		
		for (PlayerHolder p : m_players) {
			if (p.isLooser ())
				++ n_bankrupt;
			if (p.player.dropAll ().size () != 5 && !p.isLooser ())
				throw new PokerRuleException (m_state,
						"a player must return all his cards after a match");
		}
				
		if (n_bankrupt + 1 >= m_players.size ()) {
			notifyFinish (this);
			return true;
		}
		
		return false;
	}
	
	/**
	 * Comienzo de la partida.
	 */
	@Override
	public void start () throws GameException 
	{
		super.start ();
		
		if (m_players.size() < 2)
			throw new GameException ("Less than two players can not play");
		
		for (PlayerHolder p : m_players)
			p.bet = 0;
		
		notifyStart (this);
	}

	/**
	 * Devuelve lo mínimo que debe apostar un jugador en el punto actual de la
	 * partida.
	 */
	public double getMinBet ()
	{
		return m_curr_min_bet;
	}
	
	/**
	 * Devuelve el estado actual del juego.
	 * @return El estado del juego.
	 */
	public State getState ()
	{
		return m_state;
	}
	
	/**
	 * Establece la apuesta inicial.
	 * @param start_bet
	 */
	public void setStartBet (double start_bet)
	{
		m_start_bet = start_bet;
	}
	
	/**
	 * Devuelve la apuesta inicial.
	 * @return La apuesta inicial.
	 */
	public double getStartBet () 
	{
		return m_start_bet;
	}
	
	/**
	 * Devuelve el bote actual.
	 * @return El bote actual.
	 */
	public double getPot ()
	{
		return m_pot;
	}
	
	/**
	 * Crea una lista con los jugadores que siguen vivos en la partida.
	 * @return La lista de los jugadores.
	 */
	public List<Player> getAlivePlayers() 
	{
		LinkedList<Player> l = new LinkedList<Player> ();
		
		for (PlayerHolder p : m_players)
			if (!p.isLooser())
				l.add(p.player);
		
		return l;
	}
	
	/**
	 * Clase utilitaria para guardar la información de un jugador.
	 * @author raskolnikov
	 */
	private class PlayerHolder
	{
		public Player player; /**< El jugador */
		public double  bet;   /**< Su apuesta acumulada. */
		public boolean fold   = false; /**< Ha hecho un fold esta ronda? */
		public boolean all_in = false; /**< Ha hecho un all-in esta ronda? */
		
		/**
		 * Constructor.
		 */
		PlayerHolder (Player p, double b)
		{
			player = p;
			bet = b;
		}
		
		/**
		 * Ha perdido?
		 * @return Devulve true sii ha perdido la partida.
		 */
		private boolean isLooser () 
		{
			return player.getSavings () < m_start_bet;
		}
		
		/**
		 * Puede apostar?
		 * @return Devuelve true sii el jugador puede seguir apostando.
		 */
		private boolean canBet ()
		{
			return !fold && !all_in;
		}
	}
	
	/** Los jugadores */
	private LinkedList<PlayerHolder> m_players = new LinkedList<PlayerHolder>();
	
	private int m_num_fold = 0;
	private boolean m_can_check = false;
	private double m_min_bet = 0.0;
	private double m_curr_min_bet = 0.0;
	private double m_start_bet = 10.0;
	private double m_pot = 0.0;
	
	private CardPile m_cards = null;
	private State m_state = State.GIVE_CARDS;
}
