%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       noise_salt_pepper.m
%  Time-stamp: <2011-01-23 22:50:45 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Rudio de sal y pimienta.
%

function img = noise_salt_pepper (img, salt, pepper)
    q  = 1 - pepper;
    p  = q - salt;
    pt = rand (size (img));
    img (find (pt >= p & pt <= q)) = 255;
    img (find (pt >  q & pt <= 1)) = 0;
end

