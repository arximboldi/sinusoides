#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

from dao import *
from mysql_dao import *
from main_window import *

class Program:
    def register_factories (self):
        mgr = DaoFactoryMgr ()
        mgr.register ("mysql", MysqlDaoFactory ())
        mgr.default ("mysql")
    
    def run (self):
        self.register_factories ()
        dao = DaoFactoryMgr ().create_member_dao ()
        window = MainWindow ()
        window.run ()
        return 0

