%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  (c) 2010-2011 Juan Pedro Bolívar Puente
%
%  Time-stamp: <2011-01-23 05:57:51 raskolnikov>
%  Autor:      Juan Pedro Bolívar Puente
%  File:       load_as_gray.m
%
%  La verdad es que esta función la podríamos haber definido
%  directamente en main.m, pero resulta que matlab es muy gracioso
%  y no permite hacer un cierre si todas las funciones no terminan
%  en end, y generosamente guide decide no terminar en end sus
%  funciones autogeneradas... ¬¬
%

function outimg = resize_image (inimg, arg, factor, newsize, interp)
    tam = size (inimg);
    
    % TODO: Usar 'radio_...' es exponer la interfaz, deberían
    % usarse otros nombres aquí en pro de la genericidad.
    switch arg
      case 'radio_res_change_factor'
        outimg = imresize (inimg, factor, interp);
      case 'radio_res_change_size'
        outimg = imresize (inimg, newsize, interp);
      otherwise
    end
end
