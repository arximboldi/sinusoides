%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       compute_snr.m
%  Time-stamp: <2011-01-24 02:19:19 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Computar el SNR de dos imágenes.
%

function snr = compute_snr (imga, imgb)
    if size (imga) ~= size (imgb)
        errordlg(['Images must have the same size in order to calculate ' ...
                  'the SNR.'], 'Bad Input','modal');
        mse = NaN;
    else
        imga = double (imga);
        imgb = double (imgb);
        mean = mean2 (imga);
        aux  = imga - mean;
        num  = norm (aux (:))^2;
        aux  = imga - imgb;
        den  = norm (aux (:))^2;
        snr  = 10 * log10 (num / den);
    end
end
