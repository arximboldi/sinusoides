#!/bin/bash

echo "auto_update 0"

SIDES=3
while true
do
    while [ "x$SIDES" != "x20" ]
    do
	echo "clear"
#	echo "line 320 240 0 $SIDES"
	echo "regular 320 240 200 $SIDES 0"
	echo "update"
	echo "sleep 100"
	let SIDES+=1
    done
    while [ "x$SIDES" != "x3" ]
    do
	echo "clear"
#	echo "line 320 240 0 $SIDES"
	echo "regular 320 240 200 $SIDES 0"
	echo "update"
	echo "sleep 100"
	let SIDES-=1
    done
done
