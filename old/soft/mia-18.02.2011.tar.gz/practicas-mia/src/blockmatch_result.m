%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       blockmatch_result.m
%  Time-stamp: <2011-01-29 08:17:41 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Resultado de un block_match.
%


classdef blockmatch_result < image_result_base
    properties
        offset; blocksize; comp; img1; img2; mode; color
    end
    
    methods
        function self = blockmatch_result (offset, blocksize, img1, img2, mode)
            self.offset = offset;
            self.blocksize = blocksize;
            self.img1 = img1;
            self.img2 = img2;
            self.mode = mode;
            
            movx = real (offset);
            movy = imag (offset);
            [rows, cols] = size (img1);
            self.comp = zeros (rows, cols);
            for i = 1:rows
                for j=1:cols
                    self.comp(i,j) = img2(i + movx(i,j), j + movy(i,j));
                end
            end
        end
        
        function type = result_type (self)
            type = 'blockmatch';
        end
        
        function display (self, color_mode, color)
            self.color = color;
            display @ image_result_base (self, color_mode, color);
            
            if self.mode == 1
                [rows, cols] = size (self.img2);
                bs = self.blocksize;
                
                subsampled = self.offset (1:bs:rows, 1:bs:cols); 
                [x y] = meshgrid (1:bs:cols, 1:bs:rows);
                hold on;
                quiver(x, y, imag (subsampled), real (subsampled), 'y', ...
                       'Color', color);
                hold off;
            end
        end
        
        function img = get_data (self)
            switch self.mode
              case 1
                img = self.img2;
              case 2
                img = self.img1 - self.img2;
              case 3
                img = self.comp;
              case 4
                img = double (self.img1) - double (self.comp);
            end
        end
    end
end

