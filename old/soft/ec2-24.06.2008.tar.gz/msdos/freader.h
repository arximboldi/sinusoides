
#ifndef FILEREADER_H
#define FILEREADER_H

#include "types.h"

class FileReader
{
    bool m_isopen;
       
protected:
    void setIsOpen(bool isopen) {
	m_isopen = isopen;
    };
    
public:
    FileReader() :
	m_isopen(false)
	  {}
	    
    virtual ~FileReader() {};
    
    bool isOpen() {
	return m_isopen;
    }
    
    virtual bool open(const char* file) = 0;
    virtual void seek(size_t pos) = 0;
    virtual int read(Sample* buf, int n_samples) = 0;
    virtual void close() = 0;
};

#endif /* FILEREADER_H */
