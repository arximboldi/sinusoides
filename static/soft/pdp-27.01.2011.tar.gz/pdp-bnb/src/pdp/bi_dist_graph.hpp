/**
 *  Time-stamp:  <2010-11-26 17:09:18 raskolnikov>
 *
 *  @file        bi_dist_graph.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Sat Nov 20 23:27:54 2010
 *
 *  Distribucion bidimensional.
 */

#ifndef PDP_BI_DIST_GRAPH_H_
#define PDP_BI_DIST_GRAPH_H_

#include <cmath>
#include "graph.hpp"

namespace pdp
{

/**
 * Similar a uni_dist_graph, pero realiza una distribución
 * bidimensional tal y como se explica en el guión.
 */
template <typename Label>
class bi_dist_graph : public detail::graph_base<Label>
{
public:
    bi_dist_graph ()
    { reset (); }

    bi_dist_graph (MPI::Intracomm& comm, graph<Label>& g, int root)
    { scatter (comm, g, root); }

    ~bi_dist_graph ()
    { gather (); _free (); }
    
    void scatter (MPI::Intracomm& com, graph<Label>& g, int root);
    
    void bcast_row (size_t row);

    void bcast_col (size_t col);
    
    void gather (int root = -1);
        
    /**
     * Resetea la distribución unidimensional. Esto evita que se
     * ejecute que se reconstruya la distribución en el destructor.
     */
    void reset ()
    {
	_comm = 0;
	_comm_row = MPI::COMM_NULL;
	_comm_col = MPI::COMM_NULL;
	_comm_col_color = 0;
	_comm_row_color = 0;
	_type_square = MPI::INT;
	_type_column = MPI::INT;
	_data = 0;
	_size = 0;
	_local_row_begin = _local_row_end = 0;
	_local_col_begin = _local_col_end = 0;
    }
    
    /**
     * Devuelve la primera fila almacenada localmente. No cuenta las
     * distrbuidas manualmente con bcast.
     */
    size_t local_row_begin () const
    { return _local_row_begin; }

    /**
     * Devuelve la ultima fila almacenada localmente.
     */
    size_t local_row_end () const
    { return _local_row_end; }

    /**
     * Devuelve la primera fila almacenada localmente. No cuenta las
     * distrbuidas manualmente con bcast.
     */
    size_t local_col_begin () const
    { return _local_col_begin; }

    /**
     * Devuelve la ultima fila almacenada localmente.
     */
    size_t local_col_end () const
    { return _local_col_end; }
    
private:
    void _free ();
    
    void _check (MPI::Intracomm& comm, graph<Label>& g);

    void _local_range (MPI::Intracomm& comm,
		       size_t& row_begin, size_t& row_end,
		       size_t& col_begin, size_t& col_end)
    {
	int size      = comm.Get_size ();
	int size_sqrt = std::sqrt (size);
	int side      = _size / size_sqrt;

	int rank  = comm.Get_rank ();
	int row_p = rank / size_sqrt;
	int col_p = rank % size_sqrt;

	col_begin = col_p * side;
	col_end   = col_begin + side;
	row_begin = row_p * side;
	row_end   = row_begin + side;
    }
    
    MPI::Intracomm* _comm;

    MPI::Intracomm  _comm_row;
    MPI::Intracomm  _comm_col;
    int             _comm_row_color;
    int             _comm_col_color;

    MPI::Datatype   _type_square;
    MPI::Datatype   _type_column;
    
    int        _default_root;
    size_t     _local_row_begin;
    size_t     _local_row_end;
    size_t     _local_col_begin;
    size_t     _local_col_end;

    using detail::graph_base<Label>::_data;
    using detail::graph_base<Label>::_size;
};

} /* namespace pdp */

#include "bi_dist_graph.tpp"

#endif /* PDP_BI_DIST_GRAPH_H_ */
