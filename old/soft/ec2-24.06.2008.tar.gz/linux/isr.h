/*
 * Driver de sonido para Linux 2.6
 *
 * Autores:
 *   Juan Pedro Bolívar Puente
 *   Francisco Manuel Herrero Pérez
 */

#ifndef ISR_H
#define ISR_H

#include <linux/kernel.h>

asmlinkage long
get_interrupt_gate (long n);

asmlinkage void
set_interrupt_gate (long n, long addr);

#define DECLARE_ISR_HANDLER(isrfunc)		\
  asmlinkage void _isr_handler_ ##isrfunc (void);

#define DEFINE_ISR_HANDLER(isrfunc, oldisrfunc)	\
  asmlinkage void _isr_handler_ ##isrfunc (void)		\
  {							\
    __asm__ __volatile__				\
      (							\
       "pushal \n\t"					\
       "call " #isrfunc "\n\t"				\
       "cmpl $1, %eax \n\t"				\
       "je _call_old_clkisr \n\t"			\
       "movb $0x20, %al \n\t"				\
       "outb %al, $0x20 \n\t"				\
       "popal \n\t"					\
       "iret \n\t"					\
       "_call_old_clkisr: popal \n\t"			\
       "jmpl " #oldisrfunc "\n\t"			\
							);	\
  }
  
#define GET_ISR_HANDLER(isrfunc)		\
  (_isr_handler_ ## isrfunc)


#endif /* ISR_H */
