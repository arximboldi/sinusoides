/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic;

import harmonic.gen.*;
import harmonic.dao.*;

public class LoginQuery extends BasicQuery
{
    static public class Factory implements QueryFactory
    {
	public Query create() {
	    return new LoginQuery();
	}
    }

    boolean checkLogin(QueryHandler hdl, String id, String pass)
    {
	UserDAO dao = hdl.getDAOFactory().getUserDAO();
	User user = dao.find(id);
	
	if (user == null ||
	    !pass.equals(user.pass_hash) ||
	    user.confirm_code != null)
	    return false;

	return true;
    }

    Division loginErrorPage()
    {
	Division div = new Division("error", "The user could not be logged into the system. " +
				     "Please make sure that the user exists and the password is correct.");
	return div;
    }

    Division loginDefaultPage(QueryHandler hdl)
    {
	Division div = new Division("block");
	UserSession session = hdl.getUserSession();
	String user_id = hdl.getUserSession().getID();

	if (user_id == null) {
	    div.addContent(new Header(1, "Login"));

	    Form form = new Form("login");
	    div.addContent(form);
	    Input in;
	    form.addContent(new Text("User: "));
	    in = new Input("user", "user_id");
	    in.setSize(14);
	    form.addContent(in);
	    form.addContent(new Break());
	    form.addContent(new Text("Pass: "));
	    in = new Input("password", "user_pass");
	    in.setSize(14);
	    form.addContent(in);
	    form.addContent(new Break());
	    form.addContent(new Input("submit", "action", "login"));
	    div.addContent(new Link("register", "Create new user"));
	} else {
	    div.addContent(new Header(1, "Success!"));
	    div.addContent(new Paragraph("Hi " + user_id));
	    div.addContent(new Paragraph("You are successfully logged into the system. Have fun!"));
	}

	return div;
    }
    
    public Page execute(QueryHandler hdl)
    {
	UserSession session = hdl.getUserSession();
	String usr_id = session.getID();
	
	String action = hdl.getParameter("action");
	String target = hdl.getParameter("target");

	Page result = null;

	if (action != null) {
	    if (action.equals("login")) {
		String id = hdl.getParameter("user_id");
		String pass = hdl.getParameter("user_pass");
	    
		if (id != null &&
		    pass != null &&
		    checkLogin(hdl, id, pass)) { 
		    session.setID(id);
		} else {
		    target = null;
		    result = super.execute(hdl);
		    result.getContent().addContent(loginErrorPage());
		}
	    } else if (action.equals("logout"))
		session.finish();
	}
	
	if (target != null) {
	    hdl.redirect(target);
	} else if (result == null) {
	    result = super.execute(hdl);
	}

	if (result != null)
	    result.getContent().addContent(loginDefaultPage(hdl));
	
	return result;
    }
}
