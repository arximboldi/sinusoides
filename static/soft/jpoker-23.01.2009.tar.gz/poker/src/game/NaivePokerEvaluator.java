/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.*;

/**
 * Implementación trivial de un evaluador de jugadas de poquer. A pesar de ser
 * una implementación inexperta, cumple estrictamente las leyes del Poker según
 * están descritas en: http://en.wikipedia.org/wiki/Hand_rankings. Para el
 * cómputo de la puntuación de las jugadas establece una biyección entre los
 * números enteros y las posibles jugadas de poker de tal forma que sea f(hand)
 * esta biyección, se cumple que f(x) <= f(y) sii x <= y.
 * 
 * @author raskolnikov
 */
class NaivePokerEvaluator implements PokerEvaluator
{
	/** Numero de manos (jugadas) posivbles que puede tener el jugador. */
	static public int NUM_HANDS = 9;
	/** Tamaño de la mano de un jugador. */
	static public int HAND_SIZE = 5;
	
	/**
	 * Base del sistema númerico de cartas utilizado para el cómputo del valor
	 * de una mano.
	 */
	static public double FACTOR = 14.0;
	static public double BIG_FACTOR = 14.0 * 14.0 * 14.0 * 14.0 * 14.0 * 14.0;
	
	/**
	 * Construye el evaluador de poquer.
	 * @param hand La mano a evaluar.
	 */
	NaivePokerEvaluator (List<Card> hand)
	{
		m_hand = hand;
	}
	
	/**
	 * Realiza el cálculo de la evaluación de la mano.
	 */
	@Override
	public void evaluate ()
	{	
		Collections.sort (m_hand);
		evaluateRepetition ();
		evaluateContinuity ();
		evaluatePoints ();
	}
	
	/**
	 * Devuelve los puntos de la mano.
	 */
	@Override
	public double points ()
	{
		return m_points;
	}
	
	/**
	 * Devuelve la mano que tiene el jugador.
	 */
	@Override
	public PokerEvaluator.Hand hand ()
	{
		return m_hand_val;
	}
	
	/**
	 * Evalua los calculos basados en repeteción de rangos y palos.
	 */
	private void evaluateRepetition ()
	{
		/* Reset counters */
		for (int i = 0; i < PokerDeck.MAX_RANK; ++i)
			m_rank_times [i] = 0;
		for (int i = 0; i < PokerDeck.MAX_SUIT; ++i)
			m_suit_times [i] = 0;
		for (int i = 0; i < HAND_SIZE; ++i)
			m_rank_repeats [i] = 0;
		
		/* Count how many times each card appears */
		for (Card c : m_hand) {
			++ m_rank_times [c.getRank()-1];
			++ m_rank_repeats [ m_rank_times [c.getRank()-1] ];
			
			++ m_suit_times [c.getSuit().ordinal()];
			++ m_suit_repeats [ m_suit_times [c.getSuit().ordinal()] ];
		}
	}
	
	/**
	 * Evalua las manos basadas en la escalera de rangos.
	 */
	private void evaluateContinuity ()
	{
		m_continuity = 0;
		for (int i = 0; i < m_hand.size () -1; ++i) {
			if (m_hand.get (i).getRank () + 1 == m_hand.get (i+1).getRank ())
				++ m_continuity;
		}
	}
	
	/**
	 * Evalua los puntos que corresponden a la mano basándose en los cálculos de
	 * continuidad y repetición de la jugada.
	 */
	private void evaluatePoints ()
	{
		if (m_continuity == 4 && m_suit_repeats [5] > 0)
			m_hand_val = Hand.STRAIGHT_FLUSH;
		else if (m_rank_repeats [4] > 0)
			m_hand_val = Hand.FOUR_OF_A_KIND;
		else if (m_rank_repeats [3] > 0 && m_rank_repeats [2] > 1)
			m_hand_val = Hand.FULL_HOUSE;
		else if (m_suit_repeats [5] > 0)
			m_hand_val = Hand.FLUSH;
		else if (m_continuity == 4)
			m_hand_val = Hand.STRAIGHT;
		else if (m_rank_repeats [3] > 0)
			m_hand_val = Hand.THREE_OF_A_KIND;
		else if (m_rank_repeats [2] > 1)
			m_hand_val = Hand.TWO_PAIR;
		else if (m_rank_repeats [2] > 0)
			m_hand_val = Hand.ONE_PAIR;
		else
			m_hand_val = Hand.HIGH_CARD;
		
		m_points = 
			m_hand_val.value () * BIG_FACTOR
			+ untieValue ();
	}
	
	/**
	 * Computa la puntuación individual de las cartas que no influyen en una
	 * jugada de repetición.
	 * 
	 * @return El valor computado.
	 */
	private double kickerValue ()
	{
		double result = 0.0;
		double factor = 1.0;
		
		for (Card c : m_hand) {
			if (m_rank_times [c.getRank () - 1] < 2) {
				result += (c.getRank () - 1) * factor;
				factor *= FACTOR; 
			}
		}
		
		return result;
	}

	/**
	 * Computa un valor basado únicamente en el rango de las cartas.
	 * @return El valor computado. 
	 */
	private double rankValue ()
	{
		double result = 0.0;
		double factor = 1.0;
		
		for (Card c : m_hand) {
			result += c.getRank () * factor;
			factor *= FACTOR; 
		}
		
		return result;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public double[] cardPoints ()
	{
		double [] p = new double [HAND_SIZE];
		int i = 0;
		for (Card c : m_hand) {
			if (m_continuity == 4 || m_rank_times [c.getRank ()-1] > 1
					|| m_suit_times [c.getSuit ().ordinal ()] > 4)
				p [i] = m_points;
			else
				p [i] = 0.0;
			++i;
		}
		return p;
	}
	
	/**
	 * Computa el valor de desempate de una jugada.
	 * @return El valor computado.
	 */
	private double untieValue ()
	{
		switch (m_hand_val)
		{
		case HIGH_CARD:
		case FLUSH:
			return rankValue ();
			
		case ONE_PAIR:
		case THREE_OF_A_KIND:
		case FOUR_OF_A_KIND:
		{
			double result = 0.0;
			int i;
			for (i = 12; i >= 0 && m_rank_times [i] < 2; --i);
			result = i * BIG_FACTOR / FACTOR;
			return result + kickerValue ();
		}
		
		case TWO_PAIR:
		{
			int i;
			double result = 0.0;
			for (i = 12; i >= 0 && m_rank_times [i] < 2; --i);
			result += i * BIG_FACTOR / FACTOR;
			for (; i >= 0 && m_rank_times [i] < 2; --i);
			result += i * BIG_FACTOR / FACTOR / FACTOR;
			return result + kickerValue ();
		}
		
		case FULL_HOUSE:
		{
			int i;
			double result = 0.0;
			for (i = 12; i >= 0 && m_rank_times [i] != 3; --i);
			result += i * BIG_FACTOR / FACTOR;
			for (i = 12; i >= 0 && m_rank_times [i] != 2; --i);
			result += i * BIG_FACTOR / FACTOR / FACTOR;
			return result + kickerValue ();
		}
		
		case STRAIGHT:
		case STRAIGHT_FLUSH:
			return m_hand.get(m_hand.size () - 1).getRank ();

		default:
			break;
		}
		
		return 0.0;
	}
	
	@SuppressWarnings("unused")
	private static double[] hand_probability = 
	{
		50.12,
		42.27,
		4.75,
		2.11,
		0.39,
		0.20,
		0.14,
		0.024,
		0.00154
	};
	
	/* Las cartas involucradas en cada jugada */
	@SuppressWarnings({ "unchecked", "unused" })
	private List<Card> [] m_hand_cards = new List [NUM_HANDS];
	
	/* Puntuacion y mano */
	private double m_points;
	private Hand   m_hand_val;
	
	/* Ayudas para encontrar escaleras */
	private int m_continuity;
	
	/* Ayudas para encontrar los colores y escaleras de color */
	private int [] m_suit_times   = new int [PokerDeck.MAX_SUIT];
	private int [] m_suit_repeats = new int [HAND_SIZE+1];
	
	/* Ayudas para encontrar parejas, dobles parejas, trios y fulls */
	private int [] m_rank_times   = new int [PokerDeck.MAX_RANK];
	private int [] m_rank_repeats = new int [HAND_SIZE+1];
	
	/* La mano actual */
	private List<Card> m_hand;
}
