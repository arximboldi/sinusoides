%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       corner_harris.m
%  Time-stamp: <2011-02-18 20:14:00 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Algoritmo de detección de esquinas de Harris.
%

function [c, f, cornerdernom, eigen] = corner_harris(img, threshold, ...
                                                     neighbours)

    img = double(img);
    [nf, nc] = size(img);

    % Calculamos el gradiente horizontal y vertical de la img, ix e iy.
    % Filtramos la img con la máscara [-1, 0, 1] y con su traspuesta.
    
    mask = [-1 0 1];
    ix = imfilter (img, mask, 'replicate'); 
    iy = imfilter (img, mask', 'replicate');

    % Cálculo de los elementos que compondrán la matriz C
    
    masksum = ones (neighbours,neighbours);
    ix2 = ix .^ 2;
    sum_ix2 = imfilter (ix2, masksum, 'replicate');
    iy2 = iy .^ 2;
    sum_iy2 = imfilter (iy2, masksum, 'replicate');
    ixy = ix .* iy;
    sum_ixy = imfilter (ixy, masksum, 'replicate');
    
    % Observa que de esta forma hemos creado tres matrices que contienen,
    % en la posición (i,j), la sumtoria correspondiente al neighbours
    % del píxel (i,j).  Hemos aprovechado la eficiencia de la función
    % imfilter.
    
    eigen = zeros (nf, nc);
    for i = 1:nf
        for j = 1:nc
            c = [sum_ix2(i,j) sum_ixy(i,j); sum_ixy(i,j) sum_iy2(i,j)];
            d = eig (c);
            eigen (i, j) = min (d);
        end;
    end;
    
    corners = eigen > threshold * 256;
    [f,c] = find (corners);
    cornerdernom = corners .* eigen;
