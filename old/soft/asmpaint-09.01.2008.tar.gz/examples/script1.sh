#!/bin/bash

echo "auto_update 0"

RAD=3
while true
do
    while [ "x$RAD" != "x200" ]
    do
	echo "clear"
	echo "circle 320 240 $RAD"
	echo "regular 320 240 200 $SIDES 0"
	echo "update"
	echo "sleep 10"
	let RAD+=1
    done
    while [ "x$RAD" != "x3" ]
    do
	echo "clear"
	echo "circle 320 240 $RAD"
	echo "update"
	echo "sleep 10"
	let RAD-=1
    done
done
