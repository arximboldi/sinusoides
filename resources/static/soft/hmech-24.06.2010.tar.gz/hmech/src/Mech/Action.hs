--
--  File:       Action.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon Mar 16 14:36:27 2009
--  Time-stamp: <2009-05-30 23:21:43 raskolnikov>
--
--  Datos de las acciones del usuario
--

module Mech.Action where

import Mech.Info

data Action = Movement
            | Reaction
            | Weapons
            | Phisicals
            | End
              deriving (Ord, Eq, Enum, Show, Read)

data Movement = None
              | Walk
              | Run
              | Jump
              | Floor
                deriving (Ord, Eq, Enum, Show, Read)

data Rotation = NoneRot
              | LeftRot
              | RightRot
                deriving (Ord, Eq, Enum, Show, Read)

data Objective = NoneObj
               | MechObj
               | HexObj
                 deriving (Ord, Eq, Enum, Show, Read)

data Step = Step { dir   :: Direction
                 , value :: Int
                 } deriving (Show, Read)

data Shot = Shot { gun :: Slot
                 , double :: Bool
                 , shotAmmo :: Maybe Slot
                 , shotObjective :: Hex
                 , shotObjType :: Objective
                 } deriving (Show, Read)

data Hit = Punch { hitLoc :: Location }
         | Kick { hitLoc :: Location }
         | Blow { hitLoc :: Location }
         | Sword { hitLoc :: Location, hitSlot :: Int }
           deriving (Show, Read)

data Phisical = Phisical { weapon :: Hit
                         , phisObjective :: Hex
                         , phisObjType :: Objective
                         } deriving (Show, Read)

data MovementAction = MovementAction
    { move :: Movement
    , dest :: Position
    , useMasc :: Bool
    , steps :: [Step]
    }

data ReactionAction = ReactionAction Rotation

data WeaponsAction = WeaponsAction { takeClub :: Bool
                                   , objective :: Hex
                                   , shots :: [Shot]
                                   }

data PhisicalAction = PhisicalAction [Phisical]

data EndAction = EndAction { radiatorOff :: Int
                           , radiatorOn :: Int
                           , dropClub :: Bool
                           , dropAmmo :: [Slot]
                           }

defaultMovement :: MovementAction
defaultMovement = MovementAction None (Pos nullHex North) False []

defaultReaction :: ReactionAction
defaultReaction = ReactionAction NoneRot

defaultWeapons :: WeaponsAction
defaultWeapons = WeaponsAction False nullHex []

defaultPhisical :: PhisicalAction
defaultPhisical = PhisicalAction []

defaultEnd :: EndAction
defaultEnd = EndAction 0 0 False []
