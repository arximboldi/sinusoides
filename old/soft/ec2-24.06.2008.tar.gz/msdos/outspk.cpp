
#include <pc.h>
#include <iostream>
#include "outspk.h"

#define TIMER_ISR 0X1C    /* The clock tick interrupt */

using namespace std;

static OutputSpeaker* g_out = 0;

void timerISR()
{
  if (g_out) {
    Sample sample = g_out->m_buffer.pop();

    sample = (sample * g_out->m_diff) >> 8 + 1;
    outp(0x42, sample);
    g_out->m_count++;
  }
}

OutputSpeaker::OutputSpeaker(int buf_size) :
  m_buffer(buf_size),
  m_finished(false)
{  
}

bool OutputSpeaker::open()
{
  if (getState() == NOTINIT) {
    outp(0x43, 0x90);
    outp(0x61, inp(0x61) | 3);
    setState(IDLE);
    return true;
  }
  
  return false;
}

void OutputSpeaker::registerISR()
{
  g_out = this;
  
  _go32_dpmi_get_protected_mode_interrupt_vector(TIMER_ISR, &m_old_isr);
  m_new_isr.pm_offset = (int)timerISR;
  m_new_isr.pm_selector = _go32_my_cs();
  _go32_dpmi_allocate_iret_wrapper(&m_new_isr);
  _go32_dpmi_set_protected_mode_interrupt_vector(TIMER_ISR, &m_new_isr);
}

void OutputSpeaker::unregisterISR()
{
  _go32_dpmi_set_protected_mode_interrupt_vector(TIMER_ISR, &m_old_isr);
  _go32_dpmi_free_iret_wrapper(&m_new_isr);

  g_out = 0;
}

bool OutputSpeaker::start()
{
  if (getState() == IDLE) {
    setState(RUNNING);

    m_count = 0;
    m_diff = 1193180.0 / getSampleRate();
    
    outp(0x43,0x36);
    outp(0x40, m_diff);
    outp(0x40, 0);

    registerISR();
    loop();
    unregisterISR();
    
    outp(0x43, 0x36);
    outp(0x40, 0);
    outp(0x40, 0);
    
    return true;
  }
  return false;
}

void OutputSpeaker::loop()
{
  while(!m_finished) {
    if (m_buffer.writeable())
      process(m_buffer.writeable());
  } 
 
  m_finished = false;
} 
 
void OutputSpeaker::put(Sample* buf, int n_samples)
{
  m_buffer.push(buf, n_samples);
} 

bool OutputSpeaker::stop()
{
  if (getState() == RUNNING) {
    m_finished = true;
    setState(IDLE);
    return true;
  }
  
  return false;
}

bool OutputSpeaker::close()
{
  if (getState() == IDLE) {
    outp(0x43, 0x90);
    outp(0x61, inportb (0x61)& 3);
  }
  
  return false;
}

