--  File:       Run.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Tue Mar 31 16:15:43 2009
--  Time-stamp: <2009-05-29 20:51:27 raskolnikov>
--
--  Utilidad para ejecutar un bot dentro del framework
--

module Mech.Run (runWarrior) where

import System
import System.CPUTime
import System.IO

import GHC.Handle -- hDuplicateTo

import Mech.Warrior

argsError = "!! No se puede ejecutar el programa con menos de 2 argumentos"

--
-- Función principal del programa que invoca al bot Nexus7
--
runWarrior :: (Warrior a, Show a, Read a) => a -> IO Int
runWarrior warrior = 
    do args <- getArgs
       if (length args < 2)
         then do putStrLn argsError 
                 return 1
         else run warrior

run warrior =
    do let name = warName warrior
       args <- getArgs 
       log  <- openFile (name ++ "-" ++ args !! 0 ++ ".log") WriteMode
       hDuplicateTo log stdout
       hDuplicateTo log stderr       
       
       putStrLn $ "-----> " ++ (args !! 1) ++ " - " ++ (args !! 0)
       time <- timedRun $ play warrior (read (args !! 0)) (args !! 1)
       putStrLn $ "<----- " ++ (show time) 
       
       return 0

--
-- Ejecuta una acción IO y mide el tiempo que tarda en mili-segundos
--
timedRun :: (IO ()) -> IO Double
timedRun what =
    do start <- getCPUTime
       what
       end <- getCPUTime
       return (fromInteger (end - start) / 1000000000)

