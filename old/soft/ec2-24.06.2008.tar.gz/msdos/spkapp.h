
#ifndef SPEAKERAPP_H
#define SPEAKERAPP_H

#include <string>

#define DEFAULT_BUFFER_SIZE 4096

class SpeakerApp
{
  bool m_param_help;
  bool m_param_echo;
  float m_param_vol;
  float m_param_srate;
  float m_param_delayms;
  float m_param_feedback;
  int m_param_bufsize;
  const char* m_param_file;

  int play();
 public:
  SpeakerApp();
  void printHelp();
  int run(int argc, const char** argv);
};

#endif /* SPEAKERAPP_H */
