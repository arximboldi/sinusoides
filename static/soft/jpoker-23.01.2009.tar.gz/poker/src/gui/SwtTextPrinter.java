/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import org.eclipse.swt.widgets.Text;

import cli.CliPrinter;

/**
 * Imprime mensajes sobre un control de texto de SWT.
 * @author raskolnikov
 */
public class SwtTextPrinter implements CliPrinter
{
	/**
	 * Constructor.
	 * @param text El control al que delegar los mensajes.
	 */
	SwtTextPrinter (Text text)
	{
		m_text = text;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void print (String text)
	{
		m_text.append (text);
	}

	/**
	 * {@inheritDoc}
	 */
	public void println()
	{
		m_text.append ("\n");
	}

	/**
	 * {@inheritDoc}
	 */
	public void println(String text)
	{
		m_text.append (text);
		m_text.append ("\n");
	}

	private Text m_text;
}
