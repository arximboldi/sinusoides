%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       blockmatch_deep.m
%  Time-stamp: <2011-01-28 23:21:22 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Detección de desplazamiento de bloques preciso.
%

function field_offset = blockmatch_deep (...
    block_size, max_offset, mse_or_msa, f_now, f_prev)

    if mse_or_msa
        mse_or_msa = @ (b0, b1) sum (sum ((double (b1) - double (b0)).^2));
    else
        mse_or_msa = @ (b0, b1) sum (sum (abs (double(b1) - double (b0))));
    end
        
    [rows cols]  = size (f_now);
    field_offset = zeros (rows, cols);

    num_blocks_v = floor (rows / block_size);
    num_blocks_h = floor (cols / block_size);
    
    for i = 1 : num_blocks_v
        for j = 1 : num_blocks_h
            % Recortamos el block que se va a analizar (en la imagen actual).
            % Calculamos la coordenada horizontal y vertical de
            % comienzo de block.
            
            f_inic = ((i-1) * block_size) + 1;
            c_inic = ((j-1) * block_size) + 1;
            block = f_now(f_inic : f_inic+block_size-1, ...
                          c_inic : c_inic+block_size-1);
            min_criteria = Inf;
            
            % Analizamos todos los blocks candidatos
            for u = -max_offset:max_offset
                if ((f_inic+u >=1) && (f_inic+block_size+u-1 <= rows))
                    for v = -max_offset:max_offset
                        if ((c_inic+v>=1) && (c_inic+block_size+v-1 <= cols))
                            prev_block = f_prev(...
                                f_inic+u : f_inic+block_size-1+u,...
                                c_inic+v : c_inic+block_size-1+v);
    
                            criteria = mse_or_msa (prev_block, block);

                            if(criteria < min_criteria)
                                criteria_f = u;
                                criteria_c = v;
                                min_criteria = criteria;
                            end
                            
                            if criteria==min_criteria && v==0 && u==0
                                criteria_f=0;
                                criteria_c=0;
                            end
                        end
                    end %for v
                end
            end %for u
            
            % Almacenamos las dos componentes del vector de offset en un número
            % complejo por comodidad
            field_offset(f_inic:f_inic+block_size-1,...
                         c_inic:c_inic+block_size-1) = complex(...
                             criteria_f,criteria_c);
        end %for j
    end %for i
