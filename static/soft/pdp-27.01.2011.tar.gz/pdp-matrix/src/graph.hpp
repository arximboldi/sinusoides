/**
 *  Time-stamp:  <2010-11-20 23:38:31 raskolnikov>
 *
 *  @file        graph.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Wed Nov 17 21:40:13 2010
 *
 *  Grafo representado como matriz de adyacencia con utilitarios para
 *  el envío mediante MPI.
 */

#ifndef PDP_GRAPH_H
#define PDP_GRAPH_H

#include <ostream>
#include <limits>
#include <mpi.h>

namespace pdp
{

namespace detail
{

template <typename Label, bool HasInfinity>
struct label_traits_inf;

template <typename Label>
struct label_traits_inf<Label, false>
{
    static Label infinity ()
    { return std::numeric_limits<Label>::max (); }
};

template <typename Label>
struct label_traits_inf<Label, true>
{
    static Label infinity ()
    { return std::numeric_limits<Label>::infinity (); }
};

template <typename Label>
struct label_traits_base :
	public label_traits_inf<Label,
				std::numeric_limits<Label>::has_infinity>
{};

} /* namespace detail */

/**
 * Traits de las etiquetas de las aristas de un grafo. Cada trait
 * aporta dos funciones estáticas que devuelven respectivamente:
 *     mpi_type: Esta función devuelve el valor MPI::Datatype que
 *               implementa el tipo de la etiqueta sobre MPI.
 *     infinity: Esta función devuelve el valor que representa
 *               infinito en el tipo o el más apropiado en su defecto.
 */
template <typename Label>
struct label_traits : detail::label_traits_base<Label> {};

template <>
struct label_traits<float> : detail::label_traits_base<float>
{
    static const MPI::Datatype& mpi_type () { return MPI::FLOAT; }
};

template <>
struct label_traits<double> : detail::label_traits_base<double>
{
    static const MPI::Datatype& mpi_type () { return MPI::DOUBLE; }
};

template <>
struct label_traits<int> : detail::label_traits_base<int> 
{
    static const MPI::Datatype& mpi_type () { return MPI::INT; }
};

namespace detail
{

/* Utilidad de la interfaz común base del grafo */
template <typename Label>
class graph_base
{
public:
    typedef Label label_type;

    /**
     * Devuelve el valor "infinito" para esta matriz de adyacencia.
     */
    static const Label infinity ()
    { return label_traits<Label>::infinity (); }

    /**
     * Accede al vertice (i, j) de la matriz de adyacencia.
     */
    Label& operator () (size_t i, size_t j)
    { return _data [i][j]; }
    
    /**
     * Accede al vertice (i, j) de la matriz de adyacencia.
     */
    const Label& operator () (size_t i, size_t j) const
    { return _data [i][j]; }

    /**
     * Devuelve el número de vértices del grafo.
     */
    size_t size () const
    { return _size; }

    /**
     * Devuelve la matriz de datos en crudo.
     * @note La información de las etiquetas se encuentra en un bloque
     * consecutivo.
     */
    Label** raw () { return _data; }
    const Label** raw () const { return _data; }

protected:
    size_t   _size;
    Label**  _data;    
};

} /* namespace detail */

/**
 * Clase grafo representado como una matriz de adyacencia. Incluye
 * funciones que facilitan su uso entre procesos.
 */
template <typename Label>
class graph : public detail::graph_base<Label> 
{
public:
    /**
     * Constructor. Inicializa la matriz de adyacencia como un grafo
     * totalmente inconexo.
     * @param verts Numero de vertices en el grafo.
     */
    graph (size_t verts = 0);

    /** Destructor. */
    ~graph ();

    /**
     * Reconstruye e inicializa la matriz con un numero dado de vertices.
     */
    void recreate  (size_t verts);

#if 0
    /*
     * Comprueba que es posible realizar una distribución
     * bidimensional a traves de un comunicador dado.
     */
    void bi_check (MPI::Comm& comm);

    /**
     * Devuelve por referencia el rango local que del proceso actual en una
     * distribución bidimensional del grafo.
     */
    void bi_local_range (MPI::Comm& comm,
			 size_t& col_begin, size_t& col_end,
			 size_t& row_begin, size_t& row_end)
    {
	int size = comm.Get_size ();
	int rank = comm.Get_rank ();
	
	size_t size_sqr  = std::sqrt (comm.Get_size ());
	size_t rng_size  = _size / size_sqr;

	size_t row_begin = (rank * rng_size) % _size;
	size_t row_end   = row_begin + rng_size;
	size_t row_begin = (rank * rng_size) / _size;
	size_t row_end   = row_begin + rng_size;
	
	begin = _size / comm.Get_size () * comm.Get_rank ();
	end   = begin + _size / comm.Get_size ();
    }
    
    /**
     * Distribuye el grafo según se encuentra en el proceso 'root'
     * de tal forma que cada proceso recibe un número consecutivos de
     * filas de la distribución. Las filas de la matriz se distribuyen
     * por orden de rango.
     */
    void bi_scatter (MPI::Comm& com, int root);

    /**
     * Actualiza una fila dada. Asume que el grafo ha sido distribuido
     * unidimensionalmente.
     */
    void bi_bcast_row (MPI::Comm& comm, size_t row);
    
    /**
     * Actualiza una fila dada. Asume que el grafo ha sido distribuido
     * unidimensionalmente.
     */
    void bi_bcast_col (MPI::Comm& comm, size_t row);
    
    /**
     * Reconstruye en el proceso 'root' una matriz distribuida
     * unidimensionalmente entre procesos.
     */
    void bi_gather  (MPI::Comm& com, int root);
#endif
    
private:
    void _allocate (size_t s);
    void _liberate ();
    
    using detail::graph_base<Label>::_data;
    using detail::graph_base<Label>::_size;
};

/**
 * Emite una representación humana sobre un stream.
 */
template <typename Label>
std::ostream& operator<< (std::ostream& os, const graph<Label>& g);

/**
 * Carga el grafo desde un stream siguiendo la sintaxis del guion de
 * practicas.
 */
template <typename Label>
std::istream& operator>> (std::istream& is, graph<Label>& g);

} /* namespace pdp */

#include "graph.tpp"

#endif /* GRAPH_H */

