%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       noise_gaussian_mult.m
%  Time-stamp: <2011-01-23 21:54:48 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Ruido gausano multiplicativo.
%

function img = noise_gaussian_mult (img, alfa)
    img = bound_gray (double (img) + randn (size (img)) .* sqrt (alfa * double (img)));
end

