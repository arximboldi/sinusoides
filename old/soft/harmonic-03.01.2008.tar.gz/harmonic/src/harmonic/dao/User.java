/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.dao;

import java.util.Date;

public class User extends Person
{
    public static class Profile
    {
	public String real_name;
	public String sex;
	public String description;
	public Date birth_date;
	public String homepage_url;
	public String avatar_url;

	public Profile()
	{}
	
	public Profile(String _real_name,
		       String _sex,
		       String _description,
		       Date _birth_date,
		       String _homepage_url,
		       String _avatar_url) {
	    real_name = _real_name;
	    sex = _sex;
	    description = _description;
	    birth_date = _birth_date;
	    homepage_url = _homepage_url;
	    avatar_url = _avatar_url;
	}
    }
    
    public String nick;
    public String pass_hash;
    public String email;
    public String confirm_code;
    
    public User(int _id,
		Date _create_date,
		String _nick,
		String _pass_hash,
		String _email,
		String _confirm_code) {
	super(_id, _create_date);
	nick = _nick;
	pass_hash = _pass_hash;
	email = _email;
	confirm_code = _confirm_code;
    }
}
