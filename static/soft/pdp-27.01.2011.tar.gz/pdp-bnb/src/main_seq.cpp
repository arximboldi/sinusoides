/**
 *  Time-stamp:  <2011-01-15 17:27:56 raskolnikov>
 *
 *  @file        main.cpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Tue Jan 11 18:42:07 2011
 *
 *  Visitante de comercio paralelizable.
 */

#include <iostream>

#include "pdp/bnb.hpp"
#include "pdp/tsp.hpp"
#include "pdp/full_dist_graph.hpp"
#include "pdp/generic_graph_main.hpp"

int main (int argc, char** argv)
{
    using namespace pdp;

    return generic_graph_main<
        generic_graph_algo<
            bnb::branch_and_bound_fn<tsp::node<int>, full_dist_graph<int> >,
            full_dist_graph<int> > > (argc, argv);
}
