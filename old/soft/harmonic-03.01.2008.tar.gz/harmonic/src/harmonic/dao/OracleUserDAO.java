/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.dao;

import java.sql.*;

class OracleUserDAO extends OracleDAOBase implements UserDAO
{
    public void create(User user)
	throws Exception
    {
	Person p = (new OraclePersonDAO()).create();
	
	try {
	    user.id = p.id;
	    
	    Connection conn = getConnection();
	    PreparedStatement ps = conn.prepareStatement
		("insert into hm_user values (?,?,?,?,?,null,null,null,null,null,null)");
	    ps.setInt(1, user.id);
	    ps.setString(2, user.nick);
	    ps.setString(3, user.pass_hash);
	    ps.setString(4, user.email);
	    ps.setString(5, user.confirm_code);
	    ps.executeUpdate();
	    ps.close();
	} catch (Exception e) {
	    /* Nos aseguramos de no dejar basura en la tabla hm_person */
	    (new OraclePersonDAO()).delete(p);
	    
	    System.out.println("INSERT EXCEPTION: " + e.toString());
	    throw new Exception("User creation error. Probably there is another account with the same email or name.");
	} finally {
	    /* HACK: Por algun motivo núnca se ejecuta el método finally
	       y las conexiones se quedan abiertas... Esto hace que el programa sea
	       menos optimo porque antes reutilizabamos la conexion, habra que ver
	       como solucionarlo -tal vez mediante una llamada externa del usuario. */
	    closeConnection();
	}
    }

    public void update(User user)
	throws Exception
    {
	try {
	    Connection conn = getConnection();
	    PreparedStatement ps = conn.prepareStatement
		("update hm_user set nick = ?, pass_hash = ?, email = ?, confirm_code = ? where nick = ?");
	    ps.setString(1, user.nick);
	    ps.setString(2, user.pass_hash);
	    ps.setString(3, user.email);
	    ps.setString(4, user.confirm_code);
	    ps.setString(5, user.nick);
	    ps.executeUpdate();
	    ps.close();
	} catch (Exception e) {
	    System.out.println("UPDATE EXCEPTION: " + e.toString());
	    throw new Exception("Error while updating user data.");
	} finally {
	    closeConnection();
	}
    }

    public void updateProfile(User user, User.Profile profile)
	throws Exception
    {
	try {
	    Connection conn = getConnection();
	    PreparedStatement ps = conn.prepareStatement
		("update hm_user set real_name = ?, description = ?, sex = ?, birth_date = ?, homepage_url = ?, avatar_url = ? where nick = ?");
	    ps.setString(1, profile.real_name);
	    ps.setString(2, profile.description);
	    ps.setString(3, profile.sex);
	    ps.setDate(4, profile.birth_date == null ? null : new java.sql.Date(profile.birth_date.getTime()));
	    ps.setString(5, profile.homepage_url);
	    ps.setString(6, profile.avatar_url);
	    ps.setString(7, user.nick);
	    ps.executeUpdate();
	    ps.close();
	} catch (Exception e) {
	    System.out.println("UPDATE EXCEPTION: " + e.toString());
	    throw new Exception("Error while updating user data.");
	} finally {
	    closeConnection();
	}
    }
    
    public void delete(User user)
	throws Exception
    {
	(new OraclePersonDAO()).delete(user);
	
	/*
	try {
	    Connection conn = getConnection();
	    PreparedStatement ps = conn.prepareStatement
		("delete from hm_user where id = ?");
	    ps.setString(1, user.name);
	    ps.executeUpdate();
	    ps.close();
	} catch (Exception e) {
	    System.out.println("DELETE EXCEPTION: " + e.toString());
	    throw new Exception("Error while deleting user.");
	}
	*/
    }
    
    public User find(String nick) {
	if (nick == null)
	    return null;
		
	User user = null;
	
	try {
	    Connection conn = getConnection();
	    PreparedStatement ps = conn.prepareStatement
		("select * from hm_user, hm_person where hm_user.id = hm_person.id and hm_user.nick = ?");
	    ps.setString(1, nick);
	    
	    ResultSet rs = ps.executeQuery();
	    if (rs.next()) {
		user = new User(rs.getInt("id"),
				rs.getDate("create_date"),
				rs.getString("nick"),
				rs.getString("pass_hash"),
				rs.getString("email"),
				rs.getString("confirm_code"));
	    }
	    ps.close();
	    
	} catch (Exception e) {
	    System.out.println("QUERY EXCEPTION: " + e.toString());
	} finally {
	    closeConnection();
	}

	return user;
    }

    public User.Profile profile(User user)
    {
	if (user == null)
	    return null;
		
	User.Profile prf = null;
	
	try {
	    Connection conn = getConnection();
	    PreparedStatement ps = conn.prepareStatement
		("select * from hm_user where hm_user.id = ?");
	    ps.setInt(1, user.id);
	    
	    ResultSet rs = ps.executeQuery();
	    if (rs.next()) {
		prf = new User.Profile(rs.getString("real_name"),
				       rs.getString("sex"),
				       rs.getString("description"),
				       rs.getDate("birth_date") == null ?
				       null : new java.util.Date(rs.getDate("birth_date").getTime()),
				       rs.getString("homepage_url"),
				       rs.getString("avatar_url"));
	    }
	    ps.close();
	    
	} catch (Exception e) {
	    System.out.println("QUERY EXCEPTION: " + e.toString());
	} finally {
	    closeConnection();
	}

	return prf;
    }
}
