%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       check_ex.m
%  Time-stamp: <2011-01-23 22:47:05 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Comprueba que una excepcion es de cierto tipo y la relanza si
%  no lo es.
%

function check_ex (ex, id)
    if ~strcmp (ex.identifier, id)
        rethrow (ex);
    end
end
