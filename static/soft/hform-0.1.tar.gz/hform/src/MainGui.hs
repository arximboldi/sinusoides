--------------------------------------------------------------------------------
--
-- Fichero:    MainGui.hs
-- Autor:      Juan Pedro Bolivar Puente
-- Time-stamp: <2011-08-22 20:57:07 raskolnikov>
--
--------------------------------------------------------------------------------

module MainGui where

import Graphics.UI.Gtk
import Graphics.UI.Gtk.Glade
import Graphics.UI.Gtk.ModelView as New

import Formula
import FormulaParser

--
-- Ficheros de las principales ventanas
--
main_glade  = "data/gui/main.glade"
about_glade = "data/gui/about.glade"
help_glade = "data/gui/help.glade"

-- |
-- Una operación aplicable sobre una formula
data Operation = OpFnc
               deriving (Eq)

-- |
-- La operacion puede mostrarse
instance Show (Operation) where
    showsPrec _ o s = showsOperation  o s

-- |
-- Implementa la obtención de una representación textual de la operación
--
showsOperation :: Operation -> String -> String
showsOperation OpFnc _ = "FNC"

-- |
-- Una ejecución de una operacion
data Run = Run { 
      input :: String,   -- ^ La expresión de entrada 
      op :: Operation,   -- ^ La operación
      output :: String   -- ^ La expresión de salida
    }

-- |
-- Controla un evento de ejecución de una operación sobre la entrada
--
handleOperation :: Window -> New.ListStore Run -> Entry -> Entry -> Operation -> IO ()
handleOperation win history input output op = 
    do
      intext  <- get input entryText
      formula <- parseIO intext (formulaParser numberParser) :: IO (Formula Integer)
      outtext <- return (show (run formula op))
      set output [ entryText := outtext ]
      New.listStorePrepend history (Run intext op outtext)
      return ()
    `catch` excepcion
    where run f OpFnc = fnc f
          excepcion e = do
            m <- messageDialogNew (Just win) [] 
                 MessageError ButtonsOk "Error procesando la cadena"
            dialogRun m
            widgetDestroy m

-- |
-- Controla un evento de selección de un elemento del historial
--
handleSelected :: New.ListStore Run -> New.TreePath -> Entry -> Entry -> IO ()
handleSelected store path inEntry outEntry =
    do
      row  <- New.listStoreGetValue store (head path)
      set inEntry  [ entryText := input row ]
      set outEntry [ entryText := output row ]
      return ()

-- |
-- Construye y muestra el dialogo de información sobre el programa
--
showAbout :: IO ()
showAbout =
    do
      Just xml <- xmlNew about_glade
      window <- xmlGetWidget xml castToDialog "about-window"
      onResponse window $ (\x -> do widgetDestroy window)
      widgetShowAll window
      return ()

-- |
-- Construye y muestra el dialogo de ayuda
--
showHelp' :: IO ()
showHelp' =
    do
      Just xml <- xmlNew help_glade
      window <- xmlGetWidget xml castToDialog "help-window"
      but    <- xmlGetWidget xml castToButton "ok-button"
      onClicked but $ do widgetDestroy window
      widgetShowAll window
      return ()

-- |
-- Construye y muestra la ventana principal
-- 
mainWindow :: IO ()
mainWindow = 
    do
      Just xml <- xmlNew main_glade
  
      -- Obtenemos algunos widgets de interes
      window    <- xmlGetWidget xml castToWindow   "main-window"
      quitMenu  <- xmlGetWidget xml castToMenuItem "quit-menu"
      aboutMenu <- xmlGetWidget xml castToMenuItem "about-menu"
      helpMenu  <- xmlGetWidget xml castToMenuItem "help-menu"
      fncButton <- xmlGetWidget xml castToButton   "op-fnc-button"
      inEntry   <- xmlGetWidget xml castToEntry    "input-entry"
      outEntry  <- xmlGetWidget xml castToEntry    "output-entry"
      histView  <- xmlGetWidget xml castToTreeView "history-tree"

      -- Configuramos el historial
      histStore <- New.listStoreNew []
      New.treeViewSetModel histView histStore
      New.treeViewSetHeadersVisible histView True
      newCol histView histStore "Input"  (\row -> [ New.cellText := input row ])
      newCol histView histStore "Op"     (\row -> [ New.cellText := show (op row) ])
      newCol histView histStore "Output" (\row -> [ New.cellText := output row ])

      -- Añadimos eventos interesantes
      onDestroy window mainQuit
      onActivateLeaf aboutMenu $ do
        showAbout
      onActivateLeaf helpMenu $ do
        showHelp'
      onActivateLeaf quitMenu $ do
        widgetDestroy window
      onEntryActivate inEntry $ do
        handleOperation window histStore inEntry outEntry OpFnc
      onClicked fncButton $ do
        handleOperation window histStore inEntry outEntry OpFnc
      New.onRowActivated histView $ 
             (\path -> \col -> 
                       do handleSelected histStore path inEntry outEntry)
        
      -- Finiquitamos
      widgetShowAll window
      return ()
    where
      newCol view model title content = 
          do
            renderer <- New.cellRendererTextNew
            col <- New.treeViewColumnNew
            New.treeViewColumnPackStart col renderer True
            New.cellLayoutSetAttributes col renderer model $ content
            New.treeViewColumnSetTitle col title
            New.treeViewAppendColumn view col

-- |
-- Programa principal
--
main :: IO ()
main = 
    do
      initGUI
      mainWindow
      mainGUI
