--
--  File:       MainNexus7.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon Mar 16 20:16:05 2009
--  Time-stamp: <2009-05-29 20:51:36 raskolnikov>
--
--  Función main que ejecuta el bot Nexus7
--

module MainNexus7 where

import Mech.Run
import Nexus.Nexus7

main = runWarrior warrior
