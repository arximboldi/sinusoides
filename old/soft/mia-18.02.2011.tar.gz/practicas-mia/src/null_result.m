%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       null_result.m
%  Time-stamp: <2011-01-29 02:48:19 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Empty result.
%

classdef null_result < image_result_base
    methods
        function type = result_type (self)
            type = 'null';
        end
        
        function data = get_data (self)
            data = [];
        end
    end
end
