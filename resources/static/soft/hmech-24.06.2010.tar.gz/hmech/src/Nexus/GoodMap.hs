--
--  File:       GoodMap.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Wed May 27 11:02:52 2009
--  Time-stamp: <2009-06-23 21:31:39 raskolnikov>
--
--  Funciones para el cálculo del mapa de propensiones.
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Nexus.GoodMap where

import Data.Array

import Mech.Info
import Mech.Action
import Mech.Util

import Nexus.State
import Nexus.Shoot
import Nexus.Phisical
import Nexus.Attack
import Nexus.Debug

type GoodFunc = State -> Position -> Side -> Double
type GoodMap = Array Position Double


mkGoodMap :: State -> GoodFunc -> GoodMap
mkGoodMap s f = listArray (minp, maxp) $ map func $ range (minp, maxp)
    where
      (minhex, maxhex) = bounds $ smap s 

      minp = (Pos minhex North)
      maxp = (Pos maxhex NorthWest)
      func p@(Pos _ side) = min (f s p side) $ min (f s p $ nextSide side) (f s p $ prevSide side)

rotateLeft :: Mech -> Mech
rotateLeft m = m { trunkSide = prevSide (trunkSide m) }

rotateRight :: Mech -> Mech
rotateRight m = m { trunkSide = nextSide (trunkSide m) }

yingYangGoodFunc :: NexusState -> Movement -> GoodFunc
yingYangGoodFunc w m s (Pos phex pside) tside = 
    (1 - killNeed w) * defense - (killNeed w) * attack
    where
      attack  = 3 * (sum $ map attackFactor allattack)
      defense = sum $ map attackFactor alldefense

      shoot = map nullAttack . shootMech (smap s) thisMech m
      phisical = map nullAttack . phisMech w (smap s) thisMech 

      shootThis mech = map nullAttack 
                       (shootMech (smap s) mech None thisMech ++
                        shootMech (smap s) (rotateLeft mech) None thisMech ++
                        shootMech (smap s) (rotateRight mech) None thisMech)
      phisicalThis mech = map nullAttack 
                          (phisMech initialState (smap s) mech thisMech ++
                           phisMech initialState (smap s) (rotateLeft mech) thisMech ++
                           phisMech initialState (smap s) (rotateRight mech) thisMech)

      thisMech = (current s) { position = phex, side = pside, trunkSide = tside }
      
      allattack = shoot obj ++ phisical obj
      alldefense = concatMap shootThis (mechs s) ++ concatMap phisicalThis (mechs s)
      obj = nearestMech s

attackFactor :: Attack a -> Double
attackFactor x = let mod = fromIntegral $ attackModifier x
                     dam = fromIntegral $ attackDamage x
                     dst = (fromIntegral . attackDest) x / (fromIntegral . totalArmourPoints . attackMech) x
                 in dam * (1 - mod / 12) + 1 / dst

bestAttackFactor :: [Attack a] -> Double
bestAttackFactor x = modhead best / damhead best
    where
      best = bestAttack x      
      modhead []    = 13
      modhead (x:_) = fromIntegral $ attackModifier x 
      damhead []    = 1.0
      damhead (x:_) = fromIntegral $ attackDamage x

bestAttack :: [Attack a] -> [Attack a]
bestAttack attacks = best (bcomp (<) factor) attacks
    where
      factor x = fromIntegral (attackModifier x) / fromIntegral (attackDamage x)

--
-- Busca al mech más cercano al jugador
--
nearestMech :: State -> Mech
nearestMech s = head $ best (bcomp (<) (dist (current s))) $
                filter operative (mechs s)
    where                
      dist x y = hexDistSqr (position x) (position y)
