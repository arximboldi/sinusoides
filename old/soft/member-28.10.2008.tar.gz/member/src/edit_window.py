#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade
import datetime
import time
import gobject

from dao import *
from gui_tools import *
from member import *
import common


class EditWindow (GladeWindow):
    def __init__ (self, member, owner):
        GladeWindow.__init__ (self, common.GUI_EDIT, 'window-edit')
        fchooser = self.get_widget ('file-picture')
        preview = gtk.Image ()
        fchooser.set_preview_widget (preview)
        fchooser.connect ("update-preview", update_preview_cb, preview)
        
        self._cal_window = self.get_widget ('window-calendar')
        self._cal_widget = self.get_widget ('calendar')
        
        self.create_paylist ()

        if member:
            try:
                dao = DaoFactoryMgr ().create_member_dao ()
                mdata = dao.find_data (member.id)
                self._add = False
                self.get_widget ('label-member-id').set_text ('Member number: ' + str (member.id))
                self._memid = member.id
                if member.name: 
                    self.get_widget ('entry-name').set_text (member.name)
                if member.surname:
                    self.get_widget ('entry-surname').set_text (member.surname)
                if member.nif:
                    self.get_widget ('entry-nif').set_text (member.nif)
                if member.up_date:
                    self.get_widget ('entry-update').set_text (member.up_date.strftime (common.DATE_FORMAT))
                if member.down_date:
                    self.get_widget ('entry-downdate').set_text (member.down_date.strftime (common.DATE_FORMAT))
                if member.birth_date:
                    self.get_widget ('entry-birthdate').set_text (member.birth_date.strftime (common.DATE_FORMAT))
                if mdata.address:
                    self.get_widget ('entry-address').set_text (mdata.address)
                if mdata.zip:
                    self.get_widget ('entry-zip').set_text (mdata.zip)
                if mdata.city:
                    self.get_widget ('entry-city').set_text (mdata.city)
                if mdata.province:
                    self.get_widget ('entry-province').set_text (mdata.province)
                if mdata.phone:
                    self.get_widget ('entry-phone').set_text (mdata.phone)
                if mdata.mobile:
                    self.get_widget ('entry-mobile').set_text (mdata.mobile)
                if mdata.email:
                    self.get_widget ('entry-email').set_text (mdata.email)
                if mdata.web:
                    self.get_widget ('entry-web').set_text (mdata.web)
                if mdata.bank:
                    self.get_widget ('entry-bank').set_text (mdata.bank)
                if mdata.notes:
                    self.get_widget ('text-notes').get_buffer ().set_text (mdata.notes)
                if mdata.picture:
                    self.get_widget ('file-picture').set_filename (mdata.picture)
                    self.get_widget ('image-picture').set_from_file (mdata.picture)
            
                self.fill_paylist ()
            except Exception, e:
                show_error_dialog ('Could not load member data', str (e))
        else:
            self._add = True
            self._memid = None
            self.get_widget ('entry-update').set_text (datetime.date.today ().strftime (common.DATE_FORMAT))
        self.show ()
        self._owner = owner
        
    def create_paylist (self):
        store = gtk.ListStore (str, float, str)
        store.set_sort_func (0, sort_func_date)

        tree = self.get_widget ('tree-payments')
        tree.set_model (store)
        
        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('Date', cellp)
        #col.set_cell_data_func (cellp, cell_date_function)
        col.set_attributes (cellp, text=0)
        col.set_sort_column_id (0)
        tree.append_column (col)
        
        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('Amount', cellp)
        col.set_attributes (cellp, text=1)
        col.set_sort_column_id (1)
        tree.append_column (col)
        
        cellp = gtk.CellRendererText ()
        col = gtk.TreeViewColumn ('Notes', cellp)
        col.set_attributes (cellp, text=2)
        col.set_sort_column_id (2)
        tree.append_column (col)
        
        tree.set_search_column (3)

        self._tree_store = store
        self._tree_view = tree
        self._payments_changed = False

    def fill_paylist (self):
        if self._memid:
            dao = DaoFactoryMgr ().create_payment_dao ()
            li = dao.list (self._memid)
            for i in li:
                self._tree_store.append ([i.date.strftime (common.DATE_FORMAT), i.amount, i.notes])

    def store_paylist (self, memid):
        if self._payments_changed:
            dao = DaoFactoryMgr ().create_payment_dao ()
            dao.clear (memid)
            iter = self._tree_store.get_iter_first ()
            while iter:
                pay = Payment ()
                pay.id = memid
                try:
                    pay.date = my_strptime (self._tree_store.get (iter, 0)[0], common.DATE_FORMAT)
                except Exception, e:
                    show_error_dialog ('Incorrect date format. Use (day/month/year)', str (e))
                pay.amount = self._tree_store.get (iter, 1)[0]
                pay.notes = self._tree_store.get (iter, 2)[0]
                dao.add (pay)
                iter = self._tree_store.iter_next (iter)
    
    def handle_add_payment (self, wid):
        dt = self.get_widget ('entry-paydate').get_text ()
        amount = self.get_widget ('spin-payamount').get_value ()
        notes = self.get_widget ('entry-paynotes').get_text ()
        self._tree_store.append ([dt, amount, notes])
        self._payments_changed = True

    def handle_delete_payment (self, wid):
        model, row = self._tree_view.get_selection().get_selected ()
        if row:
            model.remove (row)
            self._payments_changed = True

    def handle_apply_payment (self, wid):
        model, row = self._tree_view.get_selection().get_selected ()
        if row:
            dt = self.get_widget ('entry-paydate').get_text ()
            amount = self.get_widget ('spin-payamount').get_value ()
            notes = self.get_widget ('entry-paynotes').get_text ()
            model.set (row, 0, dt, 1, amount, 2, notes)
            self._payments_changed = True

    def handle_select_payment (self, win):
        model, row = self._tree_view.get_selection().get_selected ()
        if row:
            dt, amount, notes = model.get (row, 0, 1, 2)
            self.get_widget ('entry-paydate').set_text (dt)
            self.get_widget ('spin-payamount').set_value (amount)
            self.get_widget ('entry-paynotes').set_text (notes)

    def get_mouse_position (self):
        device = gtk.gdk.device_get_core_pointer ()
        (x, y), z = device.get_state (self._root.get_root_window ())
        return x, y

    def calendar_today (self):
        today = datetime.date.today()
        self._cal_widget.select_month (today.month, today.year)
        self._cal_widget.select_day (today.day)
        self._cal_window.show ()

    def handle_picture_set (self, win):
        fname = self.get_widget ('file-picture').get_filename () 
        self.get_widget ('image-picture').set_from_file (fname)

    def calendar_on_mouse (self):
        self.calendar_today ()
        px, py = self.get_mouse_position ()
        self._cal_window.move (int (px), int (py))
        self._cal_window.show ()

    def handle_edit_update (self, win):
        self.calendar_on_mouse ()
        self._cal_entry = self.get_widget ('entry-update')

    def handle_edit_downdate (self, win):
        self.calendar_on_mouse ()
        self._cal_entry = self.get_widget ('entry-downdate')

    def handle_edit_birthdate (self, win):
        self.calendar_on_mouse ()
        self._cal_entry = self.get_widget ('entry-birthdate')
        
    def handle_edit_paydate (self, win):
        self.calendar_on_mouse ()
        self._cal_entry = self.get_widget ('entry-paydate')

    def handle_calendar_change (self, win):
        year, month, day = self._cal_widget.get_date ()
        self._cal_entry.set_text (str (day) + '/' + str (month) + '/' + str (year))
        self._cal_window.hide ()

    def handle_cancel (self, win):
        self.destroy ()
        self._cal_window.destroy ()

    def handle_ok (self, win):
        try:
            dao = DaoFactoryMgr ().create_member_dao ()
            try:
                member = self.build_member ()
                mdata  = self.build_member_data ()
            except Exception, e:
                show_error_dialog ('Incorrect date format. Use (day/month/year)', str (e))
                return

            if self._add:
                tmem = dao.add ()
                member.id = tmem.id
                mdata.id = tmem.id
                dao.update (member)
                dao.update_data (mdata)
                self._owner.add_member (member)
                self.store_paylist (tmem.id)
            else:
                dao.update (member)
                dao.update_data (mdata)
                self._owner.update_member (member)
                self.store_paylist (member.id)
        except Exception, e:
            show_error_dialog ('Could not edit member', str (e))
        self.destroy ()
        self._cal_window.destroy ()

    def build_member (self):
        mem = Member ()
        mem.id = self._memid
        mem.name = self.get_widget ('entry-name').get_text ()
        mem.surname = self.get_widget ('entry-surname').get_text ()
        mem.nif = self.get_widget ('entry-nif').get_text ()
        if self.get_widget ('entry-update').get_text ():
            mem.up_date = my_strptime (self.get_widget ('entry-update').get_text (), common.DATE_FORMAT)
        if self.get_widget ('entry-downdate').get_text ():
            mem.down_date = my_strptime (self.get_widget ('entry-downdate').get_text (), common.DATE_FORMAT)
        if self.get_widget ('entry-birthdate').get_text ():
            mem.birth_date = my_strptime (self.get_widget ('entry-birthdate').get_text (), common.DATE_FORMAT)
        return mem

    def build_member_data (self):
        data = MemberData ()
        data.id = self._memid
        data.address = self.get_widget ('entry-address').get_text ()
        data.zip = self.get_widget ('entry-zip').get_text ()
        data.city = self.get_widget ('entry-city').get_text ()
        data.province = self.get_widget ('entry-province').get_text ()
        data.phone = self.get_widget ('entry-phone').get_text ()
        data.mobile = self.get_widget ('entry-mobile').get_text ()
        data.email = self.get_widget ('entry-email').get_text ()
        data.web = self.get_widget ('entry-web').get_text ()
        data.bank = self.get_widget ('entry-bank').get_text ()
        buf = self.get_widget ('text-notes').get_buffer ();
        data.notes = buf.get_text (buf.get_start_iter (), buf.get_end_iter ())
        data.picture = self.get_widget ('file-picture').get_filename () 
        return data
