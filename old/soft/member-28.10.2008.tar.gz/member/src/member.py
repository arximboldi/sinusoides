#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

class Payment:
    def __init__ (self):
        self.id = None
        self.date = None
        self.amount = None
        self.notes = None

class Member:
    def __init__ (self):
        self.id = None
        self.name = None
        self.surname = None
        self.nif = None
        self.up_date = None
        self.down_date = None
        self.birth_date = None

class MemberData:
    def __init__ (self):
        self.id = None
        self.address = None
        self.zip = None
        self.city = None
        self.province = None
        self.phone = None
        self.mobile = None
        self.email = None
        self.web = None
        self.bank = None
        self.notes = None
        self.picture = None
