%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       image_result.m
%  Time-stamp: <2011-01-29 02:47:53 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Resultado es una imagen normal.
%

classdef image_result < image_result_base
    properties
        data
    end
    
    methods 
        function self = image_result (data)
            self.data = data;
        end
        
        function img = get_data (self)
            img = self.data;
        end
        
        function type = result_type (self)
            type = 'image';
        end
    end
end
