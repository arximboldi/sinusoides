/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


package harmonic.dao;

import java.sql.*;

public class OracleDAOBase
{
    /* HACK: Haciendo pruebas con el modelo a usar para optimizar las
       conexiones con la BD se me ha ocurrido esta forma, hacer que la
       conexion sea static, para evitar tener que recrear la conexion.
       Hay que tener en cuenta que los servlet viven en memoria durante
       todas las peticiones -no como, por ejemplo, los scripts en PHP-
       y por tanto así todas las peticiones usarán la misma conexión.
       De esta forma ya no hay que hacer nada en closeConnection().
       Hay que ver por otro lado si este método escala bien ya que no se
       como se las apaña Java para hacer las conexiones sensibles a la
       concurrencia -cada petición es una hebra, aunque comparte la misma
       instancia del servlet. */
    static Connection m_conn = null;
    
    protected synchronized Connection getConnection()
	throws java.sql.SQLException,
	       java.lang.ClassNotFoundException
    {
	if (m_conn != null && !m_conn.isClosed())
	    return m_conn;
	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	m_conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:",
					     "harmonic",
					     "harmonic");
	return m_conn;
    }

    void closeConnection() {
	/* Dejamos la función vacía por si hay que volver al viejo método. */
	/*try {
	    if (m_conn != null && !m_conn.isClosed()) {
		m_conn.close();
	    }
	} catch (Exception e) {}
	m_conn = null;*/
    }
    
    protected void finalize() {
	/*closeConnection();*/
    }
}
