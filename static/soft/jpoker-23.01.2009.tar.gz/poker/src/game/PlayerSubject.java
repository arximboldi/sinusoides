/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.*;

/**
 * Implementa el comportamiento básico de un sujeto juego sobre el cual
 * distintos PlayerListener pueden registrarse para atender a eventos de la/s
 * partida/s observadas.
 * 
 * @author raskolnikov
 */
public class PlayerSubject 
{
	/**
	 * Añade un escuchante al sujeto. A partir de ahora el escuchante será
	 * notificado de los eventos que sucedan sobre el sujeto.
	 * 
	 * @param l El escuchante a añadir.
	 */
	public void addListener (PlayerListener l)
	{
		m_listeners.add (l);
	}

	/**
	 * Quita un escuchante del sujeto. A partir de ahora el escuchante dejará de
	 * recibir notificaciones del sujeto.
	 * 
	 * @param l El escuchante a quitar.
	 */
	public void removeListener (PlayerListener l)
	{
		m_listeners.remove (l);
	}
	
	/**
	 * Dispara un evento de apuesta.
	 * @param p El jugador que apuesta.
	 * @param bet La cantidad de su apuesta.
	 */
	void notifyBet (Player p, double bet)
	{
		for (PlayerListener l : m_listeners) {
			l.handlePlayerBet (p, bet);
		}
	}
	
	/**
	 * Dispara un evento de entrega de cartas.
	 * @param p El jugador que recibe.
	 * @param c La carta recibida.
	 */
	void notifyTake (Player p, Card c)
	{
		for (PlayerListener l : m_listeners) {
			l.handlePlayerTake (p, c);
		}
	}
	
	/**
	 * Dispara un evento de devolución de cartas.
	 * @param p El jugador que devuelve cartas.
	 * @param d Las cartas devueltas.
	 */
	void notifyDrop (Player p, Collection<Card> d)
	{
		for (PlayerListener l : m_listeners) {
			l.handlePlayerDrop (p, d);
		}
	}

	/**
	 * Dispara un evento de devolución forzosa de todas las cartas.
	 * @param p El jugador que devuelve las cartas.
	 * @param c Las cartas devueltas.
	 */
	void notifyDropAll (Player p, List<Card> c)
	{
		for (PlayerListener l : m_listeners) {
			l.handlePlayerDropAll (p, c);
		}
	}
	
	void notifyUpdateSavings (Player p, double diff)
	{
		for (PlayerListener l : m_listeners) {
			l.handlePlayerUpdateSavings (p, diff);
		}
	}
	
	/** Los escuchantes de este sujeto. */
	private List<PlayerListener> m_listeners = new LinkedList<PlayerListener> ();
}
