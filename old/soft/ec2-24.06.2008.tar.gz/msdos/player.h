
#ifndef PLAYER_H
#define PLAYER_H

#include <list>
#include <string>

#include "out.h"
#include "filter.h"
#include "freader.h"

class Player : public OutputListener
{
  std::list<Filter*> m_filters;
  FileReader* m_file;

  void filter(Sample* buf, int n_samples);
 public:
  Player();
  ~Player();

  void setFile(FileReader* m_reader) {
    m_file = m_reader;
  }
  
  void attachFilter(Filter* filt) {
    m_filters.push_back(filt);
  }
  
  void process(Output* out, int n_frames);
};

#endif /* PLAYER_H */
