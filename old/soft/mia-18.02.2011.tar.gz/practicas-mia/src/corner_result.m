%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       corner_result.m
%  Time-stamp: <2011-01-29 07:02:32 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Resultado de esquinas.
%

classdef corner_result < image_result_base
    properties
        c; f; denorm; eigen; img; mode; color
    end
    
    methods
        function self = corner_result (c, f, denorm, eigen, img, mode)
            self.c = c;
            self.f = f;
            self.denorm = denorm;
            self.eigen = eigen;
            self.img = img;
            self.mode = mode;
        end
        
        function type = result_type (self)
            type = 'corner';
        end
        
        function display (self, color_mode, color)
            self.color = color;
            display @ image_result_base (self, color_mode, color);
            
            if self.mode == 3
                hold on;
                plot (self.c, self.f, 'y+', 'Color', color);
                hold off;
            end
        end
        
        function img = get_data (self)
            switch self.mode
              case 1
                img = self.denorm;
              case 2
                img = self.eigen;
              case 3
                img = self.img;
            end
        end
    end
end
