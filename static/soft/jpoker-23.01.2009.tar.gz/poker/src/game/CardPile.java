/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.*;

/**
 * Implementa una abstracción de una pila de cartas.
 * 
 * @author raskolnikov
 */
public class CardPile implements Cloneable
{
	/**
	 * Añade una carta al final de la pila.
	 * @param c La carta a añadir.
	 */
	public void addBottom (Card c) 
	{
		m_cards.addLast (c);
	}
	
	/**
	 * Toma una carta del final de la pila.
	 * @return La carta extraida de la pila.
	 */
	public Card takeBottom ()
	{
		return m_cards.removeLast ();
	}
	
	/**
	 * Añade una carta a la cima de la pila de cartas.
	 * @param c La carta a añadir.
	 */
	public void addTop (Card c)
	{
		m_cards.addFirst (c);
	}
	
	/**
	 * Extrae una carta la de la cima de la pila.
	 * @return La carta tomada.
	 */
	public Card takeTop ()
	{
		return m_cards.removeFirst ();
	}

	/**
	 * Baraja la pila de cartas aleatorizando el orden de las cartas que
	 * contiene.
	 */
	public void shuffle ()
	{
		Collections.shuffle (m_cards);
	}

	/**
	 * Clona la pila de cartas devolviendo una instancia igual en valor.
	 */
	@SuppressWarnings("unchecked")
	public CardPile clone () throws CloneNotSupportedException
	{
		CardPile clon = (CardPile) super.clone ();
		clon.m_cards = (LinkedList<Card>) m_cards.clone ();
		return clon;
	}

	/** Alberga la pila de cartas. */
	private LinkedList<Card> m_cards = new LinkedList<Card>();
}
