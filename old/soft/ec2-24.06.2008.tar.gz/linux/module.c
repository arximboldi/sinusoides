/*
 * Driver de sonido para Linux 2.6
 *
 * Autores:
 *   Juan Pedro Bolívar Puente
 *   Francisco Manuel Herrero Pérez
 */

/* Se pueden descomentar estas lineas o ejecutar 'make CFLAGS="-DUSE_XXX"' */
/* Descomentar para usar colas de espera en lugar de espera casi-activa */
/* #define USE_WAIT_QUEUE */
/* Descomentar para registrar el dispostivo en OSS */
/* #define USE_OSS */


#include <linux/module.h>
#include <linux/io.h>
#include <linux/sched.h>
#include <asm/uaccess.h>

#ifdef USE_OSS
#include <linux/soundcard.h>
#include <linux/sound.h>
#else
#include <linux/fs.h>
#endif /* USE_OSS */

#ifdef USE_WAIT_QUEUE
#include <linux/wait.h>
#endif /* USE_WAIT_QUEUE */

#include "ring_buf.h"
#include "isr.h"

#define DEFAULT_DEVICE_NAME "ec2spk"
#define DEFAULT_BUFFER_SIZE 65536
#define DEFAULT_SAMPLE_RATE 22100


typedef struct sound_s
{
  int device;
  int use_count;
  int srate;
  int timer_count;
  int tick_count;
  int old_ticks;
  ring_buf_t rbuf;
  ring_buf_reader_t rbuf_reader;
#ifdef USE_WAIT_QUEUE
  wait_queue_head_t wait_queue;
#endif
} sound_t;

static ssize_t
sound_read (struct file *file, char *buffer,
	    size_t length, loff_t *offset);
static ssize_t
sound_write (struct file *file, const char *buffer,
	     size_t length, loff_t *offset);
static int
sound_open (struct inode *inode, struct file *file);

static int
sound_release (struct inode *inode, struct file *file);

static int
sound_ioctl (struct inode *inode, struct file *file,
	     unsigned int cmd, unsigned long arg);

static void
sound_set_timer (int srate);

int
sound_isr (void);

DECLARE_ISR_HANDLER (sound_isr);
DEFINE_ISR_HANDLER (sound_isr, *gbl_old_isr);

static sound_t gbl_sound;
static long gbl_old_isr;

struct file_operations gbl_sound_fops =
  {
  read: sound_read,
  write: sound_write,
  open: sound_open,
  release: sound_release,
  ioctl: sound_ioctl
  };

int __init
sound_init (void)
{
#ifdef USE_OSS
  gbl_sound.device = register_sound_dsp (&gbl_sound_fops, -1); 
#else
  gbl_sound.device = register_chrdev (0, DEFAULT_DEVICE_NAME, &gbl_sound_fops);	
#endif

  if (gbl_sound.device < 0) {
    printk (KERN_WARNING "Error al registrar el driver. %d\n",
	    gbl_sound.device);
    return gbl_sound.device;
  }

  printk (KERN_ALERT "El modulo del kernel se ha cargado con exito.\n");
  
  if (ring_buf_init (&gbl_sound.rbuf, DEFAULT_BUFFER_SIZE) == ERROR)
    return -EFAULT;
  gbl_sound.rbuf_reader = ring_buf_begin (&gbl_sound.rbuf);

#ifdef USE_WAIT_QUEUE  
  init_waitqueue_head (&gbl_sound.wait_queue);
#endif
  
  gbl_old_isr = get_interrupt_gate (0x20);
  set_interrupt_gate (0x20, (long) GET_ISR_HANDLER (sound_isr));

  sound_set_timer (DEFAULT_SAMPLE_RATE);
  
  return 0;
}

void __exit
sound_exit (void)
{
#ifdef USE_OSS
  unregister_sound_dsp (gbl_sound.device);
#else
  unregister_chrdev (gbl_sound.device, DEFAULT_DEVICE_NAME);
#endif
  
  sound_set_timer (HZ);
  set_interrupt_gate (0x20, gbl_old_isr);

  ring_buf_clear (&gbl_sound.rbuf);
}

ssize_t
sound_read (struct file *file, char *buffer,
	    size_t length, loff_t *offset)
{
  return -EINVAL;
}

ssize_t
sound_write (struct file *file, const char *buffer,
	     size_t length, loff_t *offset)
{  
  while (ring_buf_write_availible (&gbl_sound.rbuf,
  				   &gbl_sound.rbuf_reader) < length)
    {
      if (file->f_flags & O_NONBLOCK)
	return -EAGAIN;

#ifdef USE_WAIT_QUEUE
      if (wait_event_interruptible
	  (gbl_sound.wait_queue,
	   (ring_buf_write_availible (&gbl_sound.rbuf,
				      &gbl_sound.rbuf_reader) < length)))
	return -ERESTARTSYS;
#else
      schedule();
      if (signal_pending(current))
	return -ERESTARTSYS;
#endif
    }

  return ring_buf_write (&gbl_sound.rbuf, buffer, length);
}

void
sound_set_timer (int srate)
{  
  gbl_sound.srate = srate;
  gbl_sound.timer_count = 1193180 / srate;
  outb (0x36, 0x43);
  outb (gbl_sound.timer_count & 0xFF, 0x40);
  outb ((unsigned) gbl_sound.timer_count >> 8, 0x40);
  gbl_sound.old_ticks = srate / HZ;
  gbl_sound.tick_count = 0;
}

int
sound_open (struct inode *inode, struct file *file)
{
  if (gbl_sound.use_count)
    return -EBUSY;
  gbl_sound.use_count++;
  return 0;
}
  
int
sound_release (struct inode *inode, struct file *file)
{
  gbl_sound.use_count--; // Decrementar el contador de uso
  return 0;
}

int
sound_ioctl (struct inode *inode, struct file *file,
	     unsigned int cmd, unsigned long arg)
{
#ifdef USE_OSS
  audio_buf_info info;
  int freq;

  switch (cmd)
    {
    case SNDCTL_DSP_CHANNELS:
      return put_user (1, (int*) arg);
    case SNDCTL_DSP_GETCAPS:
      return put_user (0, (int*) arg);
    case SNDCTL_DSP_GETFMTS:
      return put_user (AFMT_U8, (int*) arg);
    case SNDCTL_DSP_GETODELAY:
      return put_user (1, (int*) arg);
    case SNDCTL_DSP_GETOSPACE:
      info.fragments = 1;
      info.fragstotal = 1;
      info.fragsize = gbl_sound.rbuf.size;
      info.bytes = gbl_sound.rbuf.size;
      return copy_to_user ((void*)arg, &info, sizeof(info));
    case SNDCTL_DSP_SETFMT:
      return put_user (AFMT_U8, (int*) arg);
    case SNDCTL_DSP_SPEED:
      get_user (freq, (int*) arg);
      sound_set_timer (freq);
      break;	
    case SNDCTL_DSP_RESET:
    case SNDCTL_DSP_SYNC:
      gbl_sound.rbuf_reader = ring_buf_begin (&gbl_sound.rbuf);
      break;
    case SNDCTL_DSP_SETFRAGMENT:
      break;
    case SNDCTL_DSP_STEREO:
      return put_user(0, (int*) arg);
    case SNDCTL_DSP_GETBLKSIZE:
      return put_user(gbl_sound.rbuf.size, (int*) arg);	
    default:
      return -EINVAL;
    }
#endif /* USE_OSS */
  
  return -EINVAL;
}

int
sound_isr (void)
{
  unsigned char data;
    
  if (ring_buf_availible (&gbl_sound.rbuf, &gbl_sound.rbuf_reader))
    {
      data = ring_buf_read_one (&gbl_sound.rbuf, &gbl_sound.rbuf_reader);
      data = ((gbl_sound.timer_count * data) >> 8) + 1;
      
      outb (inb (0x61) | 0x3, 0x61);

      outb (0xB0, 0x43);
      outb (data, 0x42);
    }
  
  gbl_sound.tick_count ++;
  if (gbl_sound.tick_count > gbl_sound.old_ticks) {
    gbl_sound.tick_count -= gbl_sound.old_ticks;
    return 1;
  } else
    return 0;	
}


module_init(sound_init);
module_exit(sound_exit);

MODULE_AUTHOR ("Juan Pedro Bolivar Puente y Francisco Manuel Herrero Perez");
MODULE_DESCRIPTION ("Driver de sonido por el PC speaker.");
MODULE_LICENSE("GPL");
