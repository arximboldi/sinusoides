/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.Collection;

/**
 * Jugador de póquer que delega las decisiones en un objet externo.
 * @author raskolnikov
 */
public class DelegatedPokerPlayer extends PokerPlayer
{
	/**
	 * Constructor.
	 * @param name El nombre del jugador.
	 * @param savings Ganancias iniciales del mismo.
	 */
	public DelegatedPokerPlayer (String name, double savings)
	{
		super(name, savings);
	}

	/**
	 * Constructor.
	 * @param name El nombre del jugador.
	 * @param savings Ganancias iniciales del jugador.
	 * @param ext El objeto encargado de tomar las decisiones.
	 */
	public DelegatedPokerPlayer (String name, double savings, ExternalPokerPlayer ext)
	{
		super(name, savings);
		m_ext = ext;
	}

	/**
	 * Establece el jugador externo.
	 * @param e Quien tomará las decisiones.
	 */
	public void setExternal (ExternalPokerPlayer e)
	{
		m_ext = e;
	}
	
	/**
	 * Delega la decisión. {@inheritDoc}
	 */
	@Override
	public double chooseBet ()
	{
		return m_ext.chooseBet ();
	}

	/**
	 * Delega la decisión. {@inheritDoc}
	 */
	@Override
	public Collection<Card> chooseDrop ()
	{
		return m_ext.chooseDrop ();
	}

	/**
	 * Delega la decisión. {@inheritDoc}
	 */
	@Override
	public boolean leave ()
	{
		return m_ext.leave ();
	}
	
	private ExternalPokerPlayer m_ext;
}
