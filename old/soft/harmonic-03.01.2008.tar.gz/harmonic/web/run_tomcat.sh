#!/bin/bash

/etc/init.d/apache2 start
/usr/share/tomcat5.5/bin/catalina.sh run
/etc/init.d/apache2 stop

