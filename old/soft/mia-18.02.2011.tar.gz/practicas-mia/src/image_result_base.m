%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       image_result.m
%  Time-stamp: <2011-01-29 08:26:22 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Sirve para guardar una imagen y mostrar el resultado. Heredando
%  de aquí se puede cambiar el comportamiento para cachear
%  resultados y mostrar varias opciones diferentes.
%

classdef image_result_base < handle    
    methods (Abstract)
        get_data
        result_type
    end
    
    methods
        function display (self, color_map, color)
            data = self.get_data ();
            imagesc (data), colormap (char (color_map)), axis image off;
        end
        
        function display_profile (self, plot_fn, row, color)
            data = self.get_data ();
            s = size (data);
            row = 1 + round (row * (s (1) - 1));
            % hack
            try
                plot_fn (data (row, :), 'FaceColor', color);
            catch ex
                plot_fn (data (row, :), 'Color', color);
            end
            axis image off;
        end
        
        function res = isempty (self)
            res = strcmp (self.result_type, 'null') || isempty (self.get_data);
        end
    end
end

