/**
 *  Time-stamp:  <2010-11-25 18:23:37 raskolnikov>
 *
 *  @file        main_bi.cpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Thu Nov 18 21:51:08 2010
 *
 *  Algoritmo de floyd con distribucion bidimensional.
 */

#include "bi_dist_graph.hpp"
#include "generic_floyd.hpp"

int main (int argc, char** argv)
{
    return pdp::generic_floyd_main<pdp::bi_dist_graph<double> > (argc, argv);
}
