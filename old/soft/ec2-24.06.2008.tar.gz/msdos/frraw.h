
#ifndef FRRAW_H
#define FRRAW_H

#include <fstream>
#include "freader.h"

class FileReaderRaw : public FileReader
{
  std::ifstream m_file;
  int m_pos;
  
 public:
  bool open(const char* file);
  void seek(size_t pos);
  int read(Sample* buf, int n_samples);
  void close();
};

#endif /* FRRAW_H */
