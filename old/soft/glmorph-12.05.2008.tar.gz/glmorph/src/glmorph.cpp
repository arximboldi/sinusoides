/**
 * @file   morph.cpp
 * @author Juan Pedro Bol�var Puente
 * @date   April 2007
 * 
 * Copyright (C) 2007 by Juan Pedro Bol�var Puente
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <iostream>

#include "SDL_2dgl.h"
#include "glmorph.h"
#include "render.h"
#include "sdltimer.h"

using namespace std;

/**
 * Main function.
 */
int main(int argc, char* argv[])
{
	MorphOptions ops;
	GL2D_SurfaceGL *p1, *p2;
	Mesh2D m1, m2;
	
	if (!parseArgs(ops, argc, argv)) {
		showHelp(basename(argv[0]));
		return 1; 
	}
	
	if (ops.mesh1 == "") {
		ops.mesh1 = ops.pic1;
		changeExt(ops.mesh1, "mesh");
	}
	
	if (ops.mesh2 == "") {
		ops.mesh2 = ops.pic2;
		changeExt(ops.mesh2, "mesh");
	}
	
	if (!m1.load(ops.mesh1.c_str())) {
		cerr << _("Could not load mesh file: ") << ops.mesh1 << endl;
		exit(-1);
	}
	
	if (!m2.load(ops.mesh2.c_str())) {
		cerr << _("Could not load mesh file: ") << ops.mesh2 << endl;
		exit(-1);
	}
	
	initSDL();
	GL2D_InitScreenGL(1, 1, 32, 0); /* We need a bootstrap OGL context to load
	                                   textures. */
	
	if ((p1 = loadPicture(ops.pic1.c_str())) == NULL) {
		cerr << _("Could not load picture file: ") << ops.pic1 << endl;
		exit(-1);
	}
	
	GL2D_InitScreenGL(p1->w, p1->h, 32, 0);

	if ((p2 = loadPicture(ops.pic2.c_str())) == NULL) {
		cerr << _("Could not load picture file: ") << ops.pic2 << endl;
		exit(-1);
	}
	
	SDL_WM_SetCaption(basename(argv[0]), NULL);
	
	while (playMorphing(p1, p2, m1, m2, ops.fps, ops.time, ops.showmesh)) {
		swap(m1, m2);
		swap(p1, p2);
	}
	
	return 0;
}

void changeExt(string &path, string ext)
{
	int i;
	
	for (i = path.size()-1; i > 0 && path[i] != '.'; i--);
	
	i++;
	path.erase(i, path.size()-i);
	
	path += ext;
}

bool playMorphing(const GL2D_SurfaceGL* pic1, const GL2D_SurfaceGL* pic2,
				  const Mesh2D& m1, const Mesh2D& m2, int fps, int time,
				  bool showmesh)
{
	SDLtimer t(fps);
	int totalms = 0;
	Mesh2D maux = m1;
	SDL_Event e;
	int i, j;
	
	if (m1.width() != m2.width() || m1.height() != m2.height()) {
		cerr << _("Mesh sizes should match.") << endl;
		return false;
	}
	
	do {
		t.update();
		
		for (i = 0; i < maux.width(); i++) {
			for (j = 0; j < maux.height(); j++) {
				maux.set(i, j, maux.get(i, j).x + 
							   float(m2.get(i,j).x - m1.get(i,j).x)/time * t.msec(),
							   maux.get(i, j).y + 
							   float(m2.get(i,j).y - m1.get(i,j).y)/time * t.msec()
							   );
			}
		}
		
		/* Check if we have to quit. */
		while (SDL_PollEvent(&e)) {
			if ( e.type == SDL_QUIT ||
				(e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE)) {
				return false;	
			}
		}
		
		glClear(GL_COLOR_BUFFER_BIT);
		
		drawWarpedPic(pic1, m1, maux, 255);
		drawWarpedPic(pic2, m2, maux, int((float)totalms/time * 255));
		
		if (showmesh)
			drawMesh2D(maux);
		
		SDL_GL_SwapBuffers();
	} while ((totalms += t.msec()) < time);
	
	return true;
}

bool parseArgs(MorphOptions &ops, int argc, char* argv[])
{
	bool ret = false;
	bool arg1 = false;
	int i;
	
	ops.mesh1    = "";
	ops.mesh2    = "";
	ops.pic1     = "";
	ops.pic2     = "";
    ops.time     = DEF_TIME; 
    ops.fps      = DEF_FPS;
    ops.showmesh = false;
    
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
			switch (argv[i][1]) {
			case 'm':
				if ((i+1) < argc) {
					ops.mesh1 = argv[i+1];
					i++;
				} break;
			case 'n':
				if ((i+1) < argc) {
					ops.mesh2 = argv[i+1];
					i++;
				} break;
			case 't':
				if ((i+1) < argc) {
					ops.time = atoi(argv[i+1]);
					i++;
				} break;
			case 'f':
				if ((i+1) < argc) {
					ops.fps = atoi(argv[i+1]);
					i++;
				} break;
			case 'd':
				ops.showmesh = true;
				break;
			case '?':
				ret = false; 
				break;
			}
        } else {
			if (!arg1) {
				ops.pic1 = argv[i];
				arg1 = true;
			} else {
				ops.pic2 = argv[i];
				ret = true;
			}
        }
    }
    
    return ret;
}

/* TODO */
void showHelp(const char* appname)
{
	cout << _("Usage:") << endl
		 << appname << _(" picture_one picture_two [options]") << endl << endl
		 << _("Options:") << endl
		 << _("  -t <int>   Play time in milliseconds.") << endl
		 << _("  -f <int>   FPS limit.") << endl
		 << _("  -m <str>   Alternative mesh file for the first pic.") << endl
		 << _("  -n <str>   Alternative mesh file for the second pic.") << endl
		 << _("  -d         Display the mesh as it transforms.") << endl
		 << _("  -?         Show this help screen.") << endl << endl
		 << _("If no mesh file is explictly set the program will try to load the same as each picture but with .mesh extension.") << endl;
}



