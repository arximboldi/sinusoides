<?php
echo urlencode("if(!parseInt(document.getElementById('r').value)!=1){}");
?>
