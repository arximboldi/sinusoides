/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;

/**
 * Construye y almacena los colores que utiliza la aplicación. Debe establecerse
 * un dispositivo antes de usarla.
 * 
 * @author raskolnikov
 * 
 */
public class ColorFactory
{	
	/**
	 * El color del nombre del jugador.
	 * @return El color del nombre del jugador.
	 */
	static public Color getName ()
	{
		return m_name_color.get ();
	}
	
	/**
	 * El color del tablero.
	 * @return El color del tablero.
	 */
	static public Color getTable ()
	{
		return m_table_color.get ();
	}
	
	/**
	 * El color del jugador.
	 * @return EL color del jugador.
	 */
	static public Color getPlayer ()
	{
		return m_player_color.get ();
	}

	/**
	 * El color del indicador del bote.
	 * @return EL color del indicador del bote
	 */
	static public Color getPot ()
	{
		return m_pot_color.get ();
	}
	

	/**
	 * Establece el dispositivo.
	 * @param display
	 */
	static public void setDevice (Display display)
	{
		m_display = display;
	}

	static private class LazyColor
	{
		int m_red, m_green, m_blue;
		
		LazyColor (int red, int green, int blue)
		{
			m_red = red;
			m_green = green;
			m_blue = blue;
		}
		
		Color get ()
		{
			if (m_color == null)
				m_color = new Color (ColorFactory.m_display, m_red, m_green, m_blue);
			return m_color;
		}
		
		private Color m_color = null; 
	}
	
	static private Display m_display;
	static private LazyColor m_name_color = new LazyColor (20, 20, 180);
	static private LazyColor m_table_color = new LazyColor (20, 128, 20);
	static private LazyColor m_player_color = new LazyColor (20, 200, 20);
	static private LazyColor m_pot_color = new LazyColor (255, 255, 20);
}
