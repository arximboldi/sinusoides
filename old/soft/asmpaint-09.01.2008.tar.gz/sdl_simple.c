/*
 * sdl_simple.c
 *
 * Juan Pedro Bolívar Puente
 *
 * Librería para el manejo sencillo de la SDL, SDL_ttf y SDL_ttf, orientada a usar
 * SDL desde ensamblador.
 *
 * Se pretende que el usuario utilice también la SDL, pero evitando
 * aquellas funciones que requieran de macros (sólo accesibles desde C) o
 * de estructuras complejas.
 */

#include <SDL/SDL.h>

#ifdef ENABLE_TTF
#include <SDL/SDL_ttf.h>
#endif

#ifdef ENABLE_IMAGE
#include <SDL/SDL_image.h>
#endif

#include <stdio.h>

enum event_types {
  EV_UNKNOWN,
  EV_KEY_DOWN,
  EV_KEY_UP,
  EV_MOUSE_DOWN,
  EV_MOUSE_UP,
  EV_MOUSE_MOVE,
  EV_QUIT,
  NUM_EV
};

static SDL_Event    curr_event;
static SDL_Surface* screen;

void init_sdl(int w, int h, int bpp, int fullscreen);
void close_sdl();
void set_caption(char* string);
void update_screen();
void update_screen_rect(int x, int y, int w, int h);
Uint32 map_colour(int r, int g, int b);
void lock_screen();
void unlock_screen();
void blit_surface(SDL_Surface* s, int x, int y);
void* get_surface_memory(SDL_Surface* s);
int get_surface_pitch(SDL_Surface* s);
int get_surface_width(SDL_Surface* s);
int get_surface_height(SDL_Surface* s);
void* get_screen_memory();
int get_screen_pitch();
int get_screen_width();
int get_screen_height();
int next_event();
int wait_event();
SDL_Event* get_event();
int get_event_type();
Uint16 get_key_event_ascii();
Uint16 get_mouse_motion_x();
Uint16 get_mouse_motion_y();
SDL_Surface* load_image(const char* fname);
void draw_image(int x, int y, SDL_Surface* s);

void init_sdl(int w, int h, int bpp, int fullscreen)
{
  int flags;
  
  if (SDL_Init(SDL_INIT_VIDEO) < 0) {
    fprintf(stderr, "No se puede iniciar SDL: %s\n", SDL_GetError());
    exit(-1);
  }

  flags = SDL_SWSURFACE;
  if (fullscreen)
    flags |= SDL_FULLSCREEN;
  
  screen = SDL_SetVideoMode(w, h, bpp, flags);

  if (screen == NULL) {
    fprintf(stderr, "No se puedo inicializar la pantalla: %s\n",
	    SDL_GetError());
    SDL_Quit();
    exit(-1);
  }

#ifdef ENABLE_TTF
  if(TTF_Init() < 0) {
    printf("Error al inicializar las fuentes: %s\n", TTF_GetError());
    exit(2);
  }
#endif
  
  SDL_EnableUNICODE(1);
  
  atexit(close_sdl);
}

void close_sdl()
{
#ifdef ENABLE_TTF
  TTF_Quit();
#endif
  
  SDL_Quit();
}

void set_caption(char* string)
{
  SDL_WM_SetCaption(string, 0);
}


void blit_surface(SDL_Surface* s, int x, int y)
{
  SDL_Rect dest;
  dest.x = x;
  dest.y = y;
  dest.w = s->w;
  dest.h = s->h;
  
  SDL_BlitSurface(s, NULL, screen, &dest);
}

void update_screen()
{
  SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
}

void update_screen_rect(int x, int y, int w, int h)
{
  SDL_UpdateRect(screen, x, y, w, h);
}

Uint32 map_colour(int r, int g, int b)
{
  return SDL_MapRGB(screen->format, r, g, b);
}

void lock_screen()
{
  if (SDL_MUSTLOCK(screen))
    SDL_LockSurface(screen);
}

void unlock_screen()
{
  if (SDL_MUSTLOCK(screen))
    SDL_UnlockSurface(screen);
}

void* get_surface_memory(SDL_Surface* s)
{
  return s->pixels;
}

int get_surface_pitch(SDL_Surface* s)
{
  return s->pitch;
}

int get_surface_width(SDL_Surface* s)
{
  return s->w;
}

int get_surface_height(SDL_Surface* s)
{
  return s->h;
}

void* get_screen_memory() 
{
  return screen->pixels;
}

int get_screen_pitch()
{
  return screen->pitch;
}

int get_screen_width()
{
  return screen->w;
}

int get_screen_height()
{
  return screen->h;
}

int next_event()
{
  return SDL_PollEvent(&curr_event);
}

int wait_event()
{
  return SDL_WaitEvent(&curr_event);
}

SDL_Event* get_event()
{
  return &curr_event;
}

int get_event_type()
{
  switch (curr_event.type) {
  case SDL_KEYUP:
    return EV_KEY_UP;

  case SDL_KEYDOWN:
    return EV_KEY_DOWN;

  case SDL_MOUSEBUTTONDOWN:
    return EV_MOUSE_DOWN;

  case SDL_MOUSEBUTTONUP:
    return EV_MOUSE_UP;

  case SDL_MOUSEMOTION:
    return EV_MOUSE_MOVE;

  case SDL_QUIT:
    return EV_QUIT;
    
  default:
    return EV_UNKNOWN;
  }
}

Uint16 get_key_event_ascii()
{
  return curr_event.key.keysym.unicode;
}

Uint16 get_mouse_motion_x()
{
  return curr_event.motion.x;
}

Uint16 get_mouse_motion_y()
{
  return curr_event.motion.y;
}

SDL_Surface* load_image(const char* fname)
{
  SDL_Surface* temp;
  SDL_Surface* ret = NULL;

  /*
   * Por algún motivo SDL_LoadBMP no puede ser llamado desde ensamblador.
   * Probablemente será que está definida como una macro aunque no diga nada
   * al respecto en la documentación.
   */
  
#ifdef ENABLE_IMAGE
  temp = IMG_Load(fname);
#else
  temp = SDL_LoadBMP(fname);
#endif
  
  if (temp) {
    ret = SDL_DisplayFormat(temp);
    SDL_FreeSurface(temp);
  }
  
  return ret;
}

void draw_image(int x, int y, SDL_Surface* s)
{
  SDL_Rect dest_rect;

  dest_rect.x = x;
  dest_rect.y = y;
  dest_rect.w = s->w;
  dest_rect.h = s->h;
  
  SDL_BlitSurface(s, NULL, screen, &dest_rect);
}
