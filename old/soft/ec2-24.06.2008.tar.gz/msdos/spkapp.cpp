
#include <iostream>

#include "spkapp.h"
#include "argparse.h"
#include "outspk.h"
#include "player.h"
#include "frraw.h"
#include "fltvol.h"
#include "fltecho.h"

using namespace std;

SpeakerApp::SpeakerApp() :
  m_param_help(false),
  m_param_echo(false),
  m_param_vol(1.0f),
  m_param_srate(22100.0),
  m_param_delayms(300.0),
  m_param_feedback(0.5),
  m_param_bufsize(4096)
{
}

void SpeakerApp::printHelp()
{
  cout << "speaker - Reproductor de musica por el PC speaker de DOS." << endl
       << "(c) 2008 Juan Pedro Bolivar Puente y Francisco Manuel Herrero Perez." << endl << endl
       << "uso:" << endl
       << "  speaker fichero_sonido" << endl << endl
       << "opciones" << endl
       << "  -h, --help           Muestra esta ayuda." << endl
       << "  -v, --vol <vol>      Ajusta el volumen del sonido, valor entre 0.0 y 1.0." << endl
       << "  -r, --rate <rate>    Ajusta la frecuencia de muestro de la reproduccion." << endl
       << "  -b, --bufsize <sie>  Cambia el tamano del buffer temporal" << endl
       << "  -e, --echo           Activa el efeco echo." << endl
       << "  -d, --delay <delay>  Ajusta el retardo del efecto eco en milisegundos." << endl
       << "  -f, --feedback <fb>  Ajusta la potencia de las repeticiones del efecto echo." << endl;
}

int SpeakerApp::run(int argc, const char* argv[])
{
  ArgParser parser;
  int retval;
  
  parser.add('h', "help", &m_param_help);
  parser.add('e', "echo", &m_param_echo);
  parser.add('d', "delay", &m_param_delayms);
  parser.add('f', "feedback", &m_param_feedback);
  parser.add('v', "vol", &m_param_vol);
  parser.add('r', "rate", &m_param_srate);
  parser.add('b', "bufsize", &m_param_bufsize);
  
  parser.parse(argc, argv);

  if (m_param_help) {
    printHelp();
    return -1;
  }

  if (parser.numFreeArgs() == 0) {
    cerr << "No has especificado nada para reproducir."
	 << " Usa --help para obtener mas informacion." << endl;
    return -1;
  }

  m_param_file = *parser.begin();

  retval = play();
  
  return retval;
}

int SpeakerApp::play()
{
  OutputSpeaker output(m_param_bufsize);
  Player player;
  FileReaderRaw file;

  player.setFile(&file);
  
  if (m_param_vol != 1.0f)
    player.attachFilter(new FilterVolume(m_param_vol));
  if (m_param_echo)
    player.attachFilter(new FilterEcho(m_param_delayms * m_param_srate / 1000.0f,
				       m_param_feedback));

  if (!file.open(m_param_file))
    cerr << "No se pudo abrir el archivo.\n";

  output.setSampleRate(m_param_srate);
  output.setListener(&player);

  output.open();
  output.start();
  
  output.close();

  file.close();
  return 0;
}

