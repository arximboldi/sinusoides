/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.gen;

import org.w3c.dom.*;

public class Page implements Generator
{
    String m_title = "Harmonic";
    String m_meta_author = "Juan Pedro Bolivar Puente y Luca Conesa Martin-Aragin";
    String m_meta_keys = "music, community, download, mp3";
    String m_style = "default";
    String m_footer = "Harmonic, libre music community. (c) JPBP & LCMA 2008.";
    
    String m_logo_title = "Harmonic";
    String m_logo_subtitle = "Share your rythm.";

    Division m_header_div = null;
    Division m_sidebar_div = null;
    Division m_content_div = null;
    Division m_footer_div = null;
    Division m_footer_wrap_div = null;
    
    public Page() {}

    public void setTitle(String title) {
	m_title = title;
    }

    public void setLogoTitle(String title) {
	m_logo_title = title;
    }

    public void setLogoSubtitle(String subtitle) {
	m_logo_subtitle = subtitle;
    }

    public Division getSidebar() {
	if (m_sidebar_div == null)
	    m_sidebar_div = new Division("sidebar");
	return m_sidebar_div;
    }

    public Division getHeader() {
	if (m_header_div == null)
	    m_header_div = new Division("header");
	return m_header_div;
    }

    public Division getContent() {
	if (m_content_div == null)
	    m_content_div = new Division("content");
	return m_content_div;
    }

    /*
    public Division getFooter() {
	if (m_footer_div == null) {
	    m_footer_div = new Division("footer");
	    m_footer_wrap_div = new Division("footer-wrap");
	    m_footer_div.addContent(m_footer_wrap_div);
	}
	return m_footer_wrap_div;
    }
    */
    
    public Node generate(Document doc)
    {
	Node root = generateRoot(doc);
	root.appendChild(generateHead(doc));
	root.appendChild(generateBody(doc));
	return root;
    }
    
    private Node generateRoot(Document doc)
    {
	Element el = doc.createElement("html");
	el.setAttribute("xmlns", "http://www.w3.org/1999/xhtml");

	return el;
    }
    
    private Node generateHead(Document doc)
    {
	Element head = doc.createElement("head");

	if (m_title != null) {
	    Element title = (Element) head.appendChild(doc.createElement("title"));
	    title.appendChild(doc.createTextNode(m_title));
	}
	
	Element meta;
	if (m_meta_author != null) {
	    meta = (Element) head.appendChild(doc.createElement("meta"));
	    meta.setAttribute("name", "author");
	    meta.setAttribute("content", m_meta_author);
	}
	
	if (m_meta_keys != null) {
	    meta = (Element) head.appendChild(doc.createElement("meta"));
	    meta.setAttribute("name", "keywords");
	    meta.setAttribute("content", m_meta_keys);
	}
	
	meta = (Element) head.appendChild(doc.createElement("meta"));
	meta.setAttribute("http-equiv", "Content-Type");
	meta.setAttribute("content", "text/html");

	if (m_style != null) {
	    Element style = (Element) head.appendChild(doc.createElement("link"));
	    style.setAttribute("href", "themes/" + m_style + "/style.css");
	    style.setAttribute("rel", "stylesheet");
	    style.setAttribute("type", "text/css");
	}
	
	return head;
    }
   
    private Node generateBody(Document doc)
    {
	Element body = doc.createElement("body");

	if (m_header_div != null)
	    body.appendChild(m_header_div.generate(doc));
		
	Division logo  = new Division("logo");
	logo.addContent(new Header(1, m_logo_title));
	logo.addContent(new Header(2, m_logo_subtitle));
	body.appendChild(logo.generate(doc));

	Division page = new Division("page");
	if (m_sidebar_div != null)
	    page.addContent(m_sidebar_div);
	if (m_content_div != null)
	    page.addContent(m_content_div);
	body.appendChild(page.generate(doc));

	/* No permitamos que el pie se sobreponga. */
	Element clear = doc.createElement("div");
	clear.setAttribute("style", "clear: both;");
	clear.appendChild(doc.createTextNode(" "));
	body.appendChild(clear);

	m_footer_div = new Division("footer");
	m_footer_wrap_div = new Division("footer-wrap");
	m_footer_div.addContent(m_footer_wrap_div);
	m_footer_wrap_div.addContent(new Paragraph(m_footer));
	body.appendChild(m_footer_div.generate(doc));
	
	return body;
    }
}
