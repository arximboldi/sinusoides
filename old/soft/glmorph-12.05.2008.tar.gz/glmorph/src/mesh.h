/**
 * @file   mesh.h
 * @author Juan Pedro Bol�var Puente
 * @date   April 2007
 * 
 * Copyright (C) 2007 by Juan Pedro Bol�var Puente
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __MESH_H__
#define __MESH_H__

#include <iostream>

struct Point2D {
	float x;
	float y;
};

class Mesh2D {
	Point2D** data;
	int w;
	int h;
	
	void freemem();
	int allocate(int w, int h);
	
public:
	Mesh2D(): data(NULL), w(0), h(0) {};
	
	Mesh2D(const Mesh2D &m);
		
	Mesh2D(int w, int h);
	
	Mesh2D(int w, int h, int picw, int pich);
	
	~Mesh2D();
	
	Mesh2D& operator= (const Mesh2D& m);
	
	friend std::ostream& operator << (std::ostream& stream, const Mesh2D &m);
	friend std::istream& operator >> (std::istream& stream, Mesh2D &m);
	
	void defaults(int picw, int pich);
	
	bool load(const char* path);
	
	bool store(const char* path) const;
	
	void set(int x, int y, const Point2D& p) {
		data[x][y] = p;
	};
	
	void set(int x, int y, float px, float py) {
		data[x][y].x = px;
		data[x][y].y = py;
	};
	
	Point2D get(int x, int y) const {
		return data[x][y];
	};
	
	int width() const {
		return w;
	};
	
	int height() const {
		return h;
	};
	
	void swap(Mesh2D &m1) {
		std::swap(m1.data, data);
		std::swap(m1.w, w);
		std::swap(m1.h, h);
	};
	
	friend void swap(Mesh2D &m1, Mesh2D &m2) {
		std::swap(m1.data, m2.data);
		std::swap(m1.w, m2.w);
		std::swap(m1.h, m2.h);
	};
};

#endif /* __MESH_H__ */
