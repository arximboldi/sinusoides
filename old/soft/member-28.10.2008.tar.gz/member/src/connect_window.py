#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade

import common
from dao import *
from gui_tools import *

class ConnectWindow (GladeDialog):
    def __init__(self, user, host, database):
        GladeDialog.__init__ (self, common.GUI_CONNECT, 'connect-window')
        self.get_widget ('combo-system').set_active (0)
        self.get_widget ('entry-user').set_text (user);
        self.get_widget ('entry-host').set_text (host);
        self.get_widget ('entry-database').set_text (database);
        self._root.connect ('delete-event', lambda w, e: w.hide() or True)
    
    def get_user (self):
        return self.get_widget ('entry-user').get_text ();

    def get_database (self):
        return self.get_widget ('entry-database').get_text ();

    def get_host (self):
        return self.get_widget ('entry-host').get_text ();

    def handle_connect_clicked (self, win):
        try:
            user     = self.get_widget ('entry-user').get_text ();
            password = self.get_widget ('entry-password').get_text ();
            host     = self.get_widget ('entry-host').get_text ();
            database = self.get_widget ('entry-database').get_text ();
            system   = self.get_widget ('combo-system').get_active_text ();

            fm = DaoFactoryMgr ()
            fm.default (system)
            fm.connect (host, database, user, password)
            if not fm.check_db ():
                res = show_yesno_dialog ('<b>The software does not seem to be installed in this database.</b>\n\nDo you want to install it now?\n\n<i>Note: You may loose information previously stored in the database.</i>')
                if res == gtk.RESPONSE_YES:
                    fm.install_db ()
                else:
                    fm.disconnect ()
                    self.response (gtk.RESPONSE_REJECT)

        except Exception, e:
            show_error_dialog ('Could not connect to database', str (e))
            self.response (gtk.RESPONSE_REJECT)
