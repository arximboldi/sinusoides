/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic;

import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;
import java.util.*;
    
public class Harmonic extends HttpServlet
{
    QueryFactoryManager m_query_factory;
    
    public void init(ServletConfig conf)
        throws ServletException
    {
        super.init(conf);

	m_query_factory = new QueryFactoryManager();
	m_query_factory.register("/", new FrontpageQuery.Factory());
	m_query_factory.register("/home", new FrontpageQuery.Factory());
	m_query_factory.register("/login", new LoginQuery.Factory());
	m_query_factory.register("/register", new CreateUserQuery.Factory());
	m_query_factory.register("/user", new UserQuery.Factory());
	m_query_factory.register("/search", new SearchQuery.Factory());
    }
    
    public void doGet(HttpServletRequest request,
		      HttpServletResponse response)
	throws ServletException,
	       IOException
    {	
	try {    
	    QueryHandler query = new QueryHandler(m_query_factory,
						  request,
						  response);
	    query.run();
	} catch (Exception e) {
	    fallbackErrorPage(e, response.getWriter());
	}
    }

    public void doPost(HttpServletRequest request,
		       HttpServletResponse response)
	throws ServletException, IOException {
	doGet(request, response);
    }
    
    public void fallbackErrorPage(Exception e, PrintWriter out)
    {
	out.print("<html>\n" +
		  "<head><title>\n" +
		  "Harmonic: Internal Error</title>\n" +
		  "<link href=\"themes/default/style.css\" rel=\"stylesheet\" type=\"text/css\">" +
		  "</head><\n" +
		  "<body><div id=\"page\">" +
		  "<h1>Harmonic</h1>" + 
		  "<h2>Internal Error</h2>" +
		  "<p>There has been a grave internal error. Please contact the site administrator.</p>" +
		  "<hr><h3>Exception</h3>"  + e.toString()  + 
		  "<br><br><h3>Stack trace</h3>");

	e.printStackTrace(out);

	out.print("</div></body>\n" +
		  "</html>");
    }
}
