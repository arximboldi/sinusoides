/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import game.Card;

import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Image;

/**
 * Construye las imagenes básicas del juego y guarda una caché de ellas.
 * Antes de poder usarse hay que elegir un dispositivo.
 * @author raskolnikov
 * @todo dispose ()
 */
public class ImageFactory
{
	/**
	 * Establece el dispositivo sobre el que se crearán las imagenes.
	 * @param dev
	 */
	static void setDevice (Device dev)
	{
		m_device = dev;
	}
	
	/**
	 * Obtiene el logo del programa.
	 * @return El logo del programa.
	 */
	static public Image getLogo ()
	{
		if (m_logo == null) {
			m_logo = new Image (m_device, "data/logo.tiff");
			m_logo.setBackground (ColorFactory.getTable ());
		}
		
		return m_logo;
	}
	
	/**
	 * La image de atrás de las cartas.
	 * @return La parte de atras de las cartas.
	 */
	static public Image getBackside ()
	{
		if (m_back == null) {
			m_back = new Image (m_device, "data/cards/bs.gif");
		}
		
		return m_back;
	}
	
	/**
	 * Una carta vacia.
	 * @return La carta vacia.
	 */
	static public Image getVoid ()
	{
		if (m_void == null) {
			m_void = new Image (m_device, "data/cards/void.gif");
		}
		
		return m_void;
	}
	
	/**
	 * Devuelve la imagen que representa una carta dada.
	 * @param c La carta a visualizar.
	 * @return La imagen de la carta.
	 */
	static public Image getCard (Card c)
	{
		int index = (c.getRank () - 1) + 13 * c.getSuit ().ordinal ();
		
		if (m_cards [index] == null) {
			m_cards [index] = new Image (m_device, "data/cards/" + 
					mangleCardName (c) + ".gif");
		}
		
		return m_cards [index];
	}
	
	static private String mangleRank (int r)
	{
		String[] names = {"2", "3", "4", "5", "6", "7", "8", "9", "t", "j", "q", "k", "a"};
		return names [r];
	}
	
	static private String mangleSuit (Enum c)
	{
		return "" + Character.toLowerCase (c.toString ().charAt (0));
	}
	
	static private String mangleCardName (Card c)
	{
		//return (c.getSuit ().toString().toLowerCase () + c.getRank ());
	
		return mangleRank (c.getRank () -1) + mangleSuit (c.getSuit ());
	}
	
	static private Device m_device = null;
	static private Image m_logo = null;
	static private Image m_back = null;
	static private Image m_void = null;
	static private Image [] m_cards = new Image [52];
}
