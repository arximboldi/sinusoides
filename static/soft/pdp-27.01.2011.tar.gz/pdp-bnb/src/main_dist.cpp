/**
 *  Time-stamp:  <2011-01-18 04:24:33 raskolnikov>
 *
 *  @file        dist_main.cpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Sat Jan 15 14:34:54 2011
 *
 *  Main de la version paralela.
 */

#include <iostream>

#include "pdp/uni_dist_graph.hpp"
#include "pdp/dist_bnb.hpp"
#include "pdp/tsp.hpp"
#include "pdp/generic_graph_main.hpp"

int main (int argc, char** argv)
{
    using namespace pdp;

    return generic_graph_main<
        generic_graph_algo<
            bnb::dist_branch_and_bound_fn<tsp::node<int>, full_dist_graph<int> >,
            full_dist_graph<int> > > (argc, argv);
}
