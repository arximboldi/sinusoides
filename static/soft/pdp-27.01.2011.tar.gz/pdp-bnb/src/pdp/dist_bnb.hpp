/**
 *  Time-stamp:  <2011-01-19 04:06:03 raskolnikov>
 *
 *  @file        dist_bnb.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Sat Jan 15 14:27:44 2011
 *
 *  Version paralela del algoritmo de Branch and Bound.
 */

#ifndef PDP_DIST_BNB_H_
#define PDP_DIST_BNB_H_

#include <mpi.h>

#include "bnb.hpp"

namespace pdp
{
namespace bnb
{

template <typename Node>
class dist_state : public state <Node>
{
public:
    typedef state<Node> base;
    typedef typename base::cost_type cost_type;
    
    dist_state (const Node& initial, MPI::Intracomm& comm, int root);
    
    bool share_work ();

    void share_best_cost ();

    void merge_results ();
    
    cost_type best_cost () const { return _best_cost; }

    void push (const Node& node)
    {
        base::push (node);
        _best_cost = std::min (base::best_cost (), _best_cost);
    }
    
private:
    typedef typename base::stack_type stack_type;
    
    enum color
    {
        color_black = 0,
        color_white
    };

    void handle_msg_work_request (MPI::Status& status);
    void handle_msg_work_arrival (MPI::Status& status);
    bool handle_msg_baton (MPI::Status& status);
    bool handle_msg_finish (MPI::Status& status);
    void splice_work (stack_type& new_stack);
    
    MPI::Comm&      _comm;
    MPI::Intracomm  _bc_comm;
    cost_type       _best_cost;
    int             _root;
    bool            _active;
    color           _color;
    bool            _has_baton;
    bool            _bcast_local_bc;
    bool            _wait_bc_return;
};

template <typename Node, typename Context>
Node dist_branch_and_bound (Context& ctx, MPI::Intracomm& comm, int root);

template <typename Node, typename Context>
struct dist_branch_and_bound_fn
{
    typedef Node result_type;
    
    Node operator () (Context& ctx,
                      MPI::Intracomm& comm = MPI::COMM_WORLD,
                      int root        = 0) const
    {
        return dist_branch_and_bound<Node> (ctx, comm, root);
    }
};

} /* namespace bnb */
} /* namespace pdp */

#include "dist_bnb.tpp"

#endif /* PDP_BNB_PAR_H_ */
