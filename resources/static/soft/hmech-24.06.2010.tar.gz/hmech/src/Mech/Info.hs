{-# LANGUAGE PatternGuards #-}
--
--  File:       Info.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon Mar 16 15:14:30 2009
--  Time-stamp: <2009-05-31 12:31:33 raskolnikov>
--
--  Definición de los datos de los mech.
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Mech.Info where

import Maybe
import Data.Ix
import Data.Array

data ArmourLocation = ArmourLeftArm 
                    | ArmourLeftTrunk
                    | ArmourLeftLeg
                    | ArmourRightLeg
                    | ArmourRightTrunk
                    | ArmourRightArm
                    | ArmourTrunk
                    | ArmourHead
                    | ArmourLeftBackTrunk
                    | ArmourRightBackTrunk
                    | ArmourBackTrunk
                      deriving (Ord, Eq, Enum, Show, Read, Ix)

armourRange = (ArmourLeftArm, ArmourBackTrunk)

data Location = LeftArm
              | LeftTrunk
              | LeftLeg
              | RightLeg
              | RightTrunk
              | RightArm
              | Trunk
              | Head
                deriving (Ord, Eq, Enum, Show, Read, Ix)

locationRange = (LeftArm, Head)

isFrontArmourLocation :: ArmourLocation -> Bool
isFrontArmourLocation ArmourLeftArm       = True
isFrontArmourLocation ArmourLeftTrunk     = True
isFrontArmourLocation ArmourLeftLeg       = True
isFrontArmourLocation ArmourRightLeg      = True
isFrontArmourLocation ArmourRightTrunk    = True
isFrontArmourLocation ArmourRightArm      = True
isFrontArmourLocation ArmourTrunk         = True
isFrontArmourLocation ArmourHead          = True
isFrontArmourLocation _                   = False

toLocation :: ArmourLocation -> Location
toLocation ArmourLeftArm = LeftArm 
toLocation ArmourLeftTrunk = LeftTrunk
toLocation ArmourLeftLeg = LeftLeg
toLocation ArmourRightLeg = RightLeg
toLocation ArmourRightTrunk = RightTrunk
toLocation ArmourRightArm = RightArm
toLocation ArmourTrunk = Trunk
toLocation ArmourHead = Head
toLocation ArmourLeftBackTrunk = LeftTrunk
toLocation ArmourRightBackTrunk = RightTrunk
toLocation ArmourBackTrunk = Trunk

data Direction = Forward
               | Backward
               | LeftDir
               | RightDir
               | Up
               | Down
                 deriving (Ord, Eq, Enum, Show, Read)

data Side = North
          | NorthEast
          | SouthEast
          | South
          | SouthWest
          | NorthWest
            deriving (Ord, Eq, Enum, Ix, Show, Read)

data Hex = Hex { hexX :: Int
               , hexY :: Int }
         deriving (Ord, Eq, Ix, Show, Read)

data Position = Pos { posHex :: Hex, posSide :: Side }
              deriving (Ord, Eq, Ix, Show, Read)

data Terrain = Open
             | Asphalt
             | Water
             | Swamp
               deriving (Ord, Eq, Enum, Show, Read)

data Object = Rubble
            | LightWood
            | HeavyWood
            | LightBuilding
            | MediumBuilding
            | HeavyBuilding
            | StrongBuilding
            | Bunker
            | Empty
              deriving (Ord, Eq, Enum, Show, Read)

data ArmPart = Arms
             | LeftShoulder
             | LeftUpperarm
             | LeftForearm
             | LeftHand
             | RightShoulder
             | RightUpperarm
             | RightForearm
             | RightHand
               deriving (Ord, Ix, Eq, Enum, Show, Read)

data Item = EmptyItem
          | WeaponItem
          | AmmoItem
          | EquipmentItem
          | ActuatorItem
          | ArmourItem
          | PhisicalItem
            deriving (Ord, Eq, Enum, Show, Read)

data WeaponType = NoneWeapon
                | Energy
                | Gun
                | Missile
                  deriving (Ord, Eq, Enum, Show, Read)

data Cell = Cell { level :: Int
                 , terrain :: Terrain
                 , object :: Object  -- if (x != 255) then toEnum (x-1) else None
                 , buildingFce :: Int
                 , buildingDemolished :: Bool
                 , cellFire :: Bool
                 , smoke :: Bool
                 , clubs :: Int
                 , river :: [Bool] -- 6 lados
                 , road :: [Bool] -- 6 lados
                 } deriving (Show, Read)

type Map = Array Hex Cell

data Component = Component { code :: Int
                           , name :: String
                           , item :: Item -- Especifico
                           , onBack :: Bool
                           , location :: ArmourLocation -- toEnum
                           , secondaryLoc :: Maybe ArmourLocation -- toEnum
                           , weptype :: WeaponType -- Especifico
                           , heatGen :: Int
                           , damage :: Int
                           , shotsPerTurn :: Int
                           , minDistance :: Int
                           , shortDistance :: Int
                           , mediumDistance :: Int
                           , longDistance :: Int
                           , compOperative :: Bool
                           , weaponCode :: Int -- Si es municion
                           , amount :: Int
                           , isSpecial :: Bool
                           , shotMod :: Int
                           } deriving (Show, Read)

data Actuator = Actuator { actCode :: Int
                         , actName :: String
                         , actLocation :: ArmourLocation -- toEnum
                         , actOperative :: Bool
                         , impacts :: Int
                         } deriving (Show, Read)

data SlotDef = SlotDef { slotItem :: Item -- Especifico
                       , slotAmount :: Int -- solo ammo?
                       , slotCode :: Int
                       , slotName :: String
                       , componentIndex :: Int
                       , actuatorIndex :: Int
                       , criticalDamage :: Int
                       } deriving (Show, Read)

data MechDef = MechDef { mechName :: String
                       , model :: String
                       , weight :: Int
                       , power :: Int
                       , internalRadiators :: Int
                       , radiators :: Int
                       , hasMasc :: Bool
                       , hasDacmtd :: Bool
                       , hasDacmti :: Bool
                       , hasDacmtc :: Bool
                       , maxGeneratedHeat :: Int
                       , hasArm :: [Bool] -- ArmParts
                       , defArmourPoints :: [Int] -- ArmourLocation
                       , defInternalPoints :: [Int] -- InternalLocation
                       , components :: [Component]
                       , actuators :: [Actuator]
                       , slots :: [[SlotDef]]
                       } deriving (Show, Read)

data Slot = Slot { loc :: Location, offset :: Int } deriving (Show, Read)

data Mech = Mech { playerNum :: Int
                 , operative :: Bool
                 , disconnected :: Bool
                 , blockedInSwamp :: Bool
                 , onFloor :: Bool
                 , position :: Hex
                 , side :: Side
                 , trunkSide :: Side
                 , heat :: Int
                 , burning :: Bool
                 , club :: Bool
                 , treeClub :: Bool -- Leer como 0/1
                 , armourPoints :: Array ArmourLocation Int
                 , internalPoints :: Array Location Int
                 , defmech :: MechDef
                 } deriving (Show, Read)

totalArmourPoints = sum . elems . armourPoints


data Player = Player { walkPoints :: Int
                     , runPoints :: Int
                     , jumpPoints :: Int
                     , radiatorsOn :: Int
                     , radiatorsOff :: Int
                     , warriorInjuries :: Int
                     , warriorConscious :: Bool
                     , criticalSlots :: [Bool]
                     , weaponShot :: [Bool]
                     , ammo :: [Slot]
                     } deriving (Show, Read)

data Config = Config { hasFire :: Bool
                     , wind :: Bool
                     , windDir :: Side
                     , phisicalPhase :: Bool
                     , heatPhase :: Bool
                     , devastateWood :: Bool
                     , destroyBuilding :: Bool
                     , pilotCheck :: Bool
                     , pilotCheckOneTurn :: Bool
                     , disconnectionCheck :: Bool
                     , critical :: Bool
                     , ammoExplosion :: Bool
                     , radiatorShutodown :: Bool
                     , hasTimeLimit :: Bool
                     , timeLimit :: Int
                     } deriving (Show, Read)

data State = State { mechs :: [Mech]
                   , current :: Mech
                   , player :: Player
                   , smap :: Map
                   , config :: Config
                   , order :: [Int]
                   } deriving (Show, Read)

--
-- Numero de elementos en los enumerados
--
numArmourLocation = 11 :: Int
numLocation       = 8  :: Int
numSide           = 6  :: Int
numArmParts       = 9  :: Int

--
--  Cantidad de slots para las distintas partes del cuerpo.
--
numLeftArmSlots    = 11 :: Int
numLeftTrunkSlots  = 11 :: Int
numLeftLegSlots    = 5  :: Int
numRightLegSlots   = 5  :: Int
numRightTrunkSlots = 11 :: Int
numRightArmSlots   = 11 :: Int
numTrunkSlots      = 11 :: Int
numHeadSlots       = 5  :: Int
numTotalSlots      = 78 :: Int

--
-- Implementación de de Hex en la clase Num. Utiliza semántica
-- parecida a la vectorial.
--
instance Num Hex where
    (Hex a b) + (Hex c d) = Hex (a+c) (b+d)
    (Hex a b) - (Hex c d) = Hex (a-c) (b-d)
    (Hex a b) * (Hex c d) = Hex (a*c) (b*d)
    negate (Hex a b)      = Hex (negate a) (negate b)
    abs (Hex a b)         = Hex (abs a) (abs b)
    signum (Hex a b)      = Hex (signum a) (signum b)
    fromInteger x         = Hex (div (fromInteger x) 10) (mod (fromInteger x) 10)

--
-- La distancia al cuadrado entre dos Hex
--
hexDistSqr :: Hex -> Hex -> Int
hexDistSqr (Hex a b) (Hex c d) = (a-c)*(a-c) + (b-d)*(b-d)

--
-- La distancia real entre dos Hex
--
hexDist :: (Floating a) => Hex -> Hex -> a
hexDist x y = sqrt $ fromIntegral $ hexDistSqr x y

--
-- La distancia de Manhatan entre dos Hex
--
hexDistMan :: Hex -> Hex -> Int
hexDistMan (Hex a b) (Hex c d) = abs (a - c) + abs (b - d)

--
-- El hexágono nulo (el mapa comienza en 1 1)
--
nullHex :: Hex
nullHex = Hex 0 0

--
-- Da las coordenadas del hexágono siguiente en uno de los lados
--
nextHex :: Hex -> Side -> Hex
nextHex hex side = hex + nextHexDiff hex side

--
-- Calcula el incremento que hay entre un hexágono y el siguiente
-- dados el el hexágono y el lado en el que queremos avanzar.
--
nextHexDiff :: Hex -> Side -> Hex
nextHexDiff (Hex x y) North     = Hex    0 (-1)
nextHexDiff (Hex x y) NorthEast 
    | odd x                     = Hex    1 (-1)
    | otherwise                 = Hex    1    0
nextHexDiff (Hex x y) SouthEast 
    | odd x                     = Hex    1    0
    | otherwise                 = Hex    1    1
nextHexDiff (Hex x y) South     = Hex    0    1
nextHexDiff (Hex x y) SouthWest 
    | odd x                     = Hex (-1)    0
    | otherwise                 = Hex (-1)    1
nextHexDiff (Hex x y) NorthWest 
    | odd x                     = Hex (-1)  (-1)
    | otherwise                 = Hex (-1)    0

--
-- Devuelve el lado en el que se tocan dos hexágonos, respecto
-- al primer hexágono. La función falla si no son adyacentes.
--
hexSide :: Hex -> Hex -> Side
hexSide src dest = hexDiffToSide (odd $ hexX src) (dest-src)
    where
      hexDiffToSide :: Bool -> Hex -> Side
      hexDiffToSide _     (Hex 0    (-1)) = North
      hexDiffToSide True  (Hex 1    (-1)) = NorthEast
      hexDiffToSide False (Hex 1       0) = NorthEast
      hexDiffToSide True  (Hex 1       0) = SouthEast
      hexDiffToSide False (Hex 1       1) = SouthEast
      hexDiffToSide _     (Hex 0       1) = South
      hexDiffToSide True  (Hex (-1)    0) = SouthWest
      hexDiffToSide False (Hex (-1)    1) = SouthWest
      hexDiffToSide True  (Hex (-1) (-1)) = NorthWest
      hexDiffToSide False (Hex (-1)    0) = NorthWest
      hexDiffToSide _     _ = error "El hexagono no es adyacente"

--
-- Devuelve el lado en el que se tocan dos hexágonos, respecto
-- al primer hexágono. La función devuelve Nothing si no
-- son adjacentes.
--
safeHexSide :: Hex -> Hex -> Maybe Side
safeHexSide src dest = hexDiffToSide (odd $ hexX src) (dest-src)
    where
      hexDiffToSide :: Bool -> Hex -> Maybe Side
      hexDiffToSide _     (Hex 0    (-1)) = Just North
      hexDiffToSide True  (Hex 1    (-1)) = Just NorthEast
      hexDiffToSide False (Hex 1       0) = Just NorthEast
      hexDiffToSide True  (Hex 1       0) = Just SouthEast
      hexDiffToSide False (Hex 1       1) = Just SouthEast
      hexDiffToSide _     (Hex 0       1) = Just South
      hexDiffToSide True  (Hex (-1)    0) = Just SouthWest
      hexDiffToSide False (Hex (-1)    1) = Just SouthWest
      hexDiffToSide True  (Hex (-1) (-1)) = Just NorthWest
      hexDiffToSide False (Hex (-1)    0) = Just NorthWest
      hexDiffToSide _     _               = Nothing


--
-- Da la vuelta a un lado.
--
flipSide :: Side -> Side
flipSide = let doFlip x = (x + 3) `mod` 6
           in toEnum . doFlip . fromEnum

--
-- Da la rotación de un lado para encararse con otro por el camino
-- más corto.
--
rotationDir :: Side -> Side -> (Direction, Int)
rotationDir src dest = if rotR == 0 
                       then (Forward, 0)
                       else if rotR <= rotL 
                            then (RightDir, rotR)
                            else (LeftDir, rotL)
    where
      v1 = fromEnum src
      v2 = fromEnum dest
      rotL = (v1 - v2) `mod` 6
      rotR = (v2 - v1) `mod` 6

--
-- Aplica una rotación sobre un lado.
--
rotateDir :: Side -> (Direction, Int) -> Side
rotateDir s (LeftDir,  x) = rotate s (-x)
rotateDir s (RightDir, x) = rotate s x
rotateDir s _             = s

--
-- Igual que rotationDir pero utilizando el signo para denotar
-- la dirección.
--
rotation :: Side -> Side -> Int
rotation src dest = let v1 = fromEnum src
                        v2 = fromEnum dest
                        rotR = (v1 - v2) `mod` 6 
                        rotL = (v2 - v1) `mod` 6 
                    in if rotR == 0 || rotR <= rotL
                       then rotR
                       else (-rotL)

--
-- Igual que rotateDir pero utilizando el signo para denotar la
-- dirección
--
rotate :: Side -> Int -> Side
rotate s n  = toEnum $ (fromEnum s + n) `mod` 6

--
-- El lado siguiente
--
nextSide :: Side -> Side
nextSide s = rotate s 1

--
-- El lado anterior
--
prevSide :: Side -> Side
prevSide s = rotate s (-1)

--
-- Comprueba si un hexágono entra dentro de los límites de un mapa
--
hexInMap :: Map -> Hex -> Bool
hexInMap m h = inRange (bounds m) h

--
-- ¿Es un edificio?
--
isBuilding :: Object -> Bool
isBuilding LightBuilding   = True
isBuilding MediumBuilding  = True
isBuilding HeavyBuilding   = True
isBuilding StrongBuilding  = True
isBuilding _               = False

--
-- ¿Es un bosque el objeto?
--
isWood :: Object -> Bool
isWood LightWood = True
isWood HeavyWood = True
isWood _         = False

--
-- ¿Son adyacentes dos hexágonos?
--
touches :: Hex -> Hex -> Bool
touches src = isJust . safeHexSide src

--
-- Encuentra un componente entre los slots de un Mech
--
findComponent :: MechDef -> Component -> Maybe Slot
findComponent mech comp = dorow (slots mech) (Slot (fst locationRange) 0) 
    where
      dorow [] _ = Nothing 
      dorow (x:xs) ac | Right res <- doitem x ac = Just res
                      | otherwise = dorow xs (nextRow ac)
      
      doitem [] ac = Left ac
      doitem (x:xs) ac | slotCode x == code comp = Right ac
                       | otherwise = doitem xs (nextItem ac)

      nextRow  (Slot loc s) = Slot (succ loc) s
      nextItem (Slot loc s) = Slot loc (s+1)

--
-- Encuentra todas las apariciones de un componente entre los slots
-- de un Mech
--
findComponentList :: MechDef -> Component -> [Slot]
findComponentList mech comp = dorow (slots mech) (Slot LeftArm 0) [] 
    where
      dorow [] ac res = res 
      dorow (x:xs) ac res = dorow xs (nextrow ac) (doitem x ac res)
      
      doitem [] ac res = res 
      doitem (x:xs) ac res = doitem xs (nextitem ac) 
                             (if code comp == slotCode x
                              then ac:res 
                              else res)

      nextrow  (Slot loc s) = Slot (succ loc) s
      nextitem (Slot loc s) = Slot loc (s+1)

