%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       noise_gaussian_additive.m
%  Time-stamp: <2011-01-23 22:48:59 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Ruido gausiano aditivo.
%

function img = noise_gaussian_additive (img, mean, var)
    img = bound_gray (double (img) + double (mean + sqrt (var) * rand (size (img))));
end
