#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

import pygtk
pygtk.require('2.0')
import gtk

import common
import datetime
import time

class GladeWindow:
    def __init__ (self, file_name, root_name):
        self._glade = gtk.glade.XML (file_name)
        self._glade.signal_autoconnect (self)
        self._root = self._glade.get_widget (root_name)

    def get_widget (self, name):
        return self._glade.get_widget (name)

    def show (self):
        self._root.show ()

    def hide (self):
        self._root.hide ()

    def destroy (self):
        self._root.destroy ()

class GladeDialog (GladeWindow):
    def __init__ (self, file_name, root_name):
        GladeWindow.__init__ (self, file_name, root_name)

    def run (self):
        return self._root.run ()

    def response (self, id):
        self._root.response (id)

class GladeErrorDialog (GladeDialog):
    def __init__ (self, short_str, long_str):
        GladeDialog.__init__ (self, common.GUI_ERROR, 'window-error')
        self.get_widget ('label-message').set_text ('<b>' + short_str + '</b>')
        self.get_widget ('label-message').set_use_markup (True)
        self.get_widget ('text-message').get_buffer(). set_text (long_str)

def set_sensitive (wid):
    wid.set_sensitive (True)

def unset_sensitive (wid):
    wid.set_sensitive (False)

def show_error_dialog (message, long_message):
    error_dlg = GladeErrorDialog (message, long_message)
    res = error_dlg.run ()
    error_dlg.destroy ()
    return res

def show_yesno_dialog (message):
    error_dlg = gtk.MessageDialog (flags = gtk.DIALOG_MODAL, buttons = gtk.BUTTONS_YES_NO)
    error_dlg.set_markup (message)
    res = error_dlg.run ()
    error_dlg.destroy ()
    return res

def my_strptime (date_string, format):
    return datetime.datetime (*(time.strptime(date_string, format)[0:6]))

def update_preview_cb(file_chooser, preview):
    filename = file_chooser.get_preview_filename()
    try:
        pixbuf = gtk.gdk.pixbuf_new_from_file_at_size(filename, 128, 128)
        preview.set_from_pixbuf(pixbuf)
        have_preview = True
    except:
        have_preview = False
    file_chooser.set_preview_widget_active(have_preview)
    return

def cell_date_function (column, cell, model, iter):
    dt = model.get_value (iter, 0)
    return dt.strftime (common.DATE_FORMAT)

def sort_func_date (model, iter1, iter2):
    val1 = model.get_value (iter1, 0)
    val2 = model.get_value (iter2, 0)
    chunks1 = map (int, val1.split ('/'))
    chunks2 = map (int, val2.split ('/'))
    if chunks1 [2] < chunks2 [2]:
        return -1
    elif chunks1 [2] == chunks2 [2]:
        if chunks1 [1] < chunks2 [1]:
            return -1
        elif chunks1 [1] == chunks2 [1]:
            if chunks1 [0] < chunks2 [0]:
                return -1
            elif chunks1 [0] > chunks2 [0]:
                return 1
            else:
                return 0
        else:
            return 1
    else:
        return 1

def none_strftime (date):
    if date:
        return date.strftime (common.DATE_FORMAT)
    return None
