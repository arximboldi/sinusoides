
#ifndef FILTERECHO_H
#define FILTERECHO_H

#include "filter.h"

class FilterEcho : public Filter
{
  float* m_buffer;
  int m_delay;
  int m_pos;
  float m_feedback;
  float m_hidamp;
  float m_old_val;

  void allocate();
  void liberate();
 public:
  FilterEcho(int delay, float feedback = 0.5f, float hidamp = 0.5f);
  ~FilterEcho();
  void process(Sample* in, int n_samples);
};

#endif /* FILTERECHO_H */
