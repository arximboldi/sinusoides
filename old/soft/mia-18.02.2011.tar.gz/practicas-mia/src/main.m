%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  (c) 2010-2011 Juan Pedro Bolívar Puente
%  
%  Autor:      Juan Pedro Bolívar Puente
%  File:       mia.m
%  Time-stamp: <2011-01-22 19:24:34 raskolnikov>
%
%  Este fichero contiene la interfaz gráfica. Como este fichero se
%  modifica automáticamente por GUIDE, intentamos delegar la
%  implementación a gui.m.
%

function varargout = main(varargin)
% Last Modified by GUIDE v2.5 29-Jan-2011 08:05:37

% Begin initialization code - DO NOT EDIT
    gui_Singleton = 1;
    gui_State = struct('gui_Name',       mfilename, ...
                       'gui_Singleton',  gui_Singleton, ...
                       'gui_OpeningFcn', @main_OpeningFcn, ...
                       'gui_OutputFcn',  @main_OutputFcn, ...
                       'gui_LayoutFcn',  [] , ...
                       'gui_Callback',   []);
    if nargin && ischar(varargin{1})
        gui_State.gui_Callback = str2func(varargin{1});
    end

    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
% End initialization code - DO NOT EDIT


% --- Executes just before main is made visible.
function main_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main (see VARARGIN)

% Choose default command line output for main
    handles.output = hObject;

    handles.gui = multi_image_ui (handles);

    axes (handles.axes2), axis image off;
    axes (handles.axes3), axis image off;
    axes (handles.axes1), axis image off;

    set (handles.text_cols,    'Visible', 'off');
    set (handles.text_rows,    'Visible', 'off');
    set (handles.edit_cols,    'Visible', 'off');
    set (handles.edit_rows,    'Visible', 'off');

    set (handles.edit_mean,      'Visible', 'off');
    set (handles.edit_variance,  'Visible', 'off');
    set (handles.text_mean,      'Visible', 'off');
    set (handles.text_variance, 'Visible', 'off');
    set (handles.edit_alfa,     'Visible', 'off');
    set (handles.text_alfa,     'Visible', 'off');
    set (handles.edit_salt,     'Visible', 'off');
    set (handles.edit_pepper,   'Visible', 'off');
    set (handles.text_salt,     'Visible', 'off');
    set (handles.text_pepper,   'Visible', 'off');

    set (handles.edit_filter_sigma, 'Visible', 'off');
    set (handles.text_filter_sigma, 'Visible', 'off');

    set (handles.slider_profile_row, 'Enable', 'off');
    set (handles.text_profile_row,   'Enable', 'off');
    set (handles.radio_profile_line, 'Enable', 'off');
    set (handles.radio_profile_area, 'Enable', 'off');

    set (handles.check_edge_thinning,    'Enable', 'on');
    set (handles.edit_edge_threshold,    'Enable', 'on');
    set (handles.edit_edge_threshold_2,  'Enable', 'off');
    set (handles.edit_edge_sigma,        'Enable', 'off');
    set (handles.check_edge_threshold,   'Enable', 'on');
    set (handles.group_edge_grad,        'Visible', 'on');
    set (handles.radio_edge_grad_2,      'String', 'Vert.');
    set (handles.radio_edge_grad_3,      'String', 'Horiz');

    set (handles.panel_edge, 'Visible', 'on');
    set (handles.panel_corner, 'Visible', 'off');
    
    guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = main_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
    varargout{1} = handles.output;

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    [base_fname, path_name, filter_index] = uigetfile(...
        {'*.jpg;*.tif;*.png;*.gif;*.bmp', 'All Image Files'; ...
         '*.*', 'All Files' }, ...
        'Pick an image', '');

    if (base_fname ~= 0)
        full_fname = fullfile (path_name, base_fname);
        handles.gui.apply_one_image_operation (...
            @ (img) load_as_gray (full_fname))
    end

    guidata(hObject, handles);

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    printdlg (handles.figure1);


% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    close();


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
    if ispc && isequal(get(hObject,'BackgroundColor'), ...
                       get(0, 'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

    set (hObject, 'String', {'plot(rand(5))', 'plot(sin(1:0.01:25))', ...
                        'bar(1:.5:10)', 'plot(membrane)', 'surf(peaks)'});

% --- Executes on button press in push_resize_apply.
function push_resize_apply_Callback(hObject, eventdata, handles)
% hObject    handle to push_resize_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    interpstr  = get (handles.popup_interp, 'String');
    interp     = lower (interpstr {get (handles.popup_interp, 'Value')});
    factor     = get (handles.edit_factor, 'Value');
    res_change = get (get (handles.group_res_change, 'SelectedObject'), 'Tag');
    cols       = str2double (get (handles.edit_cols, 'String'));
    rows       = str2double (get (handles.edit_rows, 'String'));
    strcmp (res_change, 'radio_res_change_size')
    if strcmp (res_change, 'radio_res_change_size') && (...
        cols < 0 || isnan (cols) || rows < 0 || isnan (rows))
        errordlg(['You must enter a valid positive number for the ' ...
                  'colums and rows'], 'Bad Input', 'modal');
        return
    end   
    newsize    = [ rows cols ];

    handles.gui.apply_two_image_operation (...
        @ (inimg) resize_image (inimg, res_change, factor, newsize, interp))
    guidata(hObject, handles);


% --- Executes on selection change in popup_color.
function popup_color_Callback(hObject, eventdata, handles)
% hObject    handle to popup_color (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    str = get (hObject, 'String'); %returns menuColor contents as cell array
    val = get (hObject, 'Value'); %returns selected item from menuColor
    handles.gui.color_map = lower (str {val});
    colormap (char (handles.gui.color_map));
    guidata (hObject, handles);


% --- Executes during object creation, after setting all properties.
function popup_color_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_color (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



% --- Executes on slider movement.
function slider_color_Callback(hObject, eventdata, handles)
% hObject    handle to slider_color (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    handles.gui.color_level = round (get (hObject, 'Value'));
    st = strcat (handles.gui.color_map, '(', num2str (handles.gui.color_level), ')');
    colormap (char (st));
    set (handles.text_color, 'String', strcat (...
        'Quantization: ', num2str (handles.gui.color_level) ));
    guidata (hObject, handles);


% --- Executes during object creation, after setting all properties.
function slider_color_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_color (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end


% --------------------------------------------------------------------
function barracolores_Callback(hObject, eventdata, handles)
% hObject    handle to barracolores (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_toggle_colorbar_Callback(hObject, eventdata, handles)
% hObject    handle to menu_toggle_colorbar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.gui.toggle_colorbar ();

function edit_factor_Callback(hObject, eventdata, handles)
    set (handles.text_factor, ...
         'String', strcat ('Factor: ', ...
                           num2str (get (handles.edit_factor, 'Value'))));
    guidata (hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit_factor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_factor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



% --------------------------------------------------------------------
function menu_extend_Callback(hObject, eventdata, handles)
% hObject    handle to menu_extend (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    figure;
    imshow (handles.gui.src_image ().get_data ()),
    colormap (char (strcat (handles.gui.color_map, ...
                            '(', num2str(handles.gui.color_level), ')')));
    axis image off;

% --- Executes when selected object is changed in group_res_change.
function group_res_change_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in group_res_change 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
    switch get(eventdata.NewValue,'Tag') % Get Tag of selected object.
      case 'radio_res_change_factor'
        set(handles.text_factor,'Visible','on');
        set(handles.edit_factor,'Visible','on');
        set(handles.text_cols,'Visible','off');
        set(handles.text_rows,'Visible','off');
        set(handles.edit_cols,'Visible','off');
        set(handles.edit_rows,'Visible','off');
        
      case 'radio_res_change_size'
        set(handles.text_factor,'Visible','off');
        set(handles.edit_factor,'Visible','off');
        set(handles.text_cols,'Visible','on');
        set(handles.text_rows,'Visible','on');
        set(handles.edit_cols,'Visible','on');
        set(handles.edit_rows,'Visible','on');        
    end
    guidata(hObject,handles);


% --------------------------------------------------------------------
function SaveMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to SaveMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    [filename, pathname, filterindex] = uiputfile( ...
        {'*.bmp','Windows Bitmap (*.bmp)'; ...
         '*.gif','Graphics Interchange Format (*.gif)'; ...
         '*.jpg','Joint Photographic Experts Group (*.jpg, *.jpeg)'; ...
         '*.png','Portable Network Graphics (*.png)'; ...
         '*.ppm','Portable Pixmap (*.ppm)'; ...
         '*.ppm','Portable Pixmap (*.ppm)'; ...
         '*.tif;*.tiff','Tagged Image File Format (*.tif, *.tiff)';...
         '*.bmp;*.gif;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.*',...
         'Todos los archivos (*.*)'}, ...
        strcat('Guardar Imagen'));

    path = strcat (pathname, filename);
    imwrite (handles.gui.src_image (), path); 



% --- Executes on button press in rotate_right.
function rotate_right_Callback(hObject, eventdata, handles)
% hObject    handle to rotate_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.gui.apply_two_image_operation (@ (img) imrotate (...
        img, -90, 'bicubic'));
    guidata(hObject, handles);


% --- Executes on button press in rotate_left.
function rotate_left_Callback(hObject, eventdata, handles)
% hObject    handle to rotate_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.gui.apply_two_image_operation (@ (img) imrotate (...
        img, 90, 'bicubic'));
    guidata(hObject, handles);


% --- Executes on button press in push_difference.
function push_difference_Callback(hObject, eventdata, handles)
% hObject    handle to push_difference (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.gui.apply_binary_image_operation (@image_diff)

% --- Executes on button press in push_mse.
function push_mse_Callback(hObject, eventdata, handles)
% hObject    handle to push_mse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    src = handles.gui.src_image ().get_data ();
    dst = handles.gui.dst_image ().get_data ();
    set (handles.text_mse, 'String', num2str (compute_mse (src, dst)));


% --- Executes during object creation, after setting all properties.
function edit_cols_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_cols (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

% --- Executes during object creation, after setting all properties.
function edit_rows_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_cols (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.

    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on selection change in popup_dest.
function popup_dest_Callback(hObject, eventdata, handles)
% hObject    handle to popup_dest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_dest contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_dest


% --- Executes during object creation, after setting all properties.
function popup_dest_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_dest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on selection change in popup_interp.
function popup_interp_Callback(hObject, eventdata, handles)
% hObject    handle to popup_interp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_interp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_interp


% --- Executes during object creation, after setting all properties.
function popup_interp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_interp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes when selected object is changed in group_image.
function group_image_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in group_image 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function edit_rows_Callback(hObject, eventdata, handles)
% hObject    handle to edit_cols (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_cols as text
%        str2double(get(hObject,'String')) returns contents of edit_cols as a double



function edit_cols_Callback(hObject, eventdata, handles)
% hObject    handle to edit_cols (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_cols as text
%        str2double(get(hObject,'String')) returns contents of edit_cols as a double


% --- Executes on button press in push_hflip.
function push_hflip_Callback(hObject, eventdata, handles)
% hObject    handle to push_hflip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.gui.apply_two_image_operation (@ fliplr);


% --- Executes on button press in push_vflip.
function push_vflip_Callback(hObject, eventdata, handles)
% hObject    handle to push_vflip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.gui.apply_two_image_operation (@ flipud);




function edit_a_Callback(hObject, eventdata, handles)
% hObject    handle to edit_a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_a as text
%        str2double(get(hObject,'String')) returns contents of edit_a as a double


% --- Executes during object creation, after setting all properties.
function edit_a_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_b_Callback(hObject, eventdata, handles)
% hObject    handle to edit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_b as text
%        str2double(get(hObject,'String')) returns contents of edit_b as a double


% --- Executes during object creation, after setting all properties.
function edit_b_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_mean_Callback(hObject, eventdata, handles)
% hObject    handle to edit_mean (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_mean as text
%        str2double(get(hObject,'String')) returns contents of edit_mean as a double


% --- Executes during object creation, after setting all properties.
function edit_mean_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_mean (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_variance_Callback(hObject, eventdata, handles)
% hObject    handle to edit_variance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_variance as text
%        str2double(get(hObject,'String')) returns contents of edit_variance as a double


% --- Executes during object creation, after setting all properties.
function edit_variance_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_variance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_salt_Callback(hObject, eventdata, handles)
% hObject    handle to edit_salt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_salt as text
%        str2double(get(hObject,'String')) returns contents of edit_salt as a double


% --- Executes during object creation, after setting all properties.
function edit_salt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_salt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_pepper_Callback(hObject, eventdata, handles)
% hObject    handle to edit_pepper (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_pepper as text
%        str2double(get(hObject,'String')) returns contents of edit_pepper as a double


% --- Executes during object creation, after setting all properties.
function edit_pepper_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_pepper (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_alfa_Callback(hObject, eventdata, handles)
% hObject    handle to edit_alfa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_alfa as text
%        str2double(get(hObject,'String')) returns contents of edit_alfa as a double


% --- Executes during object creation, after setting all properties.
function edit_alfa_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_alfa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on button press in push_noise_apply.
function push_noise_apply_Callback(hObject, eventdata, handles)
% hObject    handle to push_noise_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hObject    handle to push_resize_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        noise = get (get (handles.group_noise, 'SelectedObject'), 'Tag');
        switch noise
          case 'radio_noise_uniform'
            a = num_get (handles.edit_a, -Inf, Inf);
            b = num_get (handles.edit_b, -Inf, Inf);
            op = @ (img) noise_uniform_additive (img, a, b);
            
          case 'radio_noise_gauss_add'
            mean = num_get (handles.edit_mean, 0, Inf);
            variance = num_get (handles.edit_variance, 0, Inf);
            op = @ (img) noise_gaussian_additive (img, mean, variance);
            
          case 'radio_noise_gauss_mult'
            factor = num_get (handles.edit_factor, -Inf, Inf);
            op = @ (img) noise_gaussian_mult (img, factor);
            
          case 'radio_noise_snp'
            salt = num_get (handles.edit_salt, 0, 100) / 100;
            pepper = num_get (handles.edit_pepper, 0, 100) / 100;
            op = @ (img) noise_salt_pepper (img, salt, pepper);
        end
        handles.gui.apply_two_image_operation (op);
        push_mse_Callback (hObject, eventdata, handles);
        push_snr_Callback (hObject, eventdata, handles);
    catch me
        check_ex (me, 'num_get');
    end
    guidata(hObject, handles);

% --- Executes when selected object is changed in group_noise.
function group_noise_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in group_noise 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
    switch get(eventdata.NewValue,'Tag') % Get Tag of selected object.
      case 'radio_noise_uniform'
        set(handles.edit_a,        'Visible', 'on');
        set(handles.edit_b,        'Visible', 'on');
        set(handles.text_a,        'Visible', 'on');
        set(handles.text_b,        'Visible', 'on');
        set(handles.edit_mean,     'Visible', 'off');
        set(handles.edit_variance, 'Visible', 'off');
        set(handles.text_mean,     'Visible', 'off');
        set(handles.text_variance, 'Visible', 'off');
        set(handles.edit_alfa,     'Visible', 'off');
        set(handles.text_alfa,     'Visible', 'off');
        set(handles.edit_salt,     'Visible', 'off');
        set(handles.edit_pepper,   'Visible', 'off');
        set(handles.text_salt,     'Visible', 'off');
        set(handles.text_pepper,   'Visible', 'off');
        
      case 'radio_noise_gauss_add'
        set(handles.edit_a,        'Visible', 'off');
        set(handles.edit_b,        'Visible', 'off');
        set(handles.text_a,        'Visible', 'off');
        set(handles.text_b,        'Visible', 'off');
        set(handles.edit_mean,     'Visible', 'on');
        set(handles.edit_variance, 'Visible', 'on');
        set(handles.text_mean,     'Visible', 'on');
        set(handles.text_variance, 'Visible', 'on');
        set(handles.edit_alfa,     'Visible', 'off');
        set(handles.text_alfa,     'Visible', 'off');
        set(handles.edit_salt,     'Visible', 'off');
        set(handles.edit_pepper,   'Visible', 'off');
        set(handles.text_salt,     'Visible', 'off');
        set(handles.text_pepper,   'Visible', 'off');
        
      case 'radio_noise_gauss_mult'
        set(handles.edit_a,        'Visible', 'off');
        set(handles.edit_b,        'Visible', 'off');
        set(handles.text_a,        'Visible', 'off');
        set(handles.text_b,        'Visible', 'off');
        set(handles.edit_mean,     'Visible', 'off');
        set(handles.edit_variance, 'Visible', 'off');
        set(handles.text_mean,     'Visible', 'off');
        set(handles.text_variance, 'Visible', 'off');
        set(handles.edit_alfa,     'Visible', 'on');
        set(handles.text_alfa,     'Visible', 'on');
        set(handles.edit_salt,     'Visible', 'off');
        set(handles.edit_pepper,   'Visible', 'off');
        set(handles.text_salt,     'Visible', 'off');
        set(handles.text_pepper,   'Visible', 'off');
        
      case 'radio_noise_snp'
        set(handles.edit_a,        'Visible', 'off');
        set(handles.edit_b,        'Visible', 'off');
        set(handles.text_a,        'Visible', 'off');
        set(handles.text_b,        'Visible', 'off');
        set(handles.edit_mean,     'Visible', 'off');
        set(handles.edit_variance, 'Visible', 'off');
        set(handles.text_mean,     'Visible', 'off');
        set(handles.text_variance, 'Visible', 'off');
        set(handles.edit_alfa,     'Visible', 'off');
        set(handles.text_alfa,     'Visible', 'off');
        set(handles.edit_salt,     'Visible', 'on');
        set(handles.edit_pepper,   'Visible', 'on');
        set(handles.text_salt,     'Visible', 'on');
        set(handles.text_pepper,   'Visible', 'on');
        
      otherwise
    end
    guidata(hObject,handles);



function edit_random_seed_Callback(hObject, eventdata, handles)
% hObject    handle to edit_random_seed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_random_seed as text
%        str2double(get(hObject,'String')) returns contents of edit_random_seed as a double


% --- Executes during object creation, after setting all properties.
function edit_random_seed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_random_seed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on button press in push_random_seed.
function push_random_seed_Callback(hObject, eventdata, handles)
% hObject    handle to push_random_seed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        new_type = get (handles.popup_random_type, 'Value');
        type_lst = cellstr(['mt19937ar  '; 
                            'mcg16807   ';
                            'mlfg6331_64';
                            'mrg32k3a   '; 
                            'shr3cong   ']);
        new_type = type_lst {new_type};
        new_seed = num_get (handles.edit_random_seed, 0, Inf);
        RandStream.setDefaultStream (RandStream (new_type, 'Seed', new_seed));
    catch ex
        check_ex (ex, 'num_get');
    end
    guidata(hObject, handles);

% --- Executes on selection change in popup_filter_type.
function popup_filter_type_Callback(hObject, eventdata, handles)
% hObject    handle to popup_filter_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_filter_type contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_filter_type
    if get (hObject, 'Value') == 2 % Gaussian
        set (handles.edit_filter_sigma, 'Visible', 'on');
        set (handles.text_filter_sigma, 'Visible', 'on');
    else
        set (handles.edit_filter_sigma, 'Visible', 'off');
        set (handles.text_filter_sigma, 'Visible', 'off');
    end

% --- Executes during object creation, after setting all properties.
function popup_filter_type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_filter_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_filter_size_Callback(hObject, eventdata, handles)
% hObject    handle to edit_filter_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_filter_size as text
%        str2double(get(hObject,'String')) returns contents of edit_filter_size as a double


% --- Executes during object creation, after setting all properties.
function edit_filter_size_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_filter_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_filter_sigma_Callback(hObject, eventdata, handles)
% hObject    handle to edit_filter_sigma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_filter_sigma as text
%        str2double(get(hObject,'String')) returns contents of edit_filter_sigma as a double


% --- Executes during object creation, after setting all properties.
function edit_filter_sigma_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_filter_sigma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function op = get_filter_operation (handles)
    filter = get (handles.popup_filter_type, 'Value');
    size   = num_get (handles.edit_filter_size, 1, Inf);
    switch filter
      case 1 % Average
        op = @ (img) imfilter (double (img), ...
                               fspecial ('average', [size size]), ...
                               'replicate');
      case 2 % Gaussian
        sigma = num_get (handles.edit_filter_sigma, 0, 1);
        op = @ (img) imfilter (double (img), ...
                               fspecial ('gaussian', [size size], sigma), ...
                               'replicate');
      case 3 % Median
        op = @ (img) ordfilt2 (double (img), 5, ones (size, size));
      case 4 % Maximum
        op = @ (img) ordfilt2 (double (img), size^2, ones (size, size));
      case 5 % Minimum
        op = @ (img) ordfilt2 (double (img), 1, ones (size, size));
    end        

% --- Executes on button press in push_filter_apply.
function push_filter_apply_Callback(hObject, eventdata, handles)
% hObject    handle to push_filter_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        op = get_filter_operation (handles);
        handles.gui.apply_two_image_operation (op);
        if ~handles.gui.third_image ().isempty ()
            push_isnr_Callback (hObject, eventdata, handles);
        end
    catch me
        check_ex (me, 'num_get');
    end
    guidata (hObject, handles);



% --- Executes during object creation, after setting all properties.
function popup_random_type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_random_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on button press in push_snr.
function push_snr_Callback(hObject, eventdata, handles)
% hObject    handle to push_snr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    src = handles.gui.src_image ().get_data ();
    dst = handles.gui.dst_image ().get_data ();
    set (handles.text_snr, 'String', num2str (compute_snr (src, dst)));


% --- Executes on button press in push_isnr.
function push_isnr_Callback(hObject, eventdata, handles)
% hObject    handle to push_isnr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    src = handles.gui.src_image ().get_data ();
    dst = handles.gui.dst_image ().get_data ();
    err = handles.gui.third_image ().get_data ();
    set (handles.text_isnr, 'String', num2str (compute_isnr (src, dst, err)));


% --------------------------------------------------------------------
function imagenMenu_Callback(hObject, eventdata, handles)
% hObject    handle to imagenMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in push_profiles.
function push_profiles_Callback(hObject, eventdata, handles)
% hObject    handle to push_profiles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.gui.toggle_profile_mode ();
    if handles.gui.profile_mode
        set (handles.push_profiles, 'String', 'On');
        set (handles.slider_profile_row, 'Enable', 'on');
        set (handles.text_profile_row,   'Enable', 'on');
        set (handles.radio_profile_line, 'Enable', 'on');
        set (handles.radio_profile_area, 'Enable', 'on');
    else
        set (handles.push_profiles, 'String', 'Off');
        set (handles.slider_profile_row, 'Enable', 'off');
        set (handles.text_profile_row,   'Enable', 'off');
        set (handles.radio_profile_line, 'Enable', 'off');
        set (handles.radio_profile_area, 'Enable', 'off');
    end
    guidata (hObject, handles);

% --- Executes on slider movement.
function slider_profile_row_Callback(hObject, eventdata, handles)
% hObject    handle to slider_profile_row (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    val = get (hObject, 'Value');
    handles.gui.set_profile_row (val);
    set (handles.text_profile_row, 'String', strcat ('Row: ', num2str (val), ...
                                                     ' in (0, 1)'));

% --- Executes during object creation, after setting all properties.
function slider_profile_row_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_profile_row (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end


% --- Executes when selected object is changed in group_profiles.
function group_profiles_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in group_profiles 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
    switch get (eventdata.NewValue, 'Tag')
      case 'radio_profile_line'
        handles.gui.set_profile_plot_fn (@ plot);
      case 'radio_profile_area'
        handles.gui.set_profile_plot_fn (@ area);
    end

% --- Executes during object creation, after setting all properties.
function popup_edge_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_edge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on button press in check_edge_filter.
function check_edge_filter_Callback(hObject, eventdata, handles)
% hObject    handle to check_edge_filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check_edge_filter



function edit_edge_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to edit_edge_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_edge_threshold as text
%        str2double(get(hObject,'String')) returns contents of edit_edge_threshold as a double


% --- Executes during object creation, after setting all properties.
function edit_edge_threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_edge_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on button press in check_edge_threshold.
function check_edge_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to check_edge_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check_edge_threshold



function edit_edge_sigma_Callback(hObject, eventdata, handles)
% hObject    handle to edit_edge_sigma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_edge_sigma as text
%        str2double(get(hObject,'String')) returns contents of edit_edge_sigma as a double


% --- Executes during object creation, after setting all properties.
function edit_edge_sigma_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_edge_sigma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



% --- Executes on button press in pushbutton21.
function pushbutton21_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function slider_corner_neighbours_Callback(hObject, eventdata, handles)
% hObject    handle to slider_corner_neighbours (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
    neigh = round (get (hObject, 'Value'));
    set (handles.text_corner_neighbour, 'String', ...
                       strcat ('Neighbours: ', num2str (neigh)));

% --- Executes during object creation, after setting all properties.
function slider_corner_neighbours_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_corner_neighbours (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end



function edit_corner_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to edit_corner_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_corner_threshold as text
%        str2double(get(hObject,'String')) returns contents of edit_corner_threshold as a double


% --- Executes during object creation, after setting all properties.
function edit_corner_threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_corner_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on button press in check_corner_local_max.
function check_corner_local_max_Callback(hObject, eventdata, handles)
% hObject    handle to check_corner_local_max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check_corner_local_max



function edit_corner_distance_Callback(hObject, eventdata, handles)
% hObject    handle to edit_corner_distance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_corner_distance as text
%        str2double(get(hObject,'String')) returns contents of edit_corner_distance as a double


% --- Executes during object creation, after setting all properties.
function edit_corner_distance_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_corner_distance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function img = edge_op_4 (handles, op, img)
    vis_idx    = get (handles.popup_edge_vis, 'Value');
    
    [edg, ts, gv, gh] = op (img);
    img = edge_result (double (edg) * 255, gv, gh, abs (gv) + abs (gh), ...
                       atan (double (gv ./ gh)), img, vis_idx);
    
    set (handles.text_edge_res_threshold, 'String', ...
                       strcat ('Threshold: ', num2str (ts)));

function img = edge_op_2 (handles, op, img)
    vis_idx    = get (handles.popup_edge_vis, 'Value');

    [edg, ts] = op (img);
    img = edge_result (double (edg) * 255, [], [], [], [], img, vis_idx);
    set (handles.text_edge_res_threshold, 'String', ...
                       strcat ('Threshold: ', num2str (ts)));

function img = edge_op_5 (handles, op, img)
    vis_idx    = get (handles.popup_edge_vis, 'Value');
    
    [edg, mag, imgx, imgy, norm] = op (img);
    img = edge_result (edg, imgx, imgy, mag, norm, img, vis_idx);

% --- Executes on button press in push_edge_apply.
function push_edge_apply_Callback(hObject, eventdata, handles)
% hObject    handle to push_edge_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        edge_type    = get (handles.popup_edge, 'Value');
        auto_ts      = get (handles.check_edge_threshold, 'Value');
        threshold    = num_get (handles.edit_edge_threshold, 0, Inf);
        threshold_2  = num_get (handles.edit_edge_threshold_2, 0, Inf);
        sigma        = num_get (handles.edit_edge_sigma, 0, Inf);
        use_filter   = get (handles.check_edge_filter, 'Value');
        gradient     = get (get (handles.group_edge_grad, 'SelectedObject'), 'Tag');
        use_thinning = get (handles.check_edge_thinning, 'Value');
        
        switch gradient
          case 'radio_edge_grad_1'
            gradient = 'both';
          case 'radio_edge_grad_2'
            gradient = 'vertical';
          case 'radio_edge_grad_3'
            gradient = 'horizontal';
        end
        
        if use_filter
            filter_op = get_filter_operation (handles);
        else
            filter_op = @ (id) id;
        end
        
        if use_thinning 
            thinning = 'thinning';
        else 
            thinning = 'nothinning';
        end
        
        switch edge_type
          case 1 % 'Roberts - MATLAB'
            if auto_ts
                op = @ (img) edge_op_4 (...
                    handles, @ (img) edge (img, 'roberts', thinning, gradient), img);
            else
                op = @ (img) edge_op_4 (...
                    handles, @ (img) edge (img, 'roberts', threshold, ...
                                           thinning, gradient), img);
            end
            
          case 2 % 'Roberts'
            op = @ (img) edge_op_5 (...
                handles, @ (img) edge_roberts (img, threshold, gradient), img);
            
          case 3 % 'Sobel - MATLAB'
            if auto_ts
                op = @ (img) edge_op_4 (...
                    handles, @ (img) edge (img, 'sobel', thinning, gradient), img);
            else
                op = @ (img) edge_op_4 (...
                    handles, @ (img) edge (img, 'sobel', threshold, ...
                                           thinning, gradient), img);
            end
            
          case 4 % 'Sobel'
            op = @ (img) edge_op_5 (...
                handles, @ (img) edge_sobel (img, threshold, gradient), img);
            
          case 5 % 'Prewitt - MATLAB'
            if auto_ts
                op = @ (img) edge_op_4 (...
                    handles, @ (img) edge (img, 'prewitt'), img);
            else
                op = @ (img) edge_op_4 (...
                    handles, @ (img) edge (img, 'prewitt', threshold), img);
            end
            
          case 6 % 'Prewitt'
            op = @ (img) edge_op_5 (...
                handles, @ (img) edge_prewitt (img, threshold, gradient), img);
            
          case 7 % 'Kirsch'
            op = @ (id) id;
            
          case 8 % 'Log - MATLAB'
            if auto_ts
                op = @ (img) edge_op_2 (...
                    handles, @ (img) edge (img, 'log'), img);
            else
                op = @ (img) edge_op_2 (...
                    handles, @ (img) edge (img, 'log', threshold, sigma), img);
            end
            
          case 9 % 'Canny - MATLAB'
            if auto_ts
                op = @ (img) edge_op_2 (...
                    handles, @ (img) edge (img, 'canny'), img);
            else
                thres = [ threshold, threshold_2];
                op = @ (img) edge_op_2 (...
                    handles, @ (img) edge (img, 'canny', thres, sigma), img);
            end
          otherwise
        end
        
        handles.gui.apply_two_image_operation (@ (img) op (filter_op (img)));
    catch ex
        check_ex (ex, 'num_get');
    end


% --- Executes on button press in check_edge_thinning.
function check_edge_thinning_Callback(hObject, eventdata, handles)
% hObject    handle to check_edge_thinning (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check_edge_thinning

% --- Executes on selection change in popup_edge_vis.
function popup_edge_vis_Callback(hObject, eventdata, handles)
% hObject    handle to popup_edge_vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_edge_vis contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_edge_vis
    handles.gui.set_mode_for ('edge', get (hObject, 'Value'));

% --- Executes during object creation, after setting all properties.
function popup_edge_vis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_edge_vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_edge_threshold_2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_edge_threshold_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_edge_threshold_2 as text
%        str2double(get(hObject,'String')) returns contents of edit_edge_threshold_2 as a double


% --- Executes during object creation, after setting all properties.
function edit_edge_threshold_2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_edge_threshold_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on selection change in popup_edge.
function popup_edge_Callback(hObject, eventdata, handles)
% hObject    handle to popup_edge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_edge contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_edge

    edge_type = get (hObject, 'Value');
    switch edge_type
      case 1 % 'Roberts - MATLAB'
        set (handles.check_edge_thinning,    'Enable', 'on');
        set (handles.edit_edge_threshold,    'Enable', 'on');
        set (handles.edit_edge_threshold_2,  'Enable', 'off');
        set (handles.edit_edge_sigma,        'Enable', 'off');
        set (handles.check_edge_threshold,   'Enable', 'on');
        set (handles.group_edge_grad,        'Visible', 'on');
        set (handles.radio_edge_grad_2,      'String', 'Vert.');
        set (handles.radio_edge_grad_3,      'String', 'Horiz');
        
      case 2 % 'Roberts'
        set (handles.check_edge_thinning,    'Enable', 'off');
        set (handles.edit_edge_threshold,    'Enable', 'on');
        set (handles.edit_edge_threshold_2,  'Enable', 'off');
        set (handles.edit_edge_sigma,        'Enable', 'off');
        set (handles.check_edge_threshold,   'Enable', 'off');
        set (handles.group_edge_grad,        'Visible', 'on');
        set (handles.radio_edge_grad_2,      'String', 'Vert.');
        set (handles.radio_edge_grad_3,      'String', 'Horiz');
        
      case 3 % 'Sobel - MATLAB'
        set (handles.check_edge_thinning,    'Enable', 'on');
        set (handles.edit_edge_threshold,    'Enable', 'on');
        set (handles.edit_edge_threshold_2,  'Enable', 'off');
        set (handles.edit_edge_sigma,        'Enable', 'off');
        set (handles.check_edge_threshold,   'Enable', 'on');
        set (handles.group_edge_grad,        'Visible', 'on');
        set (handles.radio_edge_grad_2,      'String', 'Vert.');
        set (handles.radio_edge_grad_3,      'String', 'Horiz');
        
      case 4 % 'Sobel'
        set (handles.check_edge_thinning,    'Enable', 'on');
        set (handles.edit_edge_threshold,    'Enable', 'on');
        set (handles.edit_edge_threshold_2,  'Enable', 'off');
        set (handles.edit_edge_sigma,        'Enable', 'off');
        set (handles.check_edge_threshold,   'Enable', 'off');
        set (handles.group_edge_grad,        'Visible', 'on');
        set (handles.radio_edge_grad_2,      'String', 'Vert.');
        set (handles.radio_edge_grad_3,      'String', 'Horiz');
        
      case 5 % 'Prewitt - MATLAB'
        set (handles.check_edge_thinning,    'Enable', 'off');
        set (handles.edit_edge_threshold,    'Enable', 'on');
        set (handles.edit_edge_threshold_2,  'Enable', 'off');
        set (handles.edit_edge_sigma,        'Enable', 'off');
        set (handles.check_edge_threshold,   'Enable', 'on');
        set (handles.group_edge_grad,        'Visible', 'on');
        set (handles.radio_edge_grad_2,      'String', 'Vert.');
        set (handles.radio_edge_grad_3,      'String', 'Horiz');
        
      case 6 % 'Prewitt'
        set (handles.check_edge_thinning,    'Enable', 'off');
        set (handles.edit_edge_threshold,    'Enable', 'on');
        set (handles.edit_edge_threshold_2,  'Enable', 'off');
        set (handles.edit_edge_sigma,        'Enable', 'off');
        set (handles.check_edge_threshold,   'Enable', 'off');
        set (handles.group_edge_grad,        'Visible', 'on');
        set (handles.radio_edge_grad_2,      'String', 'Vert.');
        set (handles.radio_edge_grad_3,      'String', 'Horiz');
        
      case 7 % 'Kirsch'
        
      case 8 % 'Log - MATLAB'
        set (handles.check_edge_thinning,    'Enable', 'off');
        set (handles.edit_edge_threshold,    'Enable', 'on');
        set (handles.edit_edge_threshold_2,  'Enable', 'off');
        set (handles.edit_edge_sigma,        'Enable', 'on');
        set (handles.check_edge_threshold,   'Enable', 'on');
        set (handles.group_edge_grad,        'Visible', 'on');
        set (handles.radio_edge_grad_2,      'String', 'Vert.');
        set (handles.radio_edge_grad_3,      'String', 'Horiz');
        
      case 9 % 'Canny - MATLAB'
        set (handles.check_edge_thinning,    'Enable', 'off');
        set (handles.edit_edge_threshold,    'Enable', 'on');
        set (handles.edit_edge_threshold_2,  'Enable', 'on');
        set (handles.edit_edge_sigma,        'Enable', 'on');
        set (handles.check_edge_threshold,   'Enable', 'on');
        set (handles.group_edge_grad,        'Visible', 'off');
        set (handles.radio_edge_grad_2,      'String', 'Vert.');
        set (handles.radio_edge_grad_3,      'String', 'Horiz');
      otherwise
    end

function img = corner_op (op, img, handles)
    rem_lm  = get (handles.check_corner_local_max, 'Value');
    mode    = get (handles.popup_corner_vis, 'Value');
    [c, f, denorm, eigen] = op (img);
    
    img = corner_result (c, f, denorm, eigen, img, mode);
    num_corner = size (f);
    set (handles.text_corner, 'String', ...
                       strcat ('Corners: ', num2str (num_corner (:, 1))));

    if rem_lm
        dist = num_get (handles.edit_corner_distance, 0, Inf);
        [f c] = remove_local_max (denorm, dist);
        
        num_corner = size (f);
        set (handles.text_corner_nl, ...
             'String', ...
             strcat ('Non local corners: ', num2str (num_corner (:, 1))));

    end

% --- Executes on button press in push_corner_apply.
function push_corner_apply_Callback(hObject, eventdata, handles)
% hObject    handle to push_corner_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        neighbours    = round (get (handles.slider_corner_neighbours, 'Value'));
        threshold     = num_get (handles.edit_corner_threshold, 0, Inf);
        
        op = @ (img) corner_op (...
            @ (img) corner_harris (img, threshold, neighbours), img, handles);
        
        handles.gui.apply_two_image_operation (op);
    catch ex
        check_ex (ex, 'num_get');
    end


% --- Executes on selection change in popup_corner_vis.
function popup_corner_vis_Callback(hObject, eventdata, handles)
% hObject    handle to popup_corner_vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_corner_vis contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_corner_vis
    handles.gui.set_mode_for ('corner', get (hObject, 'Value'));

% --- Executes during object creation, after setting all properties.
function popup_corner_vis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_corner_vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on selection change in popup_feature_type.
function popup_feature_type_Callback(hObject, eventdata, handles)
% hObject    handle to popup_feature_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_feature_type contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_feature_type

    switch get (hObject,'Value')
      case 1
        set (handles.panel_edge, 'Visible', 'on');
        set (handles.panel_corner, 'Visible', 'off');
      case 2
        set (handles.panel_edge, 'Visible', 'off');
        set (handles.panel_corner, 'Visible', 'on');
      case 3
        set (handles.panel_edge, 'Visible', 'off');
        set (handles.panel_corner, 'Visible', 'off');
    end
    
% --- Executes during object creation, after setting all properties.
function popup_feature_type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_feature_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_block_size_Callback(hObject, eventdata, handles)
% hObject    handle to edit_block_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_block_size as text
%        str2double(get(hObject,'String')) returns contents of edit_block_size as a double


% --- Executes during object creation, after setting all properties.
function edit_block_size_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_block_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end



function edit_block_max_offset_Callback(hObject, eventdata, handles)
% hObject    handle to edit_block_max_offset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_block_max_offset as text
%        str2double(get(hObject,'String')) returns contents of edit_block_max_offset as a double


% --- Executes during object creation, after setting all properties.
function edit_block_max_offset_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_block_max_offset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on selection change in popup_block_criteria.
function popup_block_criteria_Callback(hObject, eventdata, handles)
% hObject    handle to popup_block_criteria (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_block_criteria contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_block_criteria


% --- Executes during object creation, after setting all properties.
function popup_block_criteria_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_block_criteria (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on selection change in popup_block_vis.
function popup_block_vis_Callback(hObject, eventdata, handles)
% hObject    handle to popup_block_vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_block_vis contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_block_vis
    handles.gui.set_mode_for ('blockmatch', get (hObject, 'Value'));

% --- Executes during object creation, after setting all properties.
function popup_block_vis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_block_vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

function img = block_op (op, img1, img2, block_size, handles)
    if size(img1) ~= size(img2)
        errordlg ('Both images must be of the same size.', 'modal');
        img = [];
    else
        mode = get (handles.popup_block_vis, 'Value');
        offset = op (img1, img2);
        img = blockmatch_result (offset, block_size, img1, img2, mode);
    end

% --- Executes on button press in push_block_apply.
function push_block_apply_Callback(hObject, eventdata, handles)
% hObject    handle to push_block_apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        block_size  = num_get (handles.edit_block_size, 1, Inf);
        max_offset  = num_get (handles.edit_block_max_offset, 1, Inf);
        criteria    = get (handles.popup_block_criteria, 'Value');
        search_type = get (handles.popup_block_search, 'Value') - 1;
        
        switch search_type
          case 0
            op = @ (img1, img2) block_op (...
                @ (img1, img2) blockmatch_deep (...
                    block_size, max_offset, criteria, img2, img1), ...
                img1, img2, block_size, handles);
          case 1
            op = @ (img1, img2) block_op (...
                @ (img1, img2) blockmatch_fast (...
                    block_size, max_offset, criteria, img2, img1), ...
                img1, img2, block_size, handles);
        end
        
        handles.gui.apply_binary_image_operation (op);
        
    catch ex
        check_ex (ex, 'num_get');
    end

% --- Executes on selection change in popup_block_search.
function popup_block_search_Callback(hObject, eventdata, handles)
% hObject    handle to popup_block_search (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_block_search contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_block_search


% --- Executes during object creation, after setting all properties.
function popup_block_search_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_block_search (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end


% --- Executes on button press in color_red.
function color_red_Callback(hObject, eventdata, handles)
% hObject    handle to color_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of color_red
    handles.gui.set_color ([1 0 0]);

% --- Executes on button press in color_green.
function color_green_Callback(hObject, eventdata, handles)
% hObject    handle to color_green (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of color_green
    handles.gui.set_color ([0 1 0]);

% --- Executes on button press in color_yellow.
function color_yellow_Callback(hObject, eventdata, handles)
% hObject    handle to color_yellow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of color_yellow
    handles.gui.set_color ([1 1 0]);

% --- Executes on button press in color_blue.
function color_blue_Callback(hObject, eventdata, handles)
% hObject    handle to color_blue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of color_blue
    handles.gui.set_color ([0 0 1]);

% --- Executes on button press in color_cyan.
function color_cyan_Callback(hObject, eventdata, handles)
% hObject    handle to color_cyan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of color_cyan
    handles.gui.set_color ([0 1 1]);

% --- Executes on button press in color_pink.
function color_pink_Callback(hObject, eventdata, handles)
% hObject    handle to color_pink (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of color_pink
    handles.gui.set_color ([1 0 1]);
