/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

/**
 * Representa la información elemental de una carta de los juegos tradicionales
 * europeos, como los de baraja española, francesa, etc... Cada carta se
 * identifica segun el ordinal de su rango y un enumerado que representa su
 * palo.
 * 
 * Las cartas son ordenables según orden lexicográfico del par (rango, palo).
 * 
 * @author raskolnikov 
 */
public class Card implements Comparable<Card>
{
	/**
	 * Construye una carta a partir de su rango y palo.
	 * @param rank El rango de la carta.
	 * @param suit El palo de la carta.
	 */
	public Card (int rank, Enum suit)
	{
		m_rank = rank;
		m_suit = suit;
	}
	
	/**
	 * Accede al rango de la carta.
	 * @return El rango de la carta.
	 */
	public int getRank () 
	{
		return m_rank;
	}
	
	/**
	 * Accede al palo de la carta.
	 * @return El palo de la carta.
	 */
	public Enum getSuit () 
	{
		return m_suit;
	}
	
	/**
	 * Devuelve una representación textual de la carta.
	 */
	@Override
	public String toString ()
	{
		return "[" + m_rank + " of " + m_suit + "]";
	}
	
	/**
	 * Compara la carta con otra siguiendo un orden lexicográfico.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public int compareTo (Card c)
	{
		int val = m_rank == c.m_rank ? 0 : m_rank < c.m_rank ? -1 : 1;
		if (val == 0)
			val = m_suit.compareTo (c.m_suit);
				
		return val;
	}
	
	private int m_rank;  /**< El rango de la carta */
	private Enum m_suit; /**< El palo de la carta  */
}
