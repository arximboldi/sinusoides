%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       compute_isnr.m
%  Time-stamp: <2011-01-29 08:30:00 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Computar el ISNR con una imagen de error.
%

function isnr = compute_isnr (imga, imgb, imgc)
    sa = size (imga);
    sb = size (imgb);
    sc = size (imgc);
    
    if sa == sb & sb == sc
        aux = double (imga) - double (imgb);
        num = norm (aux (:))^2;
        aux = double (imga) - double (imgc);
        den = norm (aux (:))^2;
        isnr = 10 * log10 (num/den);
    else
        errordlg(['Not proper images. They must have the same size ' ...
                  'to calculate the ISNR. Remember that you need a ' ...
                  'third filtered image to calculate the ISNR.'], ...
                 'Bad Input', 'modal');
        isnr = NaN;
    end
end
