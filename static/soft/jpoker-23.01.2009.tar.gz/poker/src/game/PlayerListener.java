/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.Collection;
import java.util.List;

/**
 * Define la interfaz a implementar por un objeto que quiera recibir eventos de
 * un jugador.
 * 
 * @author raskolnikov
 */
public interface PlayerListener
{
	/**
	 * Este método será invocado cuando el jugador realice una apuesta.
	 * @param p El jugador que apuesta.
	 * @param bet La cantidad apostada.
	 */
	void handlePlayerBet (Player p, double bet);
	
	/**
	 * Este método será invocado cuando el jugador reciba una carta.
	 * @param p El jugador que recibe.
	 * @param c La carta recibida.
	 */
	void handlePlayerTake (Player p, Card c);
	
	/**
	 * Este método será invocado cuando el jugador devuelva una carta.
	 * @param p El jugador que devuelve la carta.
	 * @param d Las cartas devueltas.
	 */
	void handlePlayerDrop (Player p, Collection<Card> d);

	/**
	 * Este método será invocado cuando el jugador se vea forzado a devolver
	 * todas sus cartas, por ejemplo, al final de una partida.
	 * 
	 * @param p El jugador que devuelve.
	 * @param c Las cartas que devuelve.
	 */
	void handlePlayerDropAll (Player p, List<Card> c);
	
	/**
	 * Este método será invocado cuando cambien las ganancias del jugador.
	 * 
	 * @param p El jugador actualizado.
	 * @param diff La diferencia de ganancias.
	 */
	void handlePlayerUpdateSavings (Player p, double diff);
}
