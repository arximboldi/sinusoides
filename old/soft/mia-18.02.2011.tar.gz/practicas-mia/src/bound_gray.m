%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       bound_gray.m
%  Time-stamp: <2011-01-23 22:47:42 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Corta los extremos de valores de una imagen para que encajen en
%  [0, 256) y pueda ser usado como imagen de escala de grises.
%

function img = bound_gray (img)
    img = min (255, max (0, img));
end

