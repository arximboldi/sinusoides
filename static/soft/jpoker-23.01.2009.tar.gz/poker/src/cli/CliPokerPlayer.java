/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package cli;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.StringTokenizer;
import java.util.TreeSet;

import game.Card;
import game.PokerPlayer;

/**
 * Jugador de poker interactivo por la linea de comandos.
 * 
 * @author raskolnikov
 */
public class CliPokerPlayer extends PokerPlayer
{
	/**
	 * Constructor.
	 * @param name Nombre del jugador.
	 * @param savings Ganancias del jugador.
	 */
	public CliPokerPlayer (String name, double savings)
	{
		super (name, savings);
	}
	
	/**
	 * {@inheritDoc}
	 * Pregunta al usuario cuanto quiere apostar. Repite la pregunta hasta que
	 * la respuesta es consistente con las reglas del poker.
	 */
	@Override
	public double chooseBet () 
	{
		String input;
		double bet = 0.0;
		boolean finished = false;
		
		System.out.println ();
		System.out.println ("-- how much do you want to bet?");
		System.out.println ("availible: " + getSavings ());
		System.out.println ("minimum: " + getGame ().getMinBet ());
		printCards ();
		
		while (!finished) {
			try {
				input = m_in.readLine();
				bet = Double.parseDouble(input);
				if (bet != 0.0 && bet < getGame ().getMinBet ())
					System.out.println ("-- You have to bet at least " + 
							+ getGame ().getMinBet () + 
							" or fold by betting 0, repeat:");
				else
					finished = true;
			} catch (Exception e) {
				System.out.println ("-- Malformed bet, repeat:");
			}
		}
		System.out.println ();
		
		return bet;
	}

	/**
	 * {@inheritDoc}
	 * Pregunta al usuario que cartas quiere tirar.
	 */
	@Override
	public Collection<Card> chooseDrop () 
	{
		Collection<Card> cards = new TreeSet<Card> ();
		StringTokenizer tokens;
		int index;
		
		System.out.println ();
		System.out.println ("-- Choose some cards to drop by indicating their index: ");
		printCards ();
		
		try {
			tokens = new StringTokenizer (m_in.readLine ());
			while (tokens.hasMoreTokens ()) {
				index = Integer.parseInt (tokens.nextToken ());
				if (index >= 1 && index <= 5)
					cards.add (m_cards.get (index - 1));
			}
		} catch (Exception e) {}
		
		System.out.println ();
		
		return cards;
	}

	@Override
	public boolean leave () 
	{
		return false;
	}


	private void printCards ()
	{
		int index = 1;
		System.out.println ("Your cards: ");
		for (Card c : m_cards)
			System.out.println ((index ++) + ": " + c);	
	}
	
	BufferedReader m_in = new BufferedReader (new InputStreamReader (System.in));
}
