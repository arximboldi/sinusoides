/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.LinkedList;
import java.util.List;

/**
 * Implementa el comportamiento básico de un sujeto juego sobre el cual
 * distintos GameListener pueden registrarse para atender a eventos de la/s
 * partida/s observadas.
 * 
 * @author raskolnikov
 */
public class GameSubject 
{
	/**
	 * Añade un escuchante al sujeto. A partir de ahora el escuchante será
	 * notificado de los eventos que sucedan sobre el sujeto.
	 * 
	 * @param l El escuchante a añadir.
	 */
	public void addListener (GameListener l)
	{
		m_listeners.add(l);
	}
	
	/**
	 * Quita un escuchante del sujeto. A partir de ahora el escuchante dejará de
	 * recibir notificaciones del sujeto.
	 * 
	 * @param l El escuchante a quitar.
	 */
	public void removeListener (GameListener l)
	{
		m_listeners.remove(l);
	}
	
	/**
	 * Dispara un evento de comienzo de partida.
	 * @param g El juego que comienza.
	 */
	public void notifyStart (Game g)
	{
		for (GameListener l : m_listeners)
			l.handleGameStart (g);
	}
	
	/**
	 * Dispara un evento de fin de partida.
	 * @param g La partida que termina.
	 */
	public void notifyFinish (Game g)
	{
		for (GameListener l : m_listeners)
			l.handleGameFinish (g);
	}
	
	/**
	 * Dispara un evento de fin de ronda. En PlayerListener puede encontrar una descripción de las diferencias semánticas entre este Round y el de Game.
	 * @param g La partida que termina su ronda.
	 * @param winner Los ganadores de la ronda
	 * @see PlayerListener
	 */
	public void notifyRound (Game g, List<Player> winner)
	{
		for (GameListener l : m_listeners)
			l.handleGameRound (g, winner);
	}
	
	/**
	 * Dispara un evento de unión de un jugador a la partida.
	 * @param g El juego sobre el que se une.
	 * @param p El jugador que se une.
	 */
	public void notifyJoin (Game g, Player p)
	{
		for (GameListener l : m_listeners)
			l.handleGameJoin (g, p);
	}
	
	/**
	 * Dispara un evento de abandono de la partida por parte de un jugador.
	 * @param g El juego que abandona.
	 * @param p El jugador que abandona.
	 */
	public void notifyLeave (Game g, Player p)
	{
		for (GameListener l : m_listeners)
			l.handleGameLeave (g, p);
	}

	/** Lista de escuchantes registrados en el sujeto. */
	private LinkedList<GameListener> m_listeners = new LinkedList<GameListener>();
}
