/**
 *  Time-stamp:  <2011-01-25 03:06:40 raskolnikov>
 *
 *  @file        tsp.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Tue Jan 11 18:49:21 2011
 *
 *  Funciones para el cómputo del algoritmo del viajante de comercio.
 */

#ifndef PDP_TSP_H_
#define PDP_TSP_H_

#include <vector>
#include <utility>

#include <mpi.h>

#include "graph.hpp"

namespace pdp
{
namespace tsp
{

typedef int vertex;
const vertex null_vertex = -1;

typedef std::pair<vertex, vertex> arc;

inline arc null_arc ()
{
    return arc (-1, -1);
}

inline bool arc_is_null (const arc& a)
{
    return a.first < 0 || a.second < 0;
}

template <typename T>
class node
{
public:
    typedef T cost_type;
    
    node (std::size_t size = 0);
    node (const node& n);

#ifdef __GXX_EXPERIMENTAL_CXX0X__
    node (const node&& n);
#endif
    
    T cost () const { return _cost; }

    bool is_solution () const;
    
    template <class Graph, class State>
    inline void branch (Graph& g, State& s);

    void mpi_pack (void* buffer, std::size_t size,
                   int& position, MPI::Comm& c) const;
    static node mpi_unpack (const void* buffer, std::size_t size,
                            int& position, MPI::Comm& c);
    std::size_t mpi_size (const MPI::Comm& c) const;
    
private:
    std::size_t size () const;

    void add_arc (arc a);
    bool del_arc (arc a);

    template <class Graph>
    arc choose_arc (const Graph& g) const;

    template <class Graph>
    void remove_loops (Graph& g) const;

    template <class Graph>
    void mark_arcs (Graph& g) const;

    template <class Graph>
    void infer_arcs (Graph& g);

    template <class Graph1, class Graph2>
    void rebuild (Graph1& g1, Graph2& g2);

    template <class Graph>
    inline node<T> left_child (Graph& g, arc a) const;

    template <class Graph>
    inline node<T> right_child (Graph& g, arc a) const;

    template <typename Cost>
    friend std::ostream& operator << (std::ostream& os, const node<Cost>& n);
    
    T                   _cost;
    std::vector<vertex> _incl;
    vertex              _orig_excl;    
    std::vector<vertex> _dest_excl;
};

} /* namespace tsp */

namespace bnb
{

template <typename T>
struct node_traits <tsp::node<T> > : public label_traits<T>
{
    typedef T cost_type;

    template <class Graph>
    static tsp::node<T> initial (const Graph& g)
    { return tsp::node<T> (g.size ()); }
}; 

} /* namespace bnb */

namespace tsp
{

template <typename T>
std::ostream& operator << (std::ostream& os, const node<T>& n);

template <typename T>
inline T bnb_cost (const node<T>& n) { return n.cost (); }

template <typename T>
inline bool bnb_is_solution (const node<T>& n) { return n.is_solution (); }

template <class Graph>
bool is_inconsistent (const Graph& g);

template <class Graph>
typename Graph::value_type reduce (Graph& g);

template <class Graph>
inline void put_arc (Graph& tsp, arc a);

template <typename Graph>
inline void take_arc (Graph& tsp, arc a);

} /* namespace tsp */
} /* namespace pdp */

#include "tsp.tpp"

#endif /* PDP_TSP_H_ */
