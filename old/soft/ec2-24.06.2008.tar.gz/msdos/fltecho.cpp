
#include "fltecho.h"
#include <cstring>
#include <iostream>

using namespace std;

void FilterEcho::allocate()
{
  m_buffer = new float[m_delay];
  memset(m_buffer, 0, sizeof(float) * (m_delay));
}

void FilterEcho::liberate()
{
  delete [] m_buffer;
}

FilterEcho::FilterEcho(int delay, float feedback, float hidamp) :
  m_buffer(0),
  m_delay(delay),
  m_pos(0),
  m_feedback(feedback),
  m_hidamp(hidamp),
  m_old_val(0.0f)
{
  allocate();
}

FilterEcho::~FilterEcho()
{
  liberate();
}

void FilterEcho::process(Sample* in, int n_samples)
{
  float val;
  
  while (n_samples--) {
    if (m_pos >= m_delay)
      m_pos = 0;

    val = (((float)*in - 127.0f) / 128.0f) - m_buffer[m_pos] * m_feedback;
    *in++ = (Sample)((val + 1.0f) * 127.0f);

    /* Low pass filter. */
    val = val * m_hidamp + m_old_val * (1.0 - m_hidamp);

    m_buffer[m_pos] = val;
    m_old_val = val;
    m_pos++;
  }
}
