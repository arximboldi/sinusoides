--
--  File:       Phisical.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Wed May 27 12:28:07 2009
--  Time-stamp: <2009-05-31 12:33:10 raskolnikov>
--
--  Calculo de ataques físicos, etc...
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Nexus.Phisical where

import Maybe
import Data.Array

import Mech.Info
import Mech.Action

import Nexus.Attack
import Nexus.Shoot
import Nexus.State
import Nexus.Debug

phisMech :: NexusState -> Map -> Mech -> Mech -> [ Attack Hit ]
phisMech st m src dst = if isNear then map buildPhis allHits else []
    where
      srcpos = position src
      dstpos = position dst

      isNear = isJust $ safeHexSide srcpos dstpos
      
      legAngle   = shootAngle srcpos (side src) dstpos
      trunkAngle = shootAngle srcpos (trunkSide src) dstpos
      targetAngle = shootAngle dstpos (side dst) srcpos
      
      diffh  = level (m ! srcpos) - level (m ! dstpos)
      used x = not $ elem (hitLoc x) (usedLocations st)
      loc x = (internalPoints src ! hitLoc x) > 0
      filterhit = (filter loc) . (filter used) . (filter (canHit diffh (onFloor dst)))

      allHits = (filterhit . possibleTrunkHits) trunkAngle ++ 
                (take 1 . filterhit . possibleLegHits) legAngle
      
      buildPhis x = Attack x (phisMod x) 0 (phisDamage src x) (phisAnglePoints dst x targetAngle) dst

phisAnglePoints :: Mech -> Hit -> Angle -> Int
phisAnglePoints m (Punch _) Front 
    = 2 * p ArmourLeftArm + 2 * p ArmourRightArm + 2 * p ArmourHead + 
      2 * p ArmourLeftTrunk + 2 * p ArmourRightTrunk + 2 * p ArmourTrunk
    where p = (armourPoints m !)
phisAnglePoints m (Punch _) LeftLateral 
    = 4 * p ArmourLeftArm + 2 * p ArmourHead + 
      4 * p ArmourLeftTrunk + 2 * p ArmourTrunk
    where p = (armourPoints m !)
phisAnglePoints m (Punch _) RightLateral 
    = 4 * p ArmourRightArm + 2 * p ArmourHead + 
      4 * p ArmourRightTrunk + 2 * p ArmourTrunk
    where p = (armourPoints m !)
phisAnglePoints m (Punch _) Rear 
    = 2 * p ArmourLeftArm + 2 * p ArmourRightArm + 2 * p ArmourHead + 
      2 * p ArmourLeftBackTrunk + 2 * p ArmourRightBackTrunk + 2 * p ArmourBackTrunk
    where p = (armourPoints m !)

phisAnglePoints m (Kick _) Front 
    = 6 * p ArmourRightLeg + 6 * p ArmourLeftLeg
    where p = (armourPoints m !)
phisAnglePoints m (Kick _) LeftLateral 
    = 12 * p ArmourLeftLeg
    where p = (armourPoints m !)
phisAnglePoints m (Kick _) RightLateral 
    = 12 * p ArmourRightLeg
    where p = (armourPoints m !)
phisAnglePoints m (Kick _) Rear 
    = 6 * p ArmourRightLeg + 6 * p ArmourLeftLeg
    where p = (armourPoints m !)

phisAnglePoints m _ _ = totalArmourPoints m -- TODO

phisDamage :: Mech -> Hit -> Int
phisDamage m (Punch _)   = (weight . defmech) m `div` 10
phisDamage m (Kick _)    = (weight . defmech) m `div` 5
phisDamage m (Blow _)    = (weight . defmech) m `div` 5
phisDamage m (Sword _ _) = (weight . defmech) m `div` 5

phisMod :: Hit -> Int
phisMod (Punch _)   = 4
phisMod (Kick _)    = 3
phisMod (Blow _)    = 4
phisMod (Sword _ _) = 4

canHit :: Int -> Bool -> Hit -> Bool

canHit 0 False _       = True
canHit _ True (Kick _) = False

canHit 1 _  (Punch _)   = False
canHit 1 False (Kick _) = True
canHit 1 False (Blow _)     = True
canHit 1 False (Sword _ _)  = True

canHit (-1) _ (Punch _)   = True
canHit (-1) _ (Kick _)    = False
canHit (-1) _ (Blow _)    = True
canHit (-1) _ (Sword _ _) = True

canHit _    _ _ = False

possibleTrunkHits :: Angle -> [Hit]
possibleTrunkHits Front        = [Punch RightArm, Punch LeftArm]
possibleTrunkHits LeftLateral  = [Punch LeftArm]
possibleTrunkHits RightLateral = [Punch RightArm]
possibleTrunkHits _            = []

possibleLegHits :: Angle -> [Hit]
possibleLegHits Front        = [Kick LeftLeg, Kick RightLeg]
possibleLegHits _            = []
