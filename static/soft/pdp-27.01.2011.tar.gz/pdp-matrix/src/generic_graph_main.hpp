/**
 *  Time-stamp:  <2010-11-26 15:19:41 raskolnikov>
 *
 *  @file        generic_main.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Sat Nov 20 23:45:17 2010
 *
 *  Main genérico para todos los tipos de algoritmos.
 */

#ifndef PDP_ALGO_GENERIC_MAIN_H_
#define PDP_ALGO_GENERIC_MAIN_H_

#include "graph.hpp"

#include <iostream>

namespace pdp
{

/**
 * AlgoAlgo debe tener una función estática 'apply' y un tipo asociado con la
 * distribución a usar.
 */
template<class GraphAlgo>
int generic_graph_main (int argc, char** argv)
{
    typedef GraphAlgo                              graph_algo;
    typedef typename graph_algo::dist_graph        dist_graph;
    typedef graph<typename dist_graph::label_type> local_graph;

    if (argc != 2)
    {
	std::cerr << "Sintaxis: " << argv [0] << " <archivo de grafo>"
		  << std::endl;
	return -1;
    }
    
    MPI::Init (argc, argv);

    int	world_rank = MPI::COMM_WORLD.Get_rank ();
    
    local_graph g;
    if (world_rank == 0)
    {	
	std::ifstream is (argv [1]);
	is >> g;
    }
    
    double t;

    {
	dist_graph d (MPI::COMM_WORLD, g, 0);

	MPI::COMM_WORLD.Barrier ();
	t = MPI::Wtime ();
	
#ifdef DEBUG	
	std::cout << "start: " << world_rank << std::endl << g << std::endl;
#endif
	
	graph_algo::apply (d);

#ifdef DEBUG
	std::cout << "end: " << world_rank << std::endl << g << std::endl;
#endif
	
	MPI::COMM_WORLD.Barrier ();
	t = MPI::Wtime () - t;
    }
    
    MPI::Finalize ();
    if (world_rank == 0)
    {
	std::cout << std::endl
		  << "El Grafo con las distancias de los caminos más cortos es:"
		  << std::endl << std::endl
		  << g;
	std::cerr << "Tiempo gastado = " << t << std::endl << std::endl;
    }

    return 0;
}

} /* namespace pdp */

#endif /* PDP_GENERIC_ALGO_MAIN_H_ */
