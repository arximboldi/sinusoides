/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

/**
 * Interfaz de un evaluador de jugadas de poker. Un evaluador permite obtener un
 * valor numérico sobre la puntuación de una mano y otra información relacionada
 * con el valor de la mano.
 * 
 * @author raskolnikov
 */
public interface PokerEvaluator
{
	/**
	 * Enumerado de los distintos tipos de manos que pueden tenerse con una
	 * puntuación de referencia.
	 */
	public enum Hand 
	{
		HIGH_CARD       (1.0), /**< Carta alta. */
		ONE_PAIR        (2.0), /**< Pareja */
		TWO_PAIR        (3.0), /**< Doble pareja */
		THREE_OF_A_KIND (4.0), /**< Trío */
		STRAIGHT        (5.0), /**< Escalera */
		FLUSH           (6.0), /**< Color **/
		FULL_HOUSE      (7.0), /**< Full */
		FOUR_OF_A_KIND  (8.0), /**< Poker */
		STRAIGHT_FLUSH  (9.0); /**< Escalera de color */
		
		/** Constructor de la instancia estática del enumerado. */
		Hand (double value) { m_value = value; }
		
		/** Devuelve el valor de ese enumerado. */
		public double value () { return m_value; }
		
		/** El valor del enumerado. */
		private double m_value;
	}
	
	/**
	 * Realiza todo el computo necesario para evaluar la jugada. Evaluar
	 * la jugada puede cambiar el orden de las cartas proporcionadas.
	 */
	public void   evaluate ();
	
	/**
	 * Devuelve la puntuación de la jugada.
	 * @return La puntuación.
	 */
	public double points ();
	
	/**
	 * Devuelve la relevancia de cada carta en la mano actual. Aunque se
	 * deja libertad al evaluador para establecer su criterio se recomienda
	 * que sea la puntuación de alguna jugada en la que participan.
	 */
	public double[] cardPoints ();
	
	/**
	 * Devuelve el tipo de mano que tiene el jugador.
	 * @return La mano.
	 */
	public Hand   hand ();
}
