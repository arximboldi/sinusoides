/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import game.Card;
import game.Player;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;

/**
 * Vista pasiva de un jugador de poker.
 * @author raskolnikov
 *
 */
public class PassivePlayerView extends PlayerView
{
	private static int NUM_CARDS = 5;
	
	/**
	 * Constructor.
	 * @param parent Compuesto sobre el que instalar la vista.
	 * @param player El jugador a visualizar.
	 * @param pub Hacer verdadero para que se muestren siempre las cartas.
	 */
	PassivePlayerView (Composite parent, Player player, boolean pub)
	{
		super (parent, player);
		m_public = pub;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void buildGui (Composite parent)
	{
		m_cards_grid = new Group (parent, SWT.NONE);
		m_cards_grid.setLayout (new GridLayout (NUM_CARDS, false));
		
		for (int i = 0; i < NUM_CARDS; ++i) {
			Label card = new Label (m_cards_grid, SWT.NONE);
			m_cards_pic.add (card);
		}
		
		updateCards (true);
		m_cards_grid.pack ();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void showCards ()
	{
		if (!m_public) {
			updateCards (true);
		}
	}
	
	/**
	 * {@inheritDoc}
	 */	
	@Override
	public void hideCards ()
	{
		if (!m_public) {
			updateCards (false);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void handlePlayerDrop(Player p, Collection<Card> d)
	{
		m_cards.removeAll(d);
		updateCards (m_public);
	}

	/**
	 * {@inheritDoc}
	 */
	public void handlePlayerDropAll(Player p, List<Card> c)
	{
		m_cards.removeAll(c);
		updateCards (m_public);
	}

	/**
	 * {@inheritDoc}
	 */
	public void handlePlayerTake(Player p, Card c)
	{
		m_cards.add (c);
		updateCards (m_public);
	}
	
	private void updateCards (boolean show)
	{
		int i = 0;
		for (Label l : m_cards_pic) {
			if (i >= m_cards.size ())
				l.setImage (ImageFactory.getVoid ());
			else if (show)
				l.setImage (ImageFactory.getCard (m_cards.get(i)));
			else
				l.setImage (ImageFactory.getBackside ());
			++i;
		}
	}
	private Composite m_cards_grid;
	private LinkedList<Label> m_cards_pic = new LinkedList<Label> ();
	private Vector<Card> m_cards = new Vector<Card> (NUM_CARDS);
	
	private boolean m_public = false;
}
