#!/bin/bash

mmv "*" "#l1"

