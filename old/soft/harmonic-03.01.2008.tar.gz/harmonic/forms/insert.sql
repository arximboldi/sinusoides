

insert into hm_person values(1,'01/01/1900');
insert into hm_user values(1,'usuarioprueba','123','prueba@hotmail.com','1234','Usuario de prueba','m','Feo, fuerte y formal','01/01/2000','miweb.com','miavatar.com');

insert into hm_taggeable values (1);
insert into hm_taggeable values (2);
insert into hm_taggeable values (3);
insert into hm_taggeable values (4);
insert into hm_taggeable values (5);
insert into hm_taggeable values (6);
insert into hm_taggeable values (7);
insert into hm_taggeable values (8);
insert into hm_taggeable values (9);
insert into hm_taggeable values (10);

insert into hm_artist values(1,'Pink Floyd','Surgi� durante la d�cada de los 60 blablabla...');
insert into hm_artist values(2,Chopin','Sus nocturnos blablabla....');
insert into hm_artist values(3,'An endless sporadic','Pareja estadounidense dedicada a lo progresivo blablabla...');

insert into hm_song values(4,'Another brick in the wall','The wall','01/01/1970','url.brick.com');
insert into hm_song values(5,'Datk side of the moon','The dark side...','01/01/1970','url.moon.com');
insert into hm_song values(8,'the adventures of jabubu','ameliorate','01/01/2006','url.jabubu.com');
insert into hm_song values(9,'Sun pearl','ameliorate','01/01/2006','url.pearl.com');
insert into hm_song values(10,'anything','ameliorate','01/01/2006','url.anything.com');


insert into hm_author values(1,4);
insert into hm_author values(1,5);
insert into hm_author values(3,8);
insert into hm_author values(3,9);
insert into hm_author values(3,10);


insert into hm_rating values(1,4,5);
insert into hm_rating values(1,10,3);