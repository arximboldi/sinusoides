/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.gen;

import org.w3c.dom.*;
import java.util.*;

public class ItemList implements Generator
{
    public class Item extends ContentGenerator
    {
	String m_text = null;
	
	private Item() {}

	private Item(String text) {
	    m_text = text;
	}
	
	public Node generate(Document doc)
	{
	    Element el = doc.createElement("li");

	    if (m_text != null)
		el.appendChild(doc.createTextNode(m_text));

	    return generateContent(el);
	}
    }

    public enum Type { ORDERED, UNORDERED }
    
    List<Item> m_items = new LinkedList<Item>();
    Type m_type = Type.UNORDERED;

    public ItemList() {}

    public ItemList(Type type) {
	m_type = type;
    }

    public Item addItem() {
	Item item = new Item();
	m_items.add(item);

	return item;
    }

    public Item addItem(Generator gen) {
	Item item = new Item();
	m_items.add(item);
	item.addContent(gen);

	return item;
    }
    
    public Item addItem(String text) {
	Item item = new Item(text);
	m_items.add(item);

	return item;
    }
    
    public Node generate(Document doc)
    {
	Element el = null;

	if (m_type == Type.ORDERED)
	    el = doc.createElement("ol");
	else
	    el = doc.createElement("ul");
	
	Iterator it = m_items.iterator();
	while (it.hasNext())
	    el.appendChild(((Generator)it.next()).generate(doc));

	return el;
    }
}
