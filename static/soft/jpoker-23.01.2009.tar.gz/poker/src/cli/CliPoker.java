/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package cli;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;

import game.*;
import uk.co.flamingpenguin.jewel.cli.*;

/**
 * Implementa un juego de poker por linea de comandos.
 * @author raskolnikov
 */
public class CliPoker 
{
	/**
	 * Programa principal.
	 * @param raw Los parámetros del programa.
	 */
	public static void main (String[] raw)
	{
		try {
		    Game game;
		    
		    CliPokerArgs args = CliFactory.parseArguments(CliPokerArgs.class, raw);
		    
			if (args.isLog ())
				m_log_file = new PrintStream (new FileOutputStream (args.getLog ()));
			
			game = createGame (args);
			createPlayers (game, args);
			playGame (game);
		}
		catch(Exception e) {
			System.err.println (e.getMessage ());
			e.printStackTrace ();
		}
		finally {
			if (m_log_file != null)
				try { 
					m_log_file.close (); 
				} catch (Exception e) {}
		}
	}

	/**
	 * Juega una partida de poker.
	 * @param game La partida sobre la que jugar. 
	 * @throws GameException si hubo algun error.
	 */
	private static void playGame (Game game) 
		throws GameException
	{
		game.start ();
		game.play ();
		game.stop ();
	}

	/**
	 * Crea los jugadores y los añade a la partida.
	 * @param game El juego dónde han de unirse los jugadores.
	 * @param args Los argumentos del programa.
	 * @throws GameException sii no se pudieron añadir los jugadores.
	 * @throws FileNotFoundException sii No se pudo crear el log.
	 */
	private static void createPlayers (Game game, CliPokerArgs args) 
		throws GameException, FileNotFoundException
	{
		CliPlayerListener std_out = null;
		CliPlayerListener log_out = null;
		
		if (!args.getQuiet ())
			std_out = new CliPlayerListener (new CliStreamPrinter (System.out),
					args.getPublic ());
		
		if (args.isLog ())
			log_out = new CliPlayerListener (new CliStreamPrinter (m_log_file),
					args.getPublic ());
		
		if (args.isPlayers ()) {
			List<String> pnames = args.getPlayers ();
			Iterator<String> it = pnames.iterator ();
			Player p;
			
			if (it.hasNext() && args.getHuman ()) {
				p = new CliPokerPlayer (it.next(), args.getMoney ());
				if (std_out != null) p.addListener (std_out);
				if (log_out != null) p.addListener (std_out);
				game.join (p);
			}
			
			while (it.hasNext ()) {
				p = new DumbPokerPlayer (it.next(), args.getMoney ());
				if (std_out != null) p.addListener (std_out);
				if (log_out != null) p.addListener (std_out);
				game.join(p);
			}
		}
	}

	/**
	 * Crea la partida.
	 * @param args Los argumentos del programa.
	 * @return La partida creada.
	 */
	private static Game createGame (CliPokerArgs args) 
	{
		Game game = new PokerGame (args.getBet ());
		
		if (!args.getQuiet ())
			game.addListener (new CliGameListener ());
		if (args.isLog ())
			game.addListener (new CliGameListener (new CliStreamPrinter (m_log_file)));
		
		return game;
	}
	
	private static PrintStream m_log_file = null;
}
