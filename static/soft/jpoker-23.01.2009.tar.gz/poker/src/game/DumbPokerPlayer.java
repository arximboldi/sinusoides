/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.List;
import java.util.Vector;

/**
 * Jugador de poker totalmente estúpido.
 * @author raskolnikov
 */
public class DumbPokerPlayer extends PokerPlayer 
{
	/**
	 * Constructor.
	 * @param name Nombre del jugador.
	 * @param savings Ganancias inciales del jugador.
	 */
	public DumbPokerPlayer (String name, double savings)
	{
		super (name, savings);
	}
	
	/**
	 * {@inheritDoc}
	 * Este jugador siempre iguala.
	 */
	@Override
	public double chooseBet ()
	{
		return java.lang.Math.min (getGame ().getMinBet (), getSavings ());
	}

	/**
	 * {@inheritDoc}
	 * Este jugador nunca devuelve cartas.
	 */
	@Override
	public List<Card> chooseDrop ()
	{
		return new Vector<Card> ();
	}

	/**
	 * {@inheritDoc}
	 * Este jugador nunca abandona.
	 */
	@Override
	public boolean leave()
	{
		return false;
	}
}

