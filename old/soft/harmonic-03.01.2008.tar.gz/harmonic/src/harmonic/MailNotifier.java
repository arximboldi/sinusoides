/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic;

import javax.mail.*;
import javax.mail.internet.*;
import java.net.InetAddress;
import java.util.Properties;

public class MailNotifier
{
    final String localhost;
    final String mailhost;
    final String mailuser;
    final String email_notify;
    protected Session session= null;

    public MailNotifier(String _localhost, String _mailhost, String _mailuser, String _email_notify) {
	localhost= _localhost;
	mailhost= _mailhost;
	mailuser= _mailuser;
	email_notify= _email_notify;
    }

    public void send(String subject, String text)  throws Exception {
	send(email_notify, subject, text);
    }

    public void send(String _to, String subject, String text)  throws Exception {
	if (session== null) {
	    Properties p = new Properties();
	    p.put("mail.host", mailhost);
	    p.put("mail.user", mailuser);
	    session = Session.getDefaultInstance(p, null);

	    // Try to fake out SMTPTransport.java and get working EHLO:
	    Properties properties = session.getProperties();
	    String key= "mail.smtp.localhost";
	    String prop= properties.getProperty(key);
	    if (prop== null)   properties.put(key, localhost);
	    else  System.out.println(key+ ": "+ prop);
	    //session.setDebug(true);
	}
	MimeMessage msg = new MimeMessage(session);
	msg.setText(text);
	msg.setSubject(subject);
	Address fromAddr = new InternetAddress(mailuser);
	msg.setFrom(fromAddr);
	Address toAddr = new InternetAddress(_to);
	msg.addRecipient(Message.RecipientType.TO, toAddr);       
	Transport.send(msg);
	// Note: will use results of getLocalHost() to fill in EHLO domain
    }

    public String getLocalHost() {
	String localHostName= null;
	String name = "smtp";  // Name of this protocol
	try {
	    // get our hostname and cache it for future use
	    if (localHostName == null || localHostName.length() <= 0)
		localHostName =  session.getProperty("mail." + name + ".localhost");
	    if (localHostName == null || localHostName.length() <= 0)
		localHostName = InetAddress.getLocalHost().getHostName();
	} catch (Exception uhex) {
	}
	return localHostName;
    }
}
