#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade
import datetime

from common import *
from dao import *
from gui_tools import *

class BirthdayWindow (GladeDialog):
    def __init__ (self):
        GladeDialog.__init__(self, GUI_BIRTHDAY, 'window-birthday')
        text = self.generate_text ()
        self.get_widget ('text-list').get_buffer ().set_text (text)
        self.show ()
        
    def generate_text (self):
        li = []
        try:
            dao = DaoFactoryMgr ().create_member_dao ()
            li = dao.list_birthday ()
        except Exception, e:
            show_error_dialog ('Error while fetching birthday information', str (e))
        
        text = ''
        for i in li:
            text = text + str (i.id) + '. ' + i.name + ' ' + i.surname + ' is ' + str (datetime.date.today ().year - i.birth_date.year) + ' years old.\n'
        return text

    def handle_ok (self, win):
        self.destroy ()
