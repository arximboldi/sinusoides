/**
 *  Time-stamp:  <2010-11-21 01:23:52 raskolnikov>
 *
 *  @file        uni_dist_graph.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Fri Nov 19 11:42:28 2010
 *
 *  Abstracción sobre una distribución unidimensional del grafo.
 */

#ifndef PDP_UNI_DIST_GRAPH_H_
#define PDP_UNI_DIST_GRAPH_H_

#include "graph.hpp"

namespace pdp
{

/**
 * Clase que distribuye el grafo por MPI.  Esta clase puede usa RAII
 * (Resource-Adquisition-Is-Initialization).
 * 
 * Los datos son adquiridos en el constructor y reconstruidos en el
 * grafo original en el destructor. Uno no debe usar directamente el
 * grafo original mientras una instancia de este objeto que se ha
 * apropiado de ese grafo está con vida.
 *
 * Se puede escapar del RAII llamando manualmente a reset (). También
 * se puede violar RAII llamando a scatter () sin llamar a gather ().
 */
template<typename Label>
class uni_dist_graph : public detail::graph_base<Label>
{
public:
    /**
     * Constructor que no adquiere ningún grafo.
     */
    uni_dist_graph ()
    { reset (); }

    /**
     * Constructor que adquiere y distribuye un grafo.
     */
    uni_dist_graph (MPI::Comm& comm, graph<Label>& g, int root)
    {
	reset ();
	scatter (comm, g, root);
    }

    /** Destructor */
    ~uni_dist_graph ()
    { gather (); }
    
    void scatter (MPI::Comm& com, graph<Label>& g, int root);
    
    void bcast_row (size_t row);

    void gather (int root = -1);

    void bcast_col (size_t k) {}
    size_t local_col_begin () const { return 0; }
    size_t local_col_end () const { return _size; }
    
    /**
     * Resetea la distribución unidimensional. Esto evita que se
     * ejecute que se reconstruya la distribución en el destructor.
     */
    void reset ()
    {
	_comm = 0;
	_data = 0;
	_size = _local_begin = _local_end = 0;
    }
        
    /**
     * Devuelve la primera fila almacenada localmente. No cuenta las
     * distrbuidas manualmente con bcast.
     */
    size_t local_row_begin () const
    { return _local_begin; }

    /**
     * Devuelve la ultima fila almacenada localmente.
     */
    size_t local_row_end () const
    { return _local_end; }
    
private:
    void _check (MPI::Comm& comm, graph<Label>& g);
    
    void _local_range (MPI::Comm& comm, size_t& begin, size_t& end)
    {
	begin = _size / comm.Get_size () * comm.Get_rank ();
	end   = begin + _size / comm.Get_size ();
    }
    
    MPI::Comm* _comm;
    int        _default_root;
    size_t     _local_begin;
    size_t     _local_end;
    
    using detail::graph_base<Label>::_data;
    using detail::graph_base<Label>::_size;
};

} /* namespace pdp */

#include "uni_dist_graph.tpp"

#endif /* PDP_UNI_DIST_GRAPH_H_ */

