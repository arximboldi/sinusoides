/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package cli;

import java.io.File;
import java.util.List;

import uk.co.flamingpenguin.jewel.cli.Option;
import uk.co.flamingpenguin.jewel.cli.Unparsed;

/**
 * Argumentos que el poker de linea de comandos recibe de la terminal.
 * Estan autodocumentadas en la anotación Option
 * 
 * @author raskolnikov
 */
public interface CliPokerArgs
{
	@Unparsed (name="PLAYERS")
	List<String> getPlayers ();
	boolean isPlayers ();
	
	@Option (description = "record the match into a log file",
			shortName = "l")
	File getLog ();
	boolean isLog ();

	@Option (description = "minumum starting bet",
			shortName = "b",
			defaultValue = "10.0")
	double getBet ();
	
	@Option (description = "initial ammount of money",
			shortName = "m",
			defaultValue = "1000.0")
	double getMoney ();
	
	@Option (description = "the first player is human",
			shortName = "h")
	boolean getHuman ();
	
	@Option (description = "do not output to stdout",
			shortName = "q")
	boolean getQuiet ();

	@Option (description = "show card values for all players",
			shortName = "p")
	boolean getPublic ();
		
	@Option (helpRequest = true,
			description = "display this help message",
			shortName = "?")
	boolean getHelp();
}
