
#include <pc.h>
#include "player.h"

using namespace std;

Player::Player()
{
}

Player::~Player()
{
  list<Filter*>::iterator it;
  for (it = m_filters.begin(); it != m_filters.end(); ++it)
    delete *it;
}

void Player::filter(Sample* buf, int n_samples)
{
  list<Filter*>::iterator it;
  for (it = m_filters.begin(); it != m_filters.end(); ++it)
    (*it)->process(buf, n_samples);
}

void Player::process(Output* out, int n_samples)
{
  Sample tmp_buf[n_samples];
  int n_read;
  
  if (!kbhit() &&
      (n_read = m_file->read(tmp_buf, n_samples)) > 0) {
    filter(tmp_buf, n_read);
    out->put(tmp_buf, n_read);
  } else
    out->stop();
}
