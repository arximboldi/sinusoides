/**
 *  Time-stamp:  <2011-01-25 03:05:07 raskolnikov>
 *
 *  @file        graph.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Wed Nov 17 21:40:13 2010
 *
 *  Grafo representado como matriz de adyacencia con utilitarios para
 *  el envío mediante MPI.
 */

#ifndef PDP_GRAPH_H
#define PDP_GRAPH_H

#include <ostream>
#include <limits>
#include <mpi.h>

namespace pdp
{

namespace detail
{

template <typename Label, bool HasInfinity>
struct label_traits_inf;

template <typename Label>
struct label_traits_inf<Label, false>
{
    static Label infinity ()
    { return std::numeric_limits<Label>::max (); }
};

template <typename Label>
struct label_traits_inf<Label, true>
{
    static Label infinity ()
    { return std::numeric_limits<Label>::infinity (); }
};

template <typename Label>
struct label_traits_base :
	public label_traits_inf<Label,
				std::numeric_limits<Label>::has_infinity>
{};

} /* namespace detail */

/**
 * Traits de las etiquetas de las aristas de un grafo. Cada trait
 * aporta dos funciones estáticas que devuelven respectivamente:
 *     mpi_type: Esta función devuelve el valor MPI::Datatype que
 *               implementa el tipo de la etiqueta sobre MPI.
 *     infinity: Esta función devuelve el valor que representa
 *               infinito en el tipo o el más apropiado en su defecto.
 */
template <typename Label>
struct label_traits : detail::label_traits_base<Label> {};

template <>
struct label_traits<float> : detail::label_traits_base<float>
{
    static const MPI::Datatype& mpi_type () { return MPI::FLOAT; }
};

template <>
struct label_traits<double> : detail::label_traits_base<double>
{
    static const MPI::Datatype& mpi_type () { return MPI::DOUBLE; }
};

template <>
struct label_traits<int> : detail::label_traits_base<int> 
{
    static const MPI::Datatype& mpi_type () { return MPI::INT; }
};

namespace detail
{

/* Utilidad de la interfaz común base del grafo */
template <typename Label>
class graph_base
{
public:
    typedef Label label_type;
    typedef Label value_type;

    /**
     * Devuelve el valor "infinito" para esta matriz de adyacencia.
     */
    static const Label infinity ()
    { return label_traits<Label>::infinity (); }

    /**
     * Accede al vertice (i, j) de la matriz de adyacencia.
     */
    Label& operator () (size_t i, size_t j)
    { return _data [i][j]; }
    
    /**
     * Accede al vertice (i, j) de la matriz de adyacencia.
     */
    const Label& operator () (size_t i, size_t j) const
    { return _data [i][j]; }

    /**
     * Devuelve el número de vértices del grafo.
     */
    size_t size () const
    { return _size; }

    /**
     * Devuelve la matriz de datos en crudo.
     * @note La información de las etiquetas se encuentra en un bloque
     * consecutivo.
     */
    Label** raw () { return _data; }
    const Label* const * raw () const { return _data; }

protected:
    size_t   _size;
    Label**  _data;    
};

} /* namespace detail */

/**
 * Clase grafo representado como una matriz de adyacencia. Incluye
 * funciones que facilitan su uso entre procesos.
 */
template <typename Label>
class graph : public detail::graph_base<Label> 
{
public:
    /**
     * Constructor. Inicializa la matriz de adyacencia como un grafo
     * totalmente inconexo.
     * @param verts Numero de vertices en el grafo.
     */
    inline graph (size_t verts = 0);

    graph (const detail::graph_base<Label>& g);

    graph (const graph& g);
    
    graph& operator= (const detail::graph_base<Label>& g);

    graph& operator= (const graph& g);

#ifdef __GXX_EXPERIMENTAL_CXX0X__
    inline graph (const detail::graph_base<Label>&& g);

    inline graph (const graph&& g);
    
    inline graph& operator= (const detail::graph_base<Label>&& g);

    inline graph& operator= (const graph&& g);

private:
    inline void _move (const detail::graph_base<Label>&& g);

public:
#endif
    
    /** Destructor. */
    ~graph ();

    /**
     * Reconstruye e inicializa la matriz con un numero dado de vertices.
     */
    void recreate  (size_t verts);
    
private:
    void _copy (const detail::graph_base<Label>& g);
    
    void _allocate (size_t s);
    void _liberate ();
    void _initialise ();
    
    using detail::graph_base<Label>::_data;
    using detail::graph_base<Label>::_size;
};

/**
 * Un grafo dado la vuelta.
 */
template<typename Label>
class flipped_graph
{
public:
    typedef Label label_type;

    /**
     * Devuelve el valor "infinito" para esta matriz de adyacencia.
     */
    static const Label infinity ()
    { return label_traits<Label>::infinity (); }

    
    flipped_graph (detail::graph_base<Label>& g)
        : _graph (g)
    {}

    /**
     * Accede al vertice (i, j) de la matriz de adyacencia.
     */
    Label& operator () (size_t i, size_t j)
    { return _graph (j, i); }
    
    /**
     * Accede al vertice (i, j) de la matriz de adyacencia.
     */
    const Label& operator () (size_t i, size_t j) const
    { return _graph (j, i); }

    std::size_t size () const { return _graph.size (); }

private:
    detail::graph_base<Label>& _graph;
};

template <typename Label>
flipped_graph<Label> make_flipped (detail::graph_base<Label>& g)
{
    return flipped_graph<Label> (g);
}

/**
 * Emite una representación humana sobre un stream.
 */
template <typename Label>
std::ostream& operator<< (std::ostream& os, const graph<Label>& g);

/**
 * Carga el grafo desde un stream siguiendo la sintaxis del guion de
 * practicas.
 */
template <typename Label>
std::istream& operator>> (std::istream& is, graph<Label>& g);

} /* namespace pdp */

#include "graph.tpp"

#endif /* GRAPH_H */

