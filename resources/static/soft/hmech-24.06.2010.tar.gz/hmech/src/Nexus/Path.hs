--
--  File:       Path.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Tue Mar 31 11:02:11 2009
--  Time-stamp: <2009-06-24 06:38:59 raskolnikov>
--
--  Modulo de algoritmos de busqueda de caminos en el mapa
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Nexus.Path where

import Data.Array
import Control.Monad

import qualified Mech.Action as A
import Mech.Info

import Nexus.AStar
import Nexus.GoodMap

import Nexus.LOS

--
-- Coste de moverse a través de una celda
--
moveCost :: Cell -> Cell -> Int
moveCost src dest = max terrainCost objectCost + levelCost
    where
      terrainCost = case terrain dest of
                      Water -> case level dest of
                                 0 -> 1
                                 1 -> 2
                                 _ -> 4
                      Swamp -> 2
                      _     -> 1
      objectCost  = case object dest of
                      Rubble         -> 2
                      LightWood      -> 2
                      HeavyWood      -> 3
                      LightBuilding  -> 2
                      MediumBuilding -> 3
                      HeavyBuilding  -> 4
                      StrongBuilding -> 5
                      _              -> 0
      levelCost   = (fromIntegral . abs) (level src - level dest)


--
-- Función distancia para al A*
--
astarDistance :: Map -> GoodMap -> Position -> Position -> Double
astarDistance m g x y = fromIntegral (moveCost (m!posHex x) (m!posHex y)) + 
                        fromIntegral (abs (rotation (posSide x) (posSide y))) +
                        max 0 (g!y)

--
-- Función heurística para el A*
-- Inspirada por la ecuación vista aquí:
-- http://eil.stanford.edu/pengao/Papers/A%20Modified%20Heuristic%20Search%20Algorithm%20for%20Pedestrian%20Simulation.pdf
--
-- TODO
astarHeuristic :: Map -> Position -> Position -> Double
astarHeuristic m (Pos x l) (Pos y l') = 
    fromIntegral $ hexHeuristic x y +
    fromIntegral (abs (rotation l l')) +
    (fromIntegral . abs) (level (m!x) - level (m!y))


hexHeuristic :: Hex -> Hex -> Int
hexHeuristic (Hex x0 y0) (Hex x1 y1) = dx + max 0 (dy - dx `div` 2 - factor)
    where
      dx = abs $ x1 - x0
      dy = abs $ y1 - y0
      factor | even dy   = 0
             | y0 < y1   = (x0 - 1) `mod` 2
             | otherwise = (x1 - 1) `mod` 2 

--
-- Los lados de Hex
-- 
sides :: [Side]
sides = [North .. NorthWest]

validHex :: State -> Hex -> Bool
validHex s h | not $ hexInMap m h                  = False
             | cellFire (m!h)                      = False
             | not $ null $ filter inhex (mechs s) = False
             | otherwise                           = True
    where m     = smap s
          inhex = (== h) . position 

--
-- Encuentra la ruta más corta entre dos hexágonos del mapa, andando
-- hacia adelante. Aunque le pasamos el encaramiento final normalmente 
-- lo descarta.
--
-- Aplicamos el algoritmo A* utilizando como nodos (Hex, Side), es decir
-- el par de un hexágono y un encaramiento. Esto se debe a que el coste
-- para moverse a otro hexágono también depende del numero de rotaciones.
--
findPathFw :: State -> GoodMap -> Position -> Position -> Maybe [Position]
findPathFw s g from to = aStar childs (astarDistance m g) (astarHeuristic m to) goal from
    where
      m = smap s
      -- Siguientes a un nodo
      childs (Pos hex _) = filter (childCond hex) $ map (nextChild hex) [North ..]
      -- Comprobación del destino
      goal = (== to)

      -- Utilidades
      nextChild hex side = Pos (nextHex hex side) side
      childCond hex x  = validHex s (posHex x) &&
                         (abs (level (m!hex) - level (m!posHex x)) < 3)

--
-- Equivalente pero con marcha atrás
--
findPathBw :: State -> GoodMap -> Position -> Position -> Maybe [Position]
findPathBw s g from to = aStar childs (astarDistance m g) (astarHeuristic m to) goal from
    where
      m = smap s
      -- Nodos siguientes
      childs (Pos hex _) = (filter (childCondFw hex) $ map (nextChildFw hex) sides) ++
                           (filter (childCondBw hex) $ map (nextChildBw hex) sides)
      -- Comprobación del destino
      goal = (== to)

      -- Utilidades
      nextChildFw hex side = Pos (nextHex hex side) side
      nextChildBw hex side = Pos (nextHex hex side) (flipSide side)
      childCondFw hex x    = validHex s (posHex x) &&
                             (abs (level (m!hex) - level (m!(posHex x)))) < 3
      childCondBw hex x    = validHex s (posHex x) &&
                             (level (m!hex) == level (m!(posHex x)))


--
-- Devuelve la ruta a seguir como secuencia de pasos a partir de
-- de la ruta como secuencia de hexágonos
--
pathToSteps :: Map           -- El mapa sobre el que jugamos
            -> Int           -- Numero de pasos
            -> [Position]    -- Lista de hexágonos por los que pasar
            -> [A.Step]      -- Resultado
pathToSteps m n (a:b:xs) | n <= 0    = []
                         | otherwise = 
    if rot == 0
    then if move <= n 
         then (A.Step moveDir 1) : pathToSteps m (n - move) (b:xs)
         else []
    else (A.Step dir $ min n rot) : 
         pathToSteps m (n - rot) ((Pos (posHex a) (posSide b)):b:xs)
    where
      move       = moveCost (m!posHex a) (m!posHex b)
      (dir, rot) = rotationDir (posSide a) (posSide b)
      moveDir    = if posSide b == flipSide (hexSide (posHex a) (posHex b)) 
                   then Backward
                   else Forward

pathToSteps _ _ _ = []

--
-- Simula la secuencia de pasos. Asume que los movimientos se producen
-- de uno en uno y que no hay ni saltos ni se tira al suelo.
--
simSteps :: Position -- Posicion actual
         -> [A.Step]    -- Secuencia de pasos
         -> Position -- Destinos a los que se llega
simSteps (Pos hex side) (x:xs) =
    if A.dir x == Forward || A.dir x == Backward
    then simSteps (Pos next side)     xs
    else simSteps (Pos hex nextSide) xs
    where
      next = nextHex hex (if A.dir x == Forward then side else flipSide side)
      nextSide = rotateDir side (A.dir x, A.value x)
simSteps dest _ = dest

--
-- Realiza el movimiento del jugador con n puntos de movimiento
-- utilizando sólo desplazamientos hacia adelante.
--
fwMove :: State -> GoodMap -> Int -> Position -> Position -> Maybe [A.Step]
fwMove s g n src dest =
    liftM (pathToSteps (smap s) n) $ findPathFw s g src dest

--
-- Realiza el movimiento del jugador con n puntos de movimiento
-- utilizando también movimientos hacia atrás
--
bwMove :: State -> GoodMap -> Int -> Position -> Position -> Maybe [A.Step]
bwMove s g n src dest =
    liftM (pathToSteps (smap s) n) $ findPathBw s g src dest


canJump :: Map -> Int -> Position -> Position -> Bool
canJump m pm (Pos src _) (Pos dst _) = 
    pm > 0 &&
    hexLineFold (\_ ac -> ac+1) 0 src dst <= pm && 
    hexLosFold maxdiff decidediff 0 src dst <= pm
    where
      srclvl = level (m ! src)
      decidediff a b ac = if maxdiff a ac < maxdiff b ac then a else b
      maxdiff h ac = max (level (m!h) - srclvl) ac

------------------------------------------------------------------------
-- DEPRECATED
-- Buzón de funciones que ya no se utilizan por si se volviesen útiles
-- en el futuro :-)
------------------------------------------------------------------------

--
-- Rotación por el lado más corto para estar encarado -respecto a ANDAR,
-- es decir, cuando dos hexágonos tienen el mismo nivel uno puede
-- andar marcha atrás. Esta función está desactualizada.
--
rotationBw :: Map -> (Hex, Side) -> (Hex, Side) -> (Direction, Int)
rotationBw m (a, s) (b, s') =
    if rf > rb && canBw then (db, rb) else (df, rf) 
    where
      canBw = abs (level (m!a) - level (m!b)) == 0 
      (df, rf)  = rotationDir s s'
      (db', rb) = rotationDir s $ flipSide s'
      db = if db' == Forward then Backward else db'

