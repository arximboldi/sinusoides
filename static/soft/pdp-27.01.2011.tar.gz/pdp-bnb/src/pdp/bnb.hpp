/**
 *  Time-stamp:  <2011-01-26 18:34:28 raskolnikov>
 *
 *  @file        bnb.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Thu Jan 13 13:26:58 2011
 *
 *  Funciones para el branch and bound.
 */

#ifndef PDP_BNB_H_
#define PDP_BNB_H_

#include <memory>
#include <list>

namespace pdp
{
namespace bnb
{

template <typename Node>
struct node_traits
{
    typedef int cost_type;
};

template <typename Node>
class state
{
public:
    typedef typename node_traits<Node>::cost_type cost_type;

    state (const Node& initial) { _stack.push_front (initial); }
    
    virtual cost_type best_cost () const
    { return bnb_cost (_best_node); }

    
    Node& best_node () { return _best_node; }
    const Node& best_node () const { return _best_node; }

    Node& next () { return _next; }

    const Node& next () const { return _next; }

    bool empty () const { return _stack.empty (); }

    void bound ();
    
    void push (const Node& n);

    void push_back (const Node& n);

    void pop ();

    std::size_t size () const { return _stack.size (); }
    
protected:
    typedef std::list<Node> stack_type;

    /* En ausencia de boost::optional esto fuerza que Node tenga un
     * constructor por defecto, lo cual puede no ser siempre posible
     * sin pervertir su semantica. Otra opcion sería usar un
     * std::auto_ptr, pero eso añade un estres innecesario sobre el
     * heap.
     */
    Node       _next;
    Node       _best_node;
    stack_type _stack;
};

template <typename Node, typename Context>
Node branch_and_bound (Context& ctx);

template <typename Node, typename Context>
struct branch_and_bound_fn
{
    typedef Node result_type;
    
    Node operator () (Context& ctx) const
    {
        return branch_and_bound<Node> (ctx);
    }
};

} /* namespace bnb */
} /* namespace pdp */

#include "bnb.tpp"

#endif /* PDP_BNB_H_ */
