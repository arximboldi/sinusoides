/*
 * Driver de sonido para Linux 2.6
 *
 * Autores:
 *   Juan Pedro Bolívar Puente
 *   Francisco Manuel Herrero Pérez
 */

/*
 * Buffer circular usuario. Se escribe desde el espacio de usuario
 * y se lee desde el kernel.
 */

#ifndef RING_BUF_H
#define RING_BUF_H

typedef enum
  {
    ERROR,
    OK
  } state_t;

typedef enum
  {
    RING_BUF_OK,
    RING_BUF_UNDERRUN,
    RING_BUF_OVERRUN
  } ring_buf_state_t;


typedef struct ring_buf_s
{
  char* data;
  size_t size;
  size_t write_pos;
  size_t write_count;
} ring_buf_t;

typedef ring_buf_t* ring_buf_p;

typedef struct ring_buf_reader_s
{
  size_t read_pos;
  size_t read_count;
} ring_buf_reader_t;

typedef ring_buf_reader_t* ring_buf_reader_p;

state_t
ring_buf_init (ring_buf_p buf, size_t size);

void
ring_buf_clear (ring_buf_p buf);

ssize_t
ring_buf_availible (ring_buf_p buf, ring_buf_reader_p reader);

ssize_t
ring_buf_write_availible (ring_buf_p buf, ring_buf_reader_p reader);

ring_buf_state_t
ring_buf_state (ring_buf_p buf, ring_buf_reader_p reader);

ring_buf_reader_t
ring_buf_begin (ring_buf_p buf);

state_t
ring_buf_write (ring_buf_p buf, const char* data, size_t nwrite);

ssize_t
ring_buf_read (ring_buf_p buf, ring_buf_reader_p reader,
	       char* dest, size_t samples);

char
ring_buf_read_one (ring_buf_p buf, ring_buf_reader_p reader);

#endif /* RING_BUF_H */
