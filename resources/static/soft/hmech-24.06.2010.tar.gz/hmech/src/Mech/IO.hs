--
--  File:       IO.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon Mar 16 21:34:36 2009
--  Time-stamp: <2009-05-31 18:12:56 raskolnikov>
--
--  Entrada y salida de los datos del estado.
--

module Mech.IO where

import System.IO
import Data.Char
import Data.Bool
import Control.Exception
import Maybe
import Data.Array

import Mech.Info 
import Mech.Action
import Nexus.Debug

--
-- Convierte un número en un booleano
-- 
toBool :: (Num a) => a -> Bool
toBool 0 = False
toBool _ = True

--
-- Realiza un mapeo entre el formato SBT y los elementos de Location
--
sbtLocation :: String -> Location
sbtLocation "BI"  = LeftArm
sbtLocation "BD"  = RightArm
sbtLocation "PI"  = LeftLeg
sbtLocation "PD"  = RightLeg
sbtLocation "TC"  = Trunk
sbtLocation "TI"  = LeftTrunk
sbtLocation "TD"  = RightTrunk
sbtLocation "CAB" = Head

--
-- Realiza un mapeo entre el formato SBT y un Hex
--
sbtHex :: String -> Hex
sbtHex s = Hex (read (take 2 s)) (read (drop 2 s))

--
-- Realiza un mapeo entre el formato SBT y los tipos de componente
--
sbtItem :: String -> Item
sbtItem "NADA"       = EmptyItem
sbtItem "ARMA"       = WeaponItem
sbtItem "MUNICION"   = AmmoItem
sbtItem "EQUIPO"     = EquipmentItem
sbtItem "ACTUADOR"   = ActuatorItem
sbtItem "ARMADURA"   = ArmourItem
sbtItem "ARMAFISICA" = PhisicalItem

--
-- Realiza un mapeo entre el formato SBT y los tipos de armas
--
sbtWeapon :: String -> WeaponType
sbtWeapon "Nada"      = NoneWeapon
sbtWeapon "Energía"   = Energy
sbtWeapon "Balística" = Gun
sbtWeapon "Misiles"   = Missile

--
-- Realiza un mapeo entre Hex y el formato SBT
--
toSbtHex :: Hex -> String
toSbtHex (Hex c r) = (azero c (show c)) ++ (azero r (show r))
    where azero x s | x < 10    = '0' : s
                    | otherwise = s 

--
-- Realiza un mapeo entre Movement y SBT
--
toSbtMovement :: Movement -> String
toSbtMovement None = "Inmovil"
toSbtMovement Walk = "Andar"
toSbtMovement Run  = "Correr"
toSbtMovement Jump = "Saltar"

--
-- Realiza un mapeo entre Direction y SBT
--
toSbtDirection :: Direction -> String
toSbtDirection Forward  = "Adelante"
toSbtDirection Backward = "Atras"
toSbtDirection LeftDir  = "Izquierda"
toSbtDirection RightDir = "Derecha"
toSbtDirection Up       = "Levantarse"
toSbtDirection Down     = "Cuerpo a Tierra"

--
-- Realiza un mapeo entre Rotation y SBT
--
toSbtRotation :: Rotation -> String
toSbtRotation NoneRot  = "Igual"
toSbtRotation LeftRot  = "Izquierda"
toSbtRotation RightRot = "Derecha"

--
-- Realiza un mapeo entre los elementos de Location y SBT
--
toSbtLocation :: Location -> String
toSbtLocation LeftArm    = "BI"
toSbtLocation RightArm   = "BD"
toSbtLocation LeftLeg    = "PI"
toSbtLocation RightLeg   = "PD"
toSbtLocation Trunk      = "TC"
toSbtLocation LeftTrunk  = "TI"
toSbtLocation RightTrunk = "TD"
toSbtLocation Head       = "CAB"

--
-- Realiza un mapeo entre Objective y SBT
--
toSbtObjective :: Objective -> String
toSbtObjective NoneObj = "Ninguno"
toSbtObjective HexObj  = "Hexagono"
toSbtObjective MechObj = "Mech"

--
-- Elimina los espacios en blanco al principio y al final de una cadena
--
strip :: String -> String
strip s = (reverse (dropWhile isSpace (reverse (dropWhile isSpace s))))

--
-- Carga un elemento utilizando la funcion read
--
loadR :: (Read a) => Handle -> IO a
loadR h = load read h

--
-- Carga una lista de elementos con read
--
loadListR :: (Read a) => Int -> Handle -> IO [a]
loadListR 0 h = return  []
loadListR n h =
    do x <- loadR h
       xs <- loadListR (n-1) h
       return (x:xs)

loadListR_ :: (Read a) => Int -> Handle -> [a] -> IO [a]
loadListR_ 0 h a = return  a
loadListR_ n h a = 
    do x  <- loadR h
       loadListR_ (n-1) h (x:a)

--
-- Carga una lista de elementos con otra funcion de carga
--
loadListF :: Int -> (Handle -> IO a) -> Handle -> IO [a]
loadListF 0 _ _     = return  []
loadListF n loadf h = 
    do x <- loadf h
       xs <- loadListF (n-1) loadf h
       return (x:xs)

loadListF_ :: Int -> (Handle -> IO a) -> Handle -> [a] -> IO [a]
loadListF_ 0 _  _ a = return  a
loadListF_ n loadf h a = 
    do x  <- loadf h
       loadListF_ (n-1) loadf h (x:a)

--
-- Carga una cadena tal cual y "stripped"
--
loadS :: Handle -> IO String
loadS h = do
    do line <- hGetLine h
       return  (strip line)

--
-- Carga un elemento utilizando una función de mapeo String al tipo
--
load :: (String -> a) -> Handle -> IO a
load p h =
    do line <- hGetLine h
       content <- return  (strip line)
       return  (p content)

--
-- Guarda un elemento utilizando la funcion show
--
storeS :: (Show a) => a -> Handle -> IO ()
storeS x h = hPrint h x

--
-- Guarda un elemento utilizando la funcion read
--
storeStr :: String -> Handle -> IO ()
storeStr x h = hPutStrLn h x

--
-- Guarda una lista de elementos con read
--
storeListS :: (Show a) => [a] -> Handle -> IO ()
storeListS []     h = return  ()
storeListS (x:xs) h = 
    do storeS x h
       storeListS xs h

--
-- Guarda una lista de elementos con otra funcion de carga
--
storeListF :: [a] -> (a -> Handle -> IO ()) -> Handle -> IO ()
storeListF [] _ _ = return  ()
storeListF (x:xs) storef h = 
    do storef x h
       storeListF xs storef h

--
-- Guarda un elemento utilizando una función de mapeo String al tipo
--
store :: a -> (a -> String) -> Handle -> IO ()
store x p h = hPutStrLn h (p x)

--
-- Comprueba que la siguiente linea del fichero contiene la cadena
-- especificada como parámetro
--
checkHeader :: String -> Handle -> IO ()
checkHeader s h =
    do header <- loadS h
       if (header /= s)
          then (error header)
          else return  ()
    where error s' = ioError (userError ("Wrong file header: " ++ s ++ " /= " ++ s'))

--
-- Carga la información de un Slot
--
loadSlot :: Handle -> IO Slot
loadSlot h = 
    do putStrLn "amigo"
       loc  <- load sbtLocation h 
       slot <- loadR h
       return  (Slot loc slot)

--
-- Carga el un fichero "mechSBT"
--
loadMechs :: Int ->                    -- Numero del mech del jugador 
             Handle ->                 -- Fichero desde el que cargar
             IO ([Mech], Mech, Player) -- Resultado con los mechs y el jugador
loadMechs id h =
    do checkHeader "mechsSBT" h
       num <- loadR h :: IO Int
       (m, c, p) <- loadNMechs 0 num h
       return  (m, fromJust c, fromJust p)
    where
      --
      -- Cargamos la lista de Mechs
      --
      loadNMechs :: Int -> Int -> Handle 
                 -> IO ([Mech], Maybe Mech, Maybe Player)
      loadNMechs n num h | n == num  = return  ([], Nothing, Nothing)
                         | otherwise =
          do
            x <- loadMech h
            if playerNum x == id 
              then do p <- loadPlayer h
                      _ <- loadListR num h  :: IO [Bool] -- TODO:
                      _ <- loadListR num h :: IO [Bool] -- Absurdo!
                      (xs, _, _) <- loadNMechs (n+1) num h
                      return  (xs, Just x, Just p)
              else do narcOn <- loadListR num h  :: IO [Bool] -- TODO:
                      inarcOn <- loadListR num h :: IO [Bool] -- Absurdo!
                      (xs, c, p) <- loadNMechs (n+1) num h
                      return  (x:xs,c, p)

      --
      -- Cargamos UN mech
      --
      loadMech :: Handle -> IO Mech
      loadMech h = 
          do playerNum <- loadR h :: IO Int
             operative <- loadR h :: IO Bool
             disconnected <- loadR h :: IO Bool
             blockedInSwamp <- loadR h :: IO Bool
             onFloor <- loadR h :: IO Bool
             position <- load sbtHex h :: IO Hex
             side <- loadR h :: IO Int -- toEnum
             trunkSide <- loadR h :: IO Int -- toEnum
             heat <- loadR h :: IO Int
             burning <- loadR h :: IO Bool
             club <- loadR h :: IO Bool
             treeClub <- loadR h :: IO Int -- toBool
             armourPoints <- loadListR numArmourLocation h
             internalPoints <- loadListR numLocation h

             -- Mejor tener la definición del mech a mano
             let defMechFile = "defmechJ" ++ show id ++ ('-' : (show playerNum) ++ ".sbt")
             defMech <- withOpenFile defMechFile ReadMode loadMechDef
             
             return  (Mech playerNum operative disconnected blockedInSwamp
                          onFloor position (toEnum $ side -1) 
                          (toEnum $ trunkSide -1) heat burning club 
                          (toBool treeClub) 
                          (array armourRange (zip [fst armourRange ..] armourPoints))
                          (array locationRange (zip [fst locationRange ..] internalPoints))
                          defMech)
      
      --
      -- Carga la definición extendida del jugador.
      -- El primer parametro es el numero de jugadores.
      --
      loadPlayer :: Handle -> IO Player
      loadPlayer h =
          do walkPoints <- loadR h :: IO Int
             runPoints <- loadR h :: IO Int
             jumpPoints <- loadR h :: IO Int
             radiatorsOn <- loadR h :: IO Int
             radiatorsOff <- loadR h :: IO Int
             warriorInjuries <- loadR h :: IO Int
             warriorConscious <- loadR h :: IO Bool
             criticalSlots <- loadListR numTotalSlots h
             weaponShot <- loadListR numLocation h
             numAmmo <- loadR h
             ammo <- loadListF numAmmo loadSlot h
             return  (Player walkPoints runPoints jumpPoints radiatorsOn
                            radiatorsOff warriorInjuries warriorConscious 
                            criticalSlots weaponShot ammo)

--
-- Carga un fichero de definición del mech
--
loadMechDef :: Handle -> IO MechDef
loadMechDef h = 
    do -- checkHeader "defmechSBT" h
       header <- loadS h -- HACK: Pasamos de la cabecera, es erronea
       mechName <- loadS h
       model <- loadS h
       weight <- loadR h
       power <- loadR h
       internalRadiators <- loadR h
       radiators <- loadR h
       hasMasc <- loadR h
       hasDacmtd <- loadR h
       hasDacmti <- loadR h
       hasDacmtc <- loadR h
       maxGeneratedHeat <- loadR h
       hasArm <- loadListR numArmParts h
       defArmourPoints <- loadListR numArmourLocation h
       defInternalPoints <- loadListR numLocation h
       numComp <- loadR h
       components <- loadListF numComp loadComponent h
       numWeapon <- loadR h :: IO Int
       numActuator <- loadR h
       actuators <- loadListF numActuator loadActuator h
       slots <- loadListF numLocation 
                (\h -> do numSlot <-loadR h
                          loadListF numSlot loadSlotDef h) h
       return  (MechDef mechName model weight power internalRadiators radiators
                       hasMasc hasDacmtd hasDacmti hasDacmtc maxGeneratedHeat 
                       hasArm  defArmourPoints defInternalPoints components
                       actuators slots)
    where
      --
      -- Carga la definición de un componente
      --
      loadComponent :: Handle -> IO Component
      loadComponent h =
          do code <- loadR h
             name <- loadS h
             item <- load sbtItem h
             onBack <- loadR h
             location <- loadR h :: IO Int -- toEnum
             secondaryLoc <- loadR h :: IO Int -- toEnum
             weptype <- load sbtWeapon h
             heatGen <- loadR h
             damage <- loadR h
             shotsPerTurn <- loadR h
             minDistance <- loadR h
             shortDistance <- loadR h
             mediumDistance <- loadR h
             longDistance <- loadR h
             compOperative <- loadR h
             weaponCode <- loadR h -- Si es municion
             amount <- loadR h
             isSpecial <- loadS h -- Todo
             shotMod <- loadR h
             return  (Component code name item onBack (toEnum location) 
                               (if secondaryLoc < 0 then Nothing else Just $ toEnum secondaryLoc) 
                               weptype heatGen damage shotsPerTurn minDistance
                               shortDistance mediumDistance longDistance
                               compOperative weaponCode amount False
                               shotMod)

      --
      -- Carga la definición de un Actuador
      --
      loadActuator :: Handle -> IO Actuator
      loadActuator h =
          do actCode <- loadR h
             actName <- loadS h
             actLocation <- loadR h :: IO Int -- toEnum
             actOperative <- loadR h
             impacts <- loadR h
             return  (Actuator actCode actName (toEnum actLocation)
                              actOperative impacts)

      --
      -- Carga la definición de un Slot usado
      --
      loadSlotDef :: Handle -> IO SlotDef
      loadSlotDef h =
          do slotItem <- load sbtItem h
             slotAmount <- loadR h -- solo ammo?
             slotCode <- loadR h
             slotName <- loadS h
             componentIndex <- loadR h
             actuatorIndex <- loadR h
             criticalDamage <- loadR h
             return  (SlotDef slotItem slotAmount slotCode slotName
                             componentIndex actuatorIndex criticalDamage)

--
-- Carga un fichero de definición del mapa
--
loadMap :: Handle -> IO Map
loadMap h =
    do checkHeader "mapaSBT" h 
       height <- loadR h
       width  <- loadR h
       -- cells  <- loadListF width (loadListF height loadCell) h
       cells <- loadListF (width * height) loadCell h
       return  (array (Hex 1 1, Hex width height) $
               zip [Hex i j | i<-[1..width], j<-[1..height]] cells)
    where    
      --
      -- Carga una celda del mapa
      --
      loadCell :: Handle -> IO Cell
      loadCell h =
          do level <- loadR h
             terrain <- loadR h
             object <- loadR h
             buildingFce <- loadR h
             buildingDemolished <- loadR h
             cellFire <- loadR h
             smoke <- loadR h
             clubs <- loadR h
             river <- loadListR numSide h  -- 6 lados
             road <- loadListR numSide h   -- 6 lados
             return  (Cell level (toEnum terrain) 
                          (if object /= 255 then toEnum object else Empty)
                          buildingFce buildingDemolished cellFire smoke clubs
                          river road)

--
-- Carga el fichero con los datos sobre la configuración.
--
loadConfig :: Handle -> IO Config
loadConfig h =
    do checkHeader "configSBT" h
       hasFire <- loadR h
       wind <- loadR h
       windDir <- loadR h -- toEnum
       phisicalPhase <- loadR h
       heatPhase <- loadR h
       devastateForest <- loadR h
       destroyBuilding <- loadR h
       pilotCheck <- loadR h
       pilotCheckOneTurn <- loadR h
       disconnectionCheck <- loadR h
       critical <- loadR h
       ammoExplosion <- loadR h
       radiatorShutdown <- loadR h
       hasTimeLimit <- loadR h
       timeLimit <- loadR h
       return  (Config hasFire wind (toEnum $ windDir-1) phisicalPhase heatPhase
                      devastateForest destroyBuilding pilotCheck pilotCheckOneTurn
                      disconnectionCheck critical ammoExplosion radiatorShutdown
                      hasTimeLimit timeLimit)

loadOrder :: Handle -> IO [Int]
loadOrder h =
    do nmech <- loadR h :: IO Int
       loadListR nmech h

--
-- Carga toda la información del estado del juego a partir de
-- los ficheros de datos proporcionados por el entorno
--
loadState :: Int ->    -- Numero del jugador actual
             IO State
loadState id = 
    do putStrLn "Loading Mechs"
       (mechs, current, player) <- withOpenFile mechsFile  ReadMode (loadMechs id)
       putStrLn "Loading Map"
       map              <- withOpenFile mapFile    ReadMode loadMap
       putStrLn "Loading Config"
       config           <- withOpenFile configFile ReadMode loadConfig
       putStrLn "Loading Iniciativa"
       order            <- withOpenFile orderFile ReadMode loadOrder
       return  (State (filter operative mechs) current player map config order)
    where
      ids = show id
      orderFile        = "iniciativaJ" ++ ids ++ ".sbt"
      configFile       = "configJ"     ++ ids ++ ".sbt" 
      mechsFile        = "mechsJ"      ++ ids ++ ".sbt"  
      mapFile          = "mapaJ"       ++ ids ++ ".sbt"
      defMechFile mech = "defmechJ"    ++ ids ++ ('-' : (show mech) ++ ".sbt")
      
      --
      -- Carga todos los ficheros defMech
      --
      {- Esto mejor lo hacemos al leer el mech.
      loadDefs :: Int -> Int -> IO [MechDef]
      loadDefs mech total =
          if (mech < total) 
             then
                 do x  <- withOpenFile (defMechFile mech) ReadMode loadMechDef
                    xs <- loadDefs (mech+1) total
                    return  (x:xs)
             else return  []
       -}

--
-- Guarda el fichero de acción recibiendo como parámetro la función
-- de guardado concreta.
--
storeAction :: Int -> (Handle -> IO ()) -> IO ()
storeAction id doStore = withOpenFile ("accionJ" ++ (show id) ++ ".sbt")
                                      WriteMode doStore

--
-- Guarda la informacion de un Slot
--
storeSlot :: Slot -> Handle -> IO ()
storeSlot (Slot loc slot) h =
    do storeStr (toSbtLocation loc) h
       storeS slot h

--
-- Guarda el fichero de acción de de la fase de movimiento
--
storeMovement :: MovementAction -> Handle -> IO ()
storeMovement x h =
    do storeStr (toSbtMovement (move x)) h
       if (move x /= None) 
          then do storeStr ((toSbtHex . posHex . dest) x) h
                  storeS ((fromEnum . posSide . dest) x + 1) h
                  if (move x /= Jump) 
                     then do storeS (useMasc x) h
                             storeS (length (steps x)) h
                             storeListF (steps x) storeStep h
                     else return  ()
          else return  ()
    where
      --
      -- Guarda un paso de la secuencia de movimiento
      --
      storeStep :: Step -> Handle -> IO ()
      storeStep x h =
          do storeStr (toSbtDirection (dir x)) h
             storeS (value x) h

--
-- Guarda el fichero de acción de la fase de reacción
--
storeReaction :: ReactionAction -> Handle -> IO ()
storeReaction (ReactionAction x) h = 
    storeStr (toSbtRotation x) h

--
-- Guarda el fichero de acción de la fase de armas
--
storeWeapons :: WeaponsAction -> Handle -> IO ()
storeWeapons x h =
    do storeS (takeClub x) h
       if (not (takeClub x))
          then do storeStr (toSbtHex (objective x)) h
                  storeS (length (shots x)) h
                  storeListF (shots x) storeShot h
          else return  ()
    where
      --
      -- Guarda un disparo de la lista de disparos
      -- 
      storeShot :: Shot -> Handle -> IO ()
      storeShot x h =
          do storeSlot (gun x) h
             storeS (double x) h
             if isJust (shotAmmo x)
               then storeSlot (fromJust $ shotAmmo x) h 
               else storeStr "-1" h >> storeStr "-1" h
             storeStr (toSbtHex (shotObjective x)) h
             storeStr (toSbtObjective (shotObjType x)) h

--
-- Guarda el fichero de acción de la fase física
--
storePhisical :: PhisicalAction -> Handle -> IO ()
storePhisical (PhisicalAction x) h =
    do storeS (length x) h
       storeListF x storeBlow h
    where
      --
      -- Guarda en el fichero de configuración un golpe de arma fisica
      --
      storeBlow :: Phisical -> Handle -> IO ()
      storeBlow x h =
          do storeHit (weapon x) h
             storeStr (toSbtHex (phisObjective x)) h
             storeStr (toSbtObjective (phisObjType x)) h
      
      storeHit :: Hit -> Handle -> IO ()
      storeHit (Punch loc) h = 
          do storeStr (toSbtLocation loc) h
             storeStr "1000" h
      storeHit (Kick loc) h = 
          do storeStr (toSbtLocation loc) h
             storeStr "2000" h
      storeHit (Blow _) h =
          do storeStr "BIBD" h
             storeStr "3000" h
      storeHit (Sword loc sl) h = storeSlot (Slot loc sl) h

--
-- Guarda el fichero de acción de la fase de final de turno
--
storeEnd :: EndAction -> Handle -> IO ()
storeEnd x h =
    do storeS (radiatorOff x) h
       storeS (radiatorOn x) h
       storeS (dropClub x) h
       storeS (length (dropAmmo x)) h
       storeListF (dropAmmo x) storeSlot h

--
-- Ejecuta una serie de instrucciones asegurándose de que el fichero
-- se cierra si hay problemas.
--
withOpenFile:: FilePath -> IOMode -> (Handle -> IO a) -> IO a
withOpenFile name mode = bracket (openFile name mode) hClose
