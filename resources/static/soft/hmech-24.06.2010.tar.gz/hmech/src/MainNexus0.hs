--
--  File:       MainNexus0.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Tue Mar 31 16:20:04 2009
--  Time-stamp: <2009-05-29 20:55:24 raskolnikov>
--
--  Main para el bot Nexus0 -bot estúpido
--

module MainNexus0 where

import Mech.Run
import Nexus.Nexus0

main = runWarrior warrior


