/**
 * @file   glmorph.h
 * @author Juan Pedro Bol�var Puente
 * @date   April 2007
 * 
 * Copyright (C) 2007 by Juan Pedro Bol�var Puente
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __GLMORPH_H__
#define __GLMORPH_H__

#include <SDL/SDL.h>
#include "SDL_2dgl.h"
#include "mesh.h"

/* Ready the app for GNU Gettext support */
#define _(str) (str)

const int DEF_TIME = 3000;
const int DEF_FPS  = 120;

struct MorphOptions {
	std::string pic1;
	std::string pic2;
	std::string mesh1;
	std::string mesh2;
	bool showmesh;
	int time;
	int fps;
};

bool playMorphing(const GL2D_SurfaceGL* pic1, const GL2D_SurfaceGL* pic2,
				  const Mesh2D& m1, const Mesh2D& m2, int fps, int time,
				  bool showmesh);

void changeExt(std::string &path, std::string ext);

bool parseArgs(MorphOptions &ops, int argc, char* argv[]);

/**
 * Shows the app help.
 * @param appname The program binary filename.
 */
void showHelp(const char* appname);

#endif /* __GLMORPH__ */
