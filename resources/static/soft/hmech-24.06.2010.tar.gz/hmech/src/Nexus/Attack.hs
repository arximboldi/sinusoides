--
--  File:       Attack.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Thu May 28 17:39:18 2009
--  Time-stamp: <2009-05-30 21:39:01 raskolnikov>
--
--  Datos relevantes de un ataque.
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Nexus.Attack where

import Mech.Info

data Attack a = Attack { action :: a
                       , attackModifier :: Int
                       , attacktedHeat :: Int
                       , attackDamage :: Int
                       , attackDest :: Int
                       , attackMech :: Mech
                       } deriving (Show)

nullAttack :: Attack a -> Attack ()
nullAttack (Attack _ x y z w m) = Attack () x y z w m
 