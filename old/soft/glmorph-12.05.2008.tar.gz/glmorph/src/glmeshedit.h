/**
 * @file   glmeshedit.h
 * @author Juan Pedro Bol�var Puente
 * @date   April 2007
 * 
 * Copyright (C) 2007 by Juan Pedro Bol�var Puente
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __GLMESHEDIT_H__
#define __GLMESHEDIT_H__

#include <SDL/SDL.h>
#include <string>
#include <list>

#include "mesh.h"

/* Ready the app for GNU Gettext support */
#define _(str) (str)

const int DEF_MESH_W = 10;
const int DEF_MESH_H = 10;
const int DEF_SCR_W  = 640;
const int DEF_SCR_H  = 480;

struct EdOptions {
	std::string picfile;
	std::string infile;
	std::string outfile;
	int meshw;
	int meshh;
	int scrw;
	int scrh;
};

void editMesh(Mesh2D& m, const GL2D_SurfaceGL* pic);

/**
 * @retval false Invalid arguments. We should print help and exit.
 * @retval true  Evrything as expected. C'mon baby.
 */ 
bool parseArgs(EdOptions &ops, int argc, char* argv[]);

/**
 * Shows the app help.
 * @param appname The program binary filename.
 */
void showHelp(const char* appname);

#endif /* __GLMESHEDIT_H__ */

