/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.gen;

import org.w3c.dom.*;
import java.lang.*;

public class Input extends ContentGenerator
{
    String m_type = null;
    String m_name = null;
    String m_value = null;
    String m_text = null;
    int m_size = -1;
    int m_maxsize = -1;
    boolean m_checked = false;

    public Input() { }
    
    public Input(String type) {
	m_type = type;
    }

    public Input(String type, String name) {
	m_type = type;
	m_name = name;
    }

    public Input(String type, String name, String value) {
	m_type = type;
	m_name = name;
	m_value = value;
    }

    public Input(String type, String name, String value, int size) {
	m_type = type;
	m_name = name;
	m_value = value;
	m_size = size;
    }
    
    public void setName(String name) {
	m_name = name;
    }

    public void setValue(String value) {
	m_value = value;
    }
    
    public void setText(String text) {
	m_text = text;
    }

    public void setSize(int size) {
	m_size = size;
    }

    public void setMaxSize(int maxsize) {
	m_maxsize = maxsize;
    }

    public void setChecked(boolean checked) {
	m_checked = true;
    }
    
    protected void fillInputAttributes(Element el)
    {
	if (m_type != null)
	    el.setAttribute("type", m_type);
	if (m_name != null)
	    el.setAttribute("name", m_name);
	if (m_value != null)
	    el.setAttribute("value", m_value);
	if (m_size >= 0)
	    el.setAttribute("size", (new Integer(m_size)).toString());
	if (m_maxsize >= 0)
	    el.setAttribute("maxsize", (new Integer(m_maxsize)).toString());
	if (m_checked)
	    el.setAttribute("checked", (new Boolean(m_checked)).toString());
	
	if (m_text != null)
	    el.appendChild(el.getOwnerDocument().createTextNode(m_text));
    }
    
    public Node generate(Document doc)
    {
	Element el = doc.createElement("input");

	fillInputAttributes(el);
	
	return generateContent(el);
    }
}
