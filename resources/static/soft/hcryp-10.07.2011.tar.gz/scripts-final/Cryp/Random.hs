--
--  File:       Random.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon May 16 19:27:04 2011
--  Time-stamp: <2011-07-09 17:23:52 raskolnikov>
--
--  Second script of the Cryptography course held in Universidad de
--  Granada in 2011.
--

{-# LANGUAGE TupleSections, FlexibleInstances, UndecidableInstances, 
    OverlappingInstances #-}

module Cryp.Random where

import Random
import Data.List
import Data.Bits
import Data.Char (intToDigit)
import Data.Maybe (fromJust)
import System.Environment (getArgs)
import Debug.Trace (trace, traceShow)

import qualified Data.ByteString.Lazy as B

------------------------------------------------------------------------
--  Utilities reused in several exercises
------------------------------------------------------------------------

debug x = traceShow x x 

same :: (Eq a) => [a] -> Bool
same [] = True
same (x:xs) = all (==x) xs

count :: (Eq a) => a -> [a] -> Int
count x = length . filter (==x)

randomsN :: (RandomGen g) => g -> [Int]
randomsN g = x : randomsN g'
  where (x, g') = next g

randomsG :: (RandomGen g) => g -> [g]
randomsG g = g' : randomsG g'
  where (x, g') = next g

split2 = unzip . go
  where go []         = []
        go (_:[])     = []
        go (x1:x2:xs) = (x1, x2) : go xs

updateBit bits i bool | bool      = setBit bits i
                      | otherwise = bits

-- | 
-- Find the generator orbit length, assuming that the given generator
-- is inside the orbit.
--
-- More information on this in "Elements of programmong", by Alexander
-- Stepanov
--
genOrbit1 :: (RandomGen a, Eq a) => a -> Int
genOrbit1 g = 1 + (length $ takeWhile (/= g) $ randomsG g)

-- |
--
-- Find the generator orbit, assuming that the given generator might
-- be outside the orbit. Returns the collision point and orbit size.
--
genOrbit2 :: (RandomGen a, Eq a) => a -> (Int, a)
genOrbit2 g = (genOrbit1 collision, collision)
  where
    slow      = g : randomsG g
    (_, fast) = split2 slow
    collision = fst $ fromJust $ find (uncurry (==)) $ zip slow fast

-- |
--
-- Find the generator orbit, assuming that the given generator might
-- be outside the orbit. Returns the orbit size, collision point and
-- connection point.
--
genOrbit3 :: (RandomGen a, Eq a) => a -> (Int, Int, a,  a)
genOrbit3 g = (len, hdl, collision, connection)
  where
    (len, collision) = genOrbit2 g
    afterCol   = randomsG collision
    afterInit  = g : randomsG g
    connection = fst $ fromJust $ find (uncurry (==)) $ zip afterCol afterInit
    hdl        = length $ takeWhile (/= connection) $ g : randomsG g

-- |
--
-- Class for all the random binary stream generators that we will
-- later implement
--
    
class BinRandomGen g where
  binNext :: g -> (Bool, g)

instance (BinRandomGen g) => RandomGen g where
  genRange g = (fromEnum False, fromEnum True)
  next g = let (n, g') = binNext g
           in (fromEnum n, g')
  split = undefined
  

------------------------------------------------------------------------
--  Exercise 1
------------------------------------------------------------------------

-- |
-- Golomb predicates tests. While this could be done more efficiently
-- merging several tests in one function, we test each predicate
-- separately such that one could use all this family of functions to
-- discover *how* a sequence fails to meet the Golomb predicates.
--

type GolombPred = [Bool] -> Bool
  
rle :: (Eq a) => [a] -> [(a, Int)]
rle = map (\x -> (head x, length x)) . group

correlate x y = count True $ zipWith (&&) x y

golomb1 :: GolombPred
golomb1 s = abs (count True s - count False s) <= 1  

golomb2 :: GolombPred
golomb2 = golomb2' 1 (-1) . rle 

golomb2' _ _ [] = True
golomb2' len last runs = ok && golomb2' (len+1) total rest
  where (this, rest) = partition ((==len).snd) runs
        ones = count (True, len) this
        zeros = count (False, len) this
        total = ones + zeros
        ok = -- abs (ones - zeros) <= 1 && -- This part is optional!  
             (last == -1 || 
              total == (last+1) `div` 2 ||
              total == last `div` 2)

golomb3 :: GolombPred
golomb3 s = same $ map (correlate s) shifts   
  where shifts = [ drop x $ cycle s | x <- [1..length s - 1] ]

golomb :: GolombPred
golomb s = golomb1 s && golomb2 s && golomb3 s

mainGolomb :: IO Int
mainGolomb = do
  args <- getArgs
  if length args /= 1
    then do putStrLn "Usage: golomb seq"
            return 1 
    else do let input = map (=='1') $ head args
                res = golomb input
            putStrLn ("Result:   " ++ show res)
            return 0

------------------------------------------------------------------------
--  Exercise 2
------------------------------------------------------------------------

-- | 
-- 
-- The LSFR keeps the state and connection polynomial of a Linear
-- Feedback Shift Register generator. It is an instance of RandomGen
-- and thus can be used as a normal Haskell random number
-- generator.
--

data LFSR = LFSR { lfsrConn  :: [Bool] 
                 , lfsrState :: [Bool]}
            deriving (Eq, Show)

instance BinRandomGen LFSR where
  binNext = lfsrNext

lfsrNext :: LFSR -> (Bool, LFSR)
lfsrNext (LFSR conn st) = (last st, LFSR conn nextst)
  where
    input = foldl' (/=) False $ zipWith (&&) st conn
    nextst = input : take (length st - 1) st

mkLfsr conn state 
  | length state /= length conn = error "State and conn sizes do not match"
  | otherwise                   = LFSR conn state


mainLfsr :: IO Int
mainLfsr = do
  args <- getArgs
  if length args /= 3
    then do putStrLn "Usage: lfsr conn state n"
            return 1 
    else do let conn = map (=='1')  (args !! 0)
                st   = map (=='1')  (args !! 1)
                n    = read (args !! 2) :: Int
                res  = take n $ randomsN $ mkLfsr conn st
                res' = map intToDigit res
            putStrLn ("Result:   " ++ res')
            return 0

mainLfsrOrbit :: IO Int
mainLfsrOrbit = do
  args <- getArgs
  if length args /= 2
    then do putStrLn "Usage: lfsr-orbit conn state"
            return 1 
    else do let st   = map (=='1')  (args !! 1)
                conn = map (=='1')  (args !! 0)
                (len, hdl, col, con)  = genOrbit3 $ mkLfsr conn st
            putStrLn ("Length:     " ++ show len)
            putStrLn ("Handle:     " ++ show hdl)
            putStrLn ("Collision:  " ++ map (intToDigit.fromEnum) (lfsrState col))
            putStrLn ("Connection: " ++ map (intToDigit.fromEnum) (lfsrState con))
            return 0



------------------------------------------------------------------------
--  Exercise 3
------------------------------------------------------------------------

-- | 
-- 
-- The PSFR keeps the state and polynomial function of a Polynomial
-- Feedback Shift Register generator as a sum of monomials. It is an
-- instance of RandomGen and thus can be used as a normal Haskell
-- random number generator.
--

data PFSR = PFSR { pfsrPoly  :: [[Bool]] 
                 , pfsrState :: [Bool]}
            deriving (Eq, Show)

instance BinRandomGen PFSR where
  binNext = pfsrNext

pfsrNext :: PFSR -> (Bool, PFSR)
pfsrNext (PFSR poly st) = (last st, PFSR poly nextst)
  where
    terms :: [Bool]
    evalmon c x = foldl' (&&) True $ zipWith (\c x->not c||x) c x
    terms = zipWith evalmon poly $ repeat st
    input = foldl' (/=) False $ terms
    nextst = input : take (length st - 1) st

mkPfsr poly state 
  | length state /= length poly         = error "Poly sizes do not match" 
  | any ((length state /=).length) poly = error "Monomial sizes do not match" 
  | otherwise                           = PFSR poly state


mainPfsr :: IO Int
mainPfsr = do
  args <- getArgs
  if length args /= 3
    then do putStrLn "Usage: pfsr poly state n"
            return 1 
    else do let st   = map (=='1')  (args !! 1)
                poly = map (map (==1)) $ read (args !! 0)
                n    = read (args !! 2) :: Int
                res  = take n $ randomsN $ mkPfsr poly st
                res' = map intToDigit res
            putStrLn ("Result:   " ++ res')
            return 0

mainPfsrOrbit :: IO Int
mainPfsrOrbit = do
  args <- getArgs
  if length args /= 2
    then do putStrLn "Usage: pfsr-orbit poly state"
            return 1 
    else do let st   = map (=='1') (args !! 1)
                poly = map (map (==1)) $ read (args !! 0)
                (len, hdl, col, con)  = genOrbit3 $ mkPfsr poly st
            putStrLn ("Length:     " ++ show len)
            putStrLn ("Handle:     " ++ show hdl)
            putStrLn ("Collision:  " ++ map (intToDigit.fromEnum) (pfsrState col))
            putStrLn ("Connection: " ++ map (intToDigit.fromEnum) (pfsrState con))
            return 0

------------------------------------------------------------------------
--  Exercise 4
------------------------------------------------------------------------

data Geffe = Geffe { geffeLfsr1 :: LFSR 
                   , geffeLfsr2 :: LFSR 
                   , geffeLfsr3 :: LFSR }
            deriving (Eq, Show)

instance BinRandomGen Geffe where
  binNext = geffeNext


geffeNext :: Geffe -> (Bool, Geffe)
geffeNext (Geffe l1 l2 l3) = (val, Geffe l1' l2' l3')
  where
    (x1, l1') = lfsrNext l1
    (x2, l2') = lfsrNext l2
    (x3, l3') = lfsrNext l3
    val = ((x1 && x2) /= (x2 && x3)) /= x3

mkGeffe :: LFSR -> LFSR -> LFSR -> Geffe
mkGeffe l1 l2 l3
  | len1 < maxlen1     = error "LFSR_1 is not maximum length"
  | len2 < maxlen2     = error "LFSR_2 is not maximum length"
  | len3 < maxlen3     = error "LFSR_3 is not maximum length"
  | gcd len1 len2 /= 1 = error "L1 and L2 are not coprimes"
  | gcd len2 len3 /= 1 = error "L2 and L3 are not coprimes"
  | gcd len1 len3 /= 1 = error "L1 and L3 are not coprimes"
  | otherwise          = Geffe l1 l2 l3
    where
      (len1, _) = genOrbit2 l1
      (len2, _) = genOrbit2 l2
      (len3, _) = genOrbit2 l3
      maxlen1 = 2 ^ length (lfsrState l1) - 1
      maxlen2 = 2 ^ length (lfsrState l2) - 1
      maxlen3 = 2 ^ length (lfsrState l3) - 1

mainGeffe :: IO Int
mainGeffe = do
  args <- getArgs
  if length args /= 7
    then do putStrLn "Usage: geffe l1_c l1_st l2_c l2_st l3_c l3_st n"
            return 1 
    else do let params = map (map (=='1')) (init args)
                n      = read (last args) :: Int
                c1:s1:c2:s2:c3:s3:_ = params
                res  = take n $ randomsN $ 
                       mkGeffe (mkLfsr c1 s1) (mkLfsr c2 s2) (mkLfsr c3 s3)
                res' = map intToDigit res
            putStrLn ("Result:   " ++ res')
            return 0

mainGeffeOrbit :: IO Int
mainGeffeOrbit = do
  args <- getArgs
  if length args /= 6
    then do putStrLn "Usage: geffe-orbit l1_c l1_st l2_c l2_st l3_c l3_st"
            return 1 
    else do let params = map (map (=='1')) args
                c1:s1:c2:s2:c3:s3:_ = params
                (len, hdl, col, con) = genOrbit3 $ 
                       mkGeffe (mkLfsr c1 s1) (mkLfsr c2 s2) (mkLfsr c3 s3)
            putStrLn ("Length:     " ++ show len)
            putStrLn ("Handle:     " ++ show hdl)
            putStrLn ("Collision:  " ++ show [ 
                         map (intToDigit.fromEnum) (lfsrState l) |
                         l <- [ geffeLfsr1 col, 
                                geffeLfsr2 col, 
                                geffeLfsr2 col]])
            putStrLn ("Connection: " ++ show [ 
                         map (intToDigit.fromEnum) (lfsrState l) |
                         l <- [ geffeLfsr1 con, 
                                geffeLfsr2 con, 
                                geffeLfsr2 con]])
            return 0

------------------------------------------------------------------------
--  Exercise 5
------------------------------------------------------------------------

-- |
-- Encodes a lazy ByteString using a BinRandomGen as key source
--
binEncode :: (BinRandomGen a) => a -> B.ByteString -> (a, B.ByteString)
binEncode g = B.mapAccumL encodeWord g
  where encodeWord g w = let (g', e) = encodeBool g $ bitsToBool w
                         in (g', boolToBits e)
        encodeBool g b = mapAccumL encodeOne g b
        encodeOne  g x = let (k, g') = binNext g
                         in (g', x /= k) 
        
bitsToBool :: (Bits a) => a -> [Bool]
bitsToBool x = [ testBit x i | i <- [0 .. bitSize x - 1]]

boolToBits :: (Bits a) => [Bool] -> a
boolToBits x = foldl' reduce 0 $ zip [0 .. length x - 1] x
  where reduce bits (i, bool) = updateBit bits i bool
        
mainGeffeEncode :: IO Int
mainGeffeEncode = do
  args <- getArgs
  if length args /= 6
    then do putStrLn "Usage: geffe-orbit l1_c l1_st l2_c l2_st l3_c l3_st"
            return 1 
    else do let params = map (map (=='1')) args
                c1:s1:c2:s2:c3:s3:_ = params
                gen = mkGeffe (mkLfsr c1 s1) (mkLfsr c2 s2) (mkLfsr c3 s3)
            B.interact (snd . binEncode gen) 
            return 0
