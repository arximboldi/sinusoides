/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

/**
 * Conjúnto de funciones utilitarias sobre SWT.
 * @author raskolnikov
 */
public class SwtUtils
{
	/**
	 * Cambia el color de fondo de un contenedor y todos sus hijos.
	 * @param wid El contenedor.
	 * @param col El color.
	 */
	static void setBackgroundRecursive (Composite wid, Color col)
	{
		wid.setBackground (col);
		
		Control[] childs = wid.getChildren();
		
		for (int i = 0; i < childs.length; ++i) {
			if (childs[i] instanceof Composite)
				setBackgroundRecursive ((Composite) childs[i], col);
			else
				childs[i].setBackground (col);
		}
	}
	
	/**
	 * Cambia el estado de activación de un contenedor y todos sus hijos.
	 * @param wid El contenedor.
	 * @param en El nuevo valor.
	 */
	static void setEnabledRecursive (Composite wid, boolean en)
	{
		wid.setEnabled (en);
		
		Control[] childs = wid.getChildren();
		
		for (int i = 0; i < childs.length; ++i) {
			if (childs[i] instanceof Composite)
				setEnabledRecursive ((Composite) childs[i], en);
			else
				childs[i].setEnabled (en);
		}
	}

	/**
	 * Muestra un diálogo de información con un mensaje.
	 * @param parent La ventana padre.
	 * @param err El mensaje de error.
	 */
	static void infoMessage (Shell parent, String err)
	{
		MessageBox msg = new MessageBox (parent, SWT.ICON_ERROR);
		msg.setMessage (err);
		msg.open ();
	}
	
	/**
	 * Muestra un diálogo de error con un mensaje.
	 * @param parent La ventana padre.
	 * @param err El mensaje de error.
	 */
	static void errorMessage (Shell parent, String err)
	{
		MessageBox msg = new MessageBox (parent, SWT.ICON_ERROR);
		msg.setMessage (err);
		msg.open ();
	}
}
