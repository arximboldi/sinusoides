%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       noise_uniform_additive.m
%  Time-stamp: <2011-01-23 21:52:52 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Añade ruido uniforme a una imagen.
%

function img = noise_uniform_additive (img, a, b)
    img = bound_gray (double (img) + randn (size (img)) * (a - b) + a);
end
        
