/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

/**
 * Una baraja de poker que construye pilas de cartas según la baraja de poker.
 * La baraja está implementada como un objeto Singleton. El rango de las cartas
 * oscilará entre 1 y 13, ambos incluidos. El palo de la carta está definido en
 * la clase Suit.
 * 
 * @author raskolnikov
 */
public class PokerDeck 
{
	/**
	 * Tipo enumerado del palo de la baraja.
	 * @author raskolnikov
	 */
	enum Suit
	{
		HEARTS,   /**< Corazones. */
		DIAMONDS, /**< Diamantes. */
		SPADES,   /**< Picas. */
		CLUBS     /**< Tréboles. */
	}
	
	/** Rango máximo de una carta. */
	public static int MAX_RANK = 13;
	/** Numero de elementos de la clase enumerada Suit. */
	public static int MAX_SUIT = 4;
	
	/**
	 * Crea una pila de cartas.
	 * @return La pila de cartas construida.
	 */
	public CardPile create ()
	{
		CardPile ret = null;
		
		try {
			ret = m_prot.clone ();
		} catch (Exception e) { }
		
		return ret;
	}
	
	/**
	 * Devuelve la instancia única de la factoría.
	 * @return La instancia única de la factoría.
	 */
	public static PokerDeck getInstance ()
	{
		if (s_the_instance == null)
			s_the_instance = new PokerDeck (); 
		return s_the_instance;
	}
	
	/**
	 * Constructor privado. Construye un prototipo de baraja.
	 */
	private PokerDeck ()
	{
		for (int i = 1; i <= MAX_RANK; ++i) {
			m_prot.addBottom (new Card (i, Suit.HEARTS));
			m_prot.addBottom (new Card (i, Suit.DIAMONDS));
			m_prot.addBottom (new Card (i, Suit.SPADES));
			m_prot.addBottom (new Card (i, Suit.CLUBS));
		}
	}
	
	/** Referencia a la unica instancia de la clase. */
	private static PokerDeck s_the_instance = null;
	
	/** Prototipo de baraja. */
	private CardPile m_prot = new CardPile ();
}
