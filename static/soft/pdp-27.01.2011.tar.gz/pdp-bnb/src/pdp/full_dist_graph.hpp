/**
 *  Time-stamp:  <2010-11-25 19:16:49 raskolnikov>
 *
 *  @file        full_dist_graph.hpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Sat Nov 20 23:59:18 2010
 *
 *  Distribuye el grafo entre todos los procesos.
 */

#ifndef PDP_FULL_DIST_GRAPH_H_
#define PDP_FULL_DIST_GRAPH_H_

#include "graph.hpp"

namespace pdp
{

/**
 * Distribuye el grafo entre todos los procesos. No reconstruye ningún
 * grafo al final.
 */
template <typename Label>
class full_dist_graph : public detail::graph_base<Label>
{
public:
    /**
     * Constructor que no adquiere ningún grafo.
     */
    full_dist_graph ()
    {
	_data = 0;
	_size = 0;
    }

    /**
     * Constructor que adquiere y distribuye un grafo.
     */
    full_dist_graph (MPI::Comm& comm, graph<Label>& g, int root)
    {
	_data = 0;
	_size = 0;
	scatter (comm, g, root);
    }
    
    void scatter (MPI::Comm& comm, graph<Label>& g, int root);
    
    void bcast_col (size_t k) {}
    void bcast_row (size_t k) {}
    size_t local_row_begin () const { return 0; }
    size_t local_row_end () const { return _size; }
    size_t local_col_begin () const { return 0; }
    size_t local_col_end () const { return _size; }
    
private:
    using detail::graph_base<Label>::_data;
    using detail::graph_base<Label>::_size;
};

namespace detail
{

template <typename Label>
void bcast_graph_size (MPI::Comm& comm, graph<Label>& g, int root)
{
    int new_size = g.size ();
    comm.Bcast (&new_size, 1, MPI::INT, root);
    if (new_size != (int) g.size ())
	g.recreate (new_size);
}

} /* namespace detail */

template <typename Label>
void full_dist_graph<Label>::scatter (MPI::Comm& comm, graph<Label>& g, int root)
{
    // Distribuimos el tamaño
    detail::bcast_graph_size (comm, g, root);
    
    // Distribuimos el grafo en si.
    _data         = g.raw ();
    _size         = g.size ();
    comm.Bcast (*_data, _size * _size, label_traits<Label>::mpi_type (), root);
}

} /* namespace pdp */

#endif /* PDP_FULL_DIST_GRAPH_H_ */
