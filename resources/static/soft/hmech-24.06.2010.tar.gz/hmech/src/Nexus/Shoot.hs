--
--  File:       Shoot.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon May  4 16:52:04 2009
--  Time-stamp: <2009-05-31 17:27:42 raskolnikov>
--
--  Funciones para los disparos del bot.
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Nexus.Shoot where

import Maybe
import Data.Array

import Mech.Action
import Mech.Info
import Mech.Util

import Nexus.LOS
import Nexus.State
import Nexus.Debug
import Nexus.Attack

--
-- El angulo de disparo
--
data Angle = Front | LeftLateral | RightLateral | Rear 
             deriving (Show, Eq, Ord, Enum)

bcomp :: (a -> a -> b) -> (c -> a) -> c -> c -> b
bcomp f g x y = f (g x) (g y)

shootMech :: Map -> Mech -> Movement -> Mech -> [ Attack Shot ]
shootMech m src move target 
    | los == Blocked = []
    | otherwise      = map shot $ filter ((<=12).modifier) $ filter checkDistance $ filter checkAngle (weapons src)
    where
      (los, losPath) = lineOfSight m (position src) (level src)
                       (position target) (level target)

      -- Condiciones para poder dispoarar un arma
      checkDistance   = (>=0) . distanceMod (length losPath)
      checkAngle comp | location comp == ArmourRightLeg ||
                        location comp == ArmourLeftLeg     = angle == Front || angle == Rear
                      | otherwise                          = canShootAngle trunkAngle comp

      -- Angulos de disparo 
      angle       = shootAngle (position src) (side src) (position target)
      trunkAngle  = shootAngle (position src) (trunkSide src) (position target)
      targetAngle = shootAngle (position target) (side target) (position src)
 
      -- Offset de nivel de un mech 
      level mech | onFloor mech = 0
                 | otherwise = 1

      weapons = weaponList . components . defmech -- Todas las armas
      ammos = ammoList (components (defmech src)) -- Todas las municiones

      -- El modificador de disparar con un arma
      modifier comp = opponentMod (position src) target +
                      losMod los +
                      movementMod move +
                      distanceMod (length losPath) comp +
                      shotMod comp +
                      4

      -- Buscamos el slot de munición óptimo para gastar primero aquella munición
      -- de los slots más dañados.
      bestAmmoSlot weapon =
          head $ best (bcomp (>) ((internalPoints src !) . loc)) $
          concatMap (findComponentList (defmech src)) $
          best (bcomp (<) shotMod) (ammos weapon)
      
      -- Buscamos el slot de un arma
      weaponSlot = fromJust . findComponent (defmech src)
      
      -- Componemos el resultado
      shot comp = Attack (shot' comp) (modifier comp) (heatGen comp) (damage comp) (anglePoints target targetAngle) target
      shot' comp = Shot (weaponSlot comp)
                   False 
                   (if weptype comp == Energy then Nothing else Just (bestAmmoSlot comp))
                   (position target)
                   MechObj

anglePoints :: Mech -> Angle -> Int
anglePoints m Front 
    = p ArmourHead + 
      2 * p ArmourTrunk + p ArmourLeftTrunk + p ArmourRightTrunk +
      2 * p ArmourRightArm + 2 * p ArmourLeftArm +
      p ArmourRightLeg + p ArmourLeftLeg
    where p = (armourPoints m !)
anglePoints m LeftLateral
    = p ArmourHead + 
      p ArmourTrunk + 2 * p ArmourLeftTrunk + p ArmourRightTrunk +
      p ArmourRightArm + 2 * p ArmourLeftArm +
      p ArmourRightLeg + 2 * p ArmourLeftLeg
    where p = (armourPoints m !)
anglePoints m RightLateral 
    = p ArmourHead + 
      p ArmourTrunk + 2 * p ArmourLeftTrunk + p ArmourRightTrunk +
      2 * p ArmourRightArm + p ArmourLeftArm +
      2 * p ArmourRightLeg + p ArmourLeftLeg
    where p = (armourPoints m !)
anglePoints m Rear 
    = p ArmourHead + 
      2 * p ArmourBackTrunk + p ArmourLeftBackTrunk + p ArmourRightBackTrunk +
      2 * p ArmourRightArm + 2 * p ArmourLeftArm +
      p ArmourRightLeg + p ArmourLeftLeg
    where p = (armourPoints m !)

ammoList :: [Component] -> Component -> [Component]
ammoList xs weapon = filter (ammoOf weapon) xs
    where ammoOf wep ammo = item ammo == AmmoItem &&
                            weaponCode ammo == code wep &&
                            amount ammo > 0

weaponList :: [Component] -> [Component]
weaponList xs = filter condition xs
    where 
      condition comp = WeaponItem == item comp &&
                       compOperative comp &&
                       (weptype comp == Energy || hasAmmo comp)
      hasAmmo = not . null . ammoList xs

canShootAngle :: Angle -> Component -> Bool
canShootAngle angle comp
    | angle == Front &&
      isFrontArmourLocation loc       = True
    | angle == LeftLateral &&
      loc == ArmourLeftArm            = True
    | angle == RightLateral &&
      loc == ArmourRightArm           = True
    | angle == Rear &&
      ((not.isFrontArmourLocation) loc ||
      loc == ArmourHead)              = True
    | otherwise                       = False
    where
      loc = location comp

opponentMod :: Hex  -- Posicion nuestra
            -> Mech -- Oponente
            -> Int
opponentMod src target =
    onFloorMod + swampMod
    where
      onFloorMod | onFloor target = if touches src (position target)
                                    then -2 else 1
                 | otherwise = 0
      swampMod | blockedInSwamp target = -2
               | otherwise  = 0

movementMod :: Movement -> Int
movementMod None  = 0
movementMod Walk  = 1
movementMod Run   = 2
movementMod Jump  = 3
movementMod Floor = 2

distanceMod :: Int -> Component -> Int
distanceMod dist comp
    | dist > longDistance comp   = -1
    | dist > mediumDistance comp = 4
    | dist > shortDistance comp  = 2
    | dist > minDistance comp    = 0
    | otherwise                  = (1 + minDistance comp - dist)

--
-- Dado un hexagono y un encaramiento y un objeto nos dice
-- en que región de disparo está.
--
shootAngle :: Hex -> Side -> Hex -> Angle
shootAngle src side target 
    | right (rotate side (-1))  && left (rotate side 1) = Front
    | left (rotate side 2) = RightLateral
    | right (rotate side (-2)) = LeftLateral
    | otherwise = Rear
    where
      left x  = leftOf src x target
      right x = rightOf src x target

--
-- Comprueba si el objetivo está a la derecha de la linea definida por
-- un punto/lado.
--
rightOf :: Hex  -- Fuente 
        -> Side -- Encaramiento fuente
        -> Hex  -- Objetivo
        -> Bool
rightOf  (Hex sx sy) side (Hex dx dy) =
    case side of
      North      -> sx <= dx
      NorthEast  -> (dx + dy*2 + mod (dx+1) 2) >= (sx + sy*2 + mod (sx+1) 2)
      SouthEast  -> sx >= dx - (dy - sy)*2
      South      -> sx >= dx
      SouthWest  -> (dx + dy*2 + mod (dx+1) 2) <= (sx + sy*2 + mod (sx+1) 2)
      NorthWest  -> sx <= dx - (dy - sy)*2

--
-- Comprueba si el objetivo está a la izquierda de la linea definida por
-- un punto/lado.
--
-- rightOf src (rotate 3 side) dest
leftOf :: Hex  -- Fuente 
        -> Side -- Encaramiento fuente
        -> Hex  -- Objetivo
        -> Bool
leftOf (Hex sx sy) side (Hex dx dy) =
    case side of
      North      -> sx >= dx
      NorthEast  -> (dx + dy*2 + mod (dx+1) 2) <= (sx + sy*2 + mod (sx+1) 2)
      SouthEast  -> sx <= dx - (dy - sy)*2
      South      -> sx <= dx
      SouthWest  -> (dx + dy*2 + mod (dx+1) 2) >= (sx + sy*2 + mod (sx+1) 2)
      NorthWest  -> sx >= dx - (dy - sy)*2
