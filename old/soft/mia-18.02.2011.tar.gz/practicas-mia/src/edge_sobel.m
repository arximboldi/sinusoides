%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       edge_sobel.m
%  Time-stamp: <2011-01-27 03:14:55 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Detector de fronteras Sobel.
%

function [img, gradmag, imgx, imgy, imgnorm] = edge_sobel (img, threshold, dir)
    img = double(img);

    % Hacemos la correlacion con la mask para obtener el filtrado en la
    % dir X e Y.
    mask = [-1 -2 -1; 0 0 0; 1 2 1];
    imgx = imfilter (img, mask, 'conv', 'replicate');
    imgy = imfilter (img, mask', 'conv', 'replicate');

    switch dir
      case 'both' %Ambos
        grad = sqrt (imgx.*imgx + imgy.*imgy);        
      case 'vertical' %Horizontal       
        grad = sqrt (imgy.*imgy);
      case 'horizontal' %Vertical
        grad = sqrt (imgx.*imgx);
    end
    gradmag = grad;
    
    % Seleccionamos solo los pixeles que superan el threshold (si se ha
    % introducido si no devolveremos la img sin thresholdizar)
    if ~isnan (threshold)
        grad = grad > threshold * 256;
    end
    imgnorm = grad;
    img = grad .* 255;

