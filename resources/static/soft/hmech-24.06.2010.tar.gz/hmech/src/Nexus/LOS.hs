--
--  File:       LOS.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Sun Apr 12 18:14:41 2009
--  Time-stamp: <2009-05-31 12:15:52 raskolnikov>
--
--  Implementación de la linea de visión. El algoritmo está inspirado,
--  aunque con modificaciones, del encotnrado aquí:
--      http://www.sable.mcgill.ca/~clump/hexes.txt
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Nexus.LOS where

import Mech.Info
import Nexus.Debug
import Data.Array

--
-- Representa el resultado de calcular la linea de vision
--
data LOS = Visible {losMod :: Int} -- El entero es el modificador de disparo por terreno
         | Partial {losMod :: Int} -- El entero es el modificador de disparo por terreno 
                       -- más cobertura parcial.
         | Blocked 
           deriving (Eq, Ord, Show)

data LOSAccum = LOSAccum 
    { los      :: LOS    -- El modificador se computa a parte
    , modifier :: Int
    , path     :: [Hex]
    , lwcount  :: Int
    , hwcount  :: Int
    , count    :: Int
    }

--
-- Computa la linea de visión con el objetivo
--
lineOfSight :: Map ->  -- Mapa sobre el que calcularla 
               Hex ->  -- Hexagono origen 
               Int ->  -- Cambio de altitud en el origen 
               Hex ->  -- Hexagono destino 
               Int ->  -- Cambio de altitud en el destino 
               (LOS, [Hex]) -- [Hex está reverso]
lineOfSight map src srcl dst dstl = 
    (losWater $ losCalc $ accumResult, path accumResult) 
    where
      -- Resultado de iterar por la linea de vision
      accumResult = hexLosFold losVisit losChoose losStart src dst

      srcLevel = level (map!src) + srcl -- Nivel real del destino
      dstLevel = level (map!dst) + dstl -- Nivel real de la fuente

      -- Linea de vision bloqueada por agua
      losWater r | count accumResult == 0 && 
                   (srcLevel < -1) /= (dstLevel < -1) = Blocked
                 | count accumResult /= 0 &&
                   (srcLevel < -1 || dstLevel < -1) = Blocked
                 | otherwise = r
      
      -- Linea de vision inicial
      losStart = LOSAccum (Visible 0) 0 [] 0 0 0

      -- Modificador al disparar porque la linea de vision pase por aqui 
      cellMod cell = case object cell of
                       LightWood -> 2
                       HeavyWood -> 3
                       _         -> 0
      
      --
      -- Visita cada nodo de la linea de vision
      --
      losVisit hex ac@(LOSAccum los mod path lwcount hwcount count)
          | los == Blocked = ac
          | hex == dst     = ac { modifier = (modifier ac) + cellMod (map!hex) }
          | otherwise      = LOSAccum newLos newMod newPath newLwcount newHwcount (count+1)
          where
            -- Actualizamos el modificador para disparar
            newMod = mod + cellMod (map!hex)

            -- Actualizamos la ruta
            newPath = hex : path

            -- Actualizamos los contadores de árboles
            (newLwcount, newHwcount) 
                | isIntervening (level (map!hex) + 2) =
                    (if object (map!hex) == LightWood then lwcount + 1 else lwcount,
                     if object (map!hex) == HeavyWood || smoke (map!hex) then hwcount + 1 else hwcount)
                | otherwise = (lwcount, hwcount)
                     
            -- Nuevo valor de linea de visión
            newLos | isIntervening $ level (map!hex)         = Blocked
                   | isWood (object (map!hex))           &&
                     isIntervening (level (map!hex) + 2) &&
                     newLwcount + newHwcount * 2 > 3         = Blocked
                   | otherwise                               = los
            
            -- Comprueba si una elevacion efectiva del terreno dada
            -- sería considerada interviniente
            isIntervening :: Int -> Bool
            isIntervening lvl = (lvl > srcLevel && lvl > dstLevel) ||
                                (lvl > srcLevel && touches hex src) ||
                                (lvl > dstLevel && touches hex dst)

      --
      -- Elige el peor de dos hexagonos
      --
      losChoose hex1 hex2 ac = worse (losVisit hex1 ac) (losVisit hex2 ac)
          where
            worse ac1 ac2 | not $ hexInMap map hex1     = hex2
                          | not $ hexInMap map hex2     = hex1
                          | los ac1 == Blocked          = hex1
                          | los ac2 == Blocked          = hex2
                          | modifier ac1 < modifier ac2 = hex1
                          | modifier ac2 > modifier ac1 = hex2
                          | hwcount ac1 > hwcount ac2   = hex1
                          | otherwise                   = hex2

      --
      -- Calcula la linea de vision definitiva a partir de los datos obtenidos
      -- del acumulador
      --
      losCalc ac | los ac == Blocked
                     = Blocked
                 | count ac > 0 &&
                   dstLevel >= srcLevel && 
                   level (map ! (head.path) ac) == dstLevel 
                     = Partial (modifier ac + 3 + waterMod)
                 | dstl > 0 && dstLevel <= 0   
                     = Partial (modifier ac + 3 + waterMod)
                 | otherwise
                     = Visible (modifier ac + waterMod)
      
      -- Modificador para impactar por estar en el agua
      waterMod = let srcmod | level (map!src) < 0 = 1
                            | otherwise = 0
                     dstmod | level (map!dst) < 0 = -1
                            | otherwise = 0
                 in srcmod + dstmod

--
-- Representa un hexágono en el espacio "hexagonal" descrito en el artículo.
-- Este espacio toma como ejes dos lineas cualesquiera de las que cruzan
-- el hexágono, nosotros hemos tomado:
--      X -> De SW a NE
--      Y -> De NW a SE 
--
data HexA = HexA 
    { hexaX :: Int
    , hexaY :: Int 
    } deriving (Ord, Eq, Show)

--
-- Convierte un hexágono en coordenadas HexA a cordenadas Hex
--
a2hex :: HexA -> Hex
a2hex (HexA x y) = Hex (y + x) (y - fdiv (x+y) 2)

--
-- Convierte un hexágono en coordenadas Hex a coordenadas HexA
--
hex2a :: Hex -> HexA
hex2a (Hex x y) = HexA (cdiv x 2 - y) (fdiv x 2 + y)

--
-- Division redondeando por abajo
--
fdiv :: (Integral a) => a -> a -> a
fdiv = div

--
-- División redondeando por arriba
--
cdiv :: (Integral a) => a -> a -> a
cdiv x y = q + rest
    where (q, r) = divMod x y
          rest | r == 0    = 0
               | otherwise = 1

--
-- Combina los hexágonos utilizando una función con acumulador dada y otra
-- función que decide que hexágono visitar en caso de ambiguedad y que
-- puede ver el valor del acumulador.
--
hexLosFold :: (Hex -> a -> a)           -- Función a aplicar a cada hexágono
           -> (Hex -> Hex -> a -> Hex)  -- Función de decisión del peor
           -> a                         -- Valor inicial
           -> Hex                       -- Inicio
           -> Hex                       -- Fin
           -> a
hexLosFold f choose accum src dst =
    case hexSpecialLineFold f choose accum src dst of
      Just res -> res
      Nothing  -> hexLineFold f accum src dst

--
-- Computa la linea de visión de casos especiales en los que hay que elegir 
-- entre casos ambiguos
--
hexSpecialLineFold :: (Hex -> a -> a)           -- Función a aplicar a cada hexágono
                   -> (Hex -> Hex -> a -> Hex)  -- Función de decisión del hex
                   -> a                         -- Valor inicial
                   -> Hex                       -- Inicio
                   -> Hex                       -- Fin
                   -> Maybe a
hexSpecialLineFold f choose accum src dst =
    if isSpecial
    then Just $ hexSpecialLineFold' f choose accum line
    else Nothing

    where
      (reverse', src'@(Hex sx sy), dst'@(Hex dx dy)) 
          | hexX src > hexX dst = (reverse, dst, src)
          | otherwise           = (id,      src, dst)

      (isSpecial, specialF, steps) 
          | isSpecialHoriz src' dst' = (True, specialHoriz, fdiv (dx - sx) 2)
          | isSpecialDiag1 src' dst' = (True, specialDiag1, dx - sx)
          | isSpecialDiag2 src' dst' = (True, specialDiag2, dx - sx)
          --
          | otherwise                = (False, specialDiag1, 0)

      line = tail $ reverse' $ init $ init $ concatMap (specialF src') [0 .. steps]

--
-- Realiza el fold real sobre el recorrido construido descartando
-- los nodos que no se eligen.
--
hexSpecialLineFold' f choose accum [] = accum
hexSpecialLineFold' f choose accum (x:[]) = f x accum
hexSpecialLineFold' f choose accum (x:c1:c2:xs) =
    let ac = f x accum
    in hexSpecialLineFold' f choose (f (choose c1 c2 ac) ac) xs

isSpecialDiag1 src@(Hex sx sy) (Hex dx dy)  = dy == (hexY $ head $ specialDiag1 src (dx - sx))
isSpecialDiag2 src@(Hex sx sy) (Hex dx dy)  = dy == (hexY $ head $ specialDiag2 src (dx - sx))
isSpecialHoriz (Hex sx sy) (Hex dx dy)      = sy == dy && even (dx - sx)

specialDiag1 :: Hex -> Int -> [Hex]
specialDiag1 (Hex x y) i =
    let (sx, sy) | i == 0    = (x, y) 
                 | otherwise = (x + i, y + 3 * (fdiv i 2) + mod i 2 * if odd x then 1 else 2)
    in  Hex sx sy : Hex sx (sy+1) : Hex (sx+1) (sy + mod (sx+1) 2) : []

specialDiag2 :: Hex -> Int -> [Hex]
specialDiag2 (Hex x y) i =
    let (sx, sy) | i == 0    = (x, y) 
                 | otherwise = (x + i, y - 3 * (fdiv i 2) - mod i 2 * if even x then 1 else 2)
    in  Hex sx sy : Hex sx (sy-1) : Hex (sx+1) (sy - mod sx 2) : []

specialHoriz :: Hex -> Int -> [Hex]
specialHoriz (Hex x y) i = 
    let (sx, sy) = (x + 2 * i, y)
    in  Hex sx sy : Hex (sx+1) sy : Hex (sx+1) (sy + if odd sx then (-1) else 1) : []

--
-- Calcula la linea que une dos hexágonos ejecutando una función
-- con acumulador en cada visita. Se visitan los hexágonos en
-- la dirección en la que se introducen las coordenadas.
---
-- El algoritmo utilizad es una modificación del algoritmo de
-- Bresenham.
--
hexLineFold :: (Hex -> a -> a)   -- Función a aplicar en cada hexágono
            -> a                 -- Valor inicial 
            -> Hex               -- Inicio
            -> Hex               -- Fin
            -> a
hexLineFold func accum src dest = 
    hexLineFold' factor func accum src' dest'
    where
      -- El algoritmo es simetrico
      doSwap   (HexA x y) = HexA y x
      dontSwap hex        = hex
      swap | abs (hexaX (hex2a src) - hexaX (hex2a dest)) >=
             abs (hexaY (hex2a src) - hexaY (hex2a dest)) = dontSwap
           | otherwise                                    = doSwap
 
      -- Algunos valores iniciales
      src'  @ (HexA x0 y0) = swap $ hex2a src
      dest' @ (HexA x1 y1) = swap $ hex2a dest
      dx = x1 - x0
      dy = y1 - y0
      sig = signum dx == signum dy
      ddx = fromIntegral $ abs $ if even dx then dx * 2 else dx
      ddy = fromIntegral $ abs $ if even dx then dy * 2 else dy
      factor = ddx / 2 :: Double

      -- La función con acumulador
      hexLineFold' :: Double -> (Hex -> a -> a) -> a -> HexA -> HexA -> a
      hexLineFold' factor func accum curr dest  
          | curr == dest = accum
          | otherwise    = hexLineFold' factor' func accum' curr' dest
          where
            -- El nuevo factor
            factorN  = factor + ddy
            diagMove = factorN >= ddx 
            factor' | diagMove  = factorN - ddx
                    | otherwise = factorN
            
            -- El siguiente hexágono
            currV = HexA (hexaX curr + signum dx) (hexaY curr + signum dy)
            currH = HexA (hexaX curr + signum dx) (hexaY curr)
            curr'   | diagMove  = currV
                    | otherwise = currH

            -- El nuevo valor del acumulador
            accum' = process curr' (if diagMove && sig 
                                    then process currH accum
                                    else accum)
            process = func . a2hex . swap 

test src dest = 
    do
      putStrLn ""
      putStrLn $ "Src:  " ++ (show (hex2a src))
      putStrLn $ "Dest: " ++ (show (hex2a dest))
      putStrLn "Res1: "
      print $ reverse $ hexLosFold (:) (\x _ _ -> x) [] src dest
      putStrLn "Res2: "
      print $ reverse $ hexLosFold (:) (\_ x _ -> x) [] src dest
