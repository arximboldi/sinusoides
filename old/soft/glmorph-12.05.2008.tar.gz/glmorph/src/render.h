/**
 * @file   render.h
 * @author Juan Pedro Bol�var Puente
 * @date   April 2007
 * 
 * Copyright (C) 2007 by Juan Pedro Bol�var Puente
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __RENDER_H__
#define __RENDER_H__

#include "mesh.h"
#include "SDL_2dgl.h"

enum {
	RED = 0,
	GREEN,
	BLUE,
};

const Uint8 MESH_RED   = 0;
const Uint8 MESH_GREEN = 255;
const Uint8 MESH_BLUE  = 0;

const int POINT_SIZE = 6;

GL2D_SurfaceGL* loadPicture(const char* path);

void drawWarpedPic(const GL2D_SurfaceGL* pic, const Mesh2D &ms, const Mesh2D &m2, Uint8 alpha);

void GL2D_DrawPoint(int x, int y, int size, Uint8 r, Uint8 g, Uint8 b, Uint8 a);

bool initSDL();

void drawMesh2D(const Mesh2D& m);

#endif /* __RENDER_H__ */

