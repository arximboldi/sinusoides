%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       edge_result.m
%  Time-stamp: <2011-01-29 06:15:11 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Resultado de detectar fronteras.
%

classdef edge_result < image_result_base
    properties
        edges; g1; g2; mag; img; dir; mode; color
    end
    
    methods
        function self = edge_result (edges, g1, g2, mag, dir, img, mode)
            self.edges = edges;
            self.g1  = g1;
            self.g2  = g2;
            self.mag = mag;
            self.img = img;
            self.dir = dir;
            self.mode = mode;
            self.color = [255 0 0];
        end
        
        function type = result_type (self)
            type = 'edge';
        end
        
        function display (self, color_mode, color)
            self.color = color;
            display @ image_result_base (self, color_mode, color);
        end
        
        function img = get_data (self)
            switch self.mode
              case 1
                img = self.edges;
              case 2
                img = self.g1;
              case 3
                img = self.g2;
              case 4
                img = self.mag;
              case 5
                img = add_feature (self.img, self.edges, self.color);
              case 6
                img = self.dir;
            end
        end
    end
end
