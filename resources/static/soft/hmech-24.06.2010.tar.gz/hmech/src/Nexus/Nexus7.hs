{-# LANGUAGE TypeSynonymInstances, PatternGuards #-}

--
--  File:       Nexus7.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon Mar 16 21:04:44 2009
--  Time-stamp: <2009-06-24 00:48:02 raskolnikov>
--
--  Bot para el juego del Battletech.
--  Este bot pertenece a la familia Nexus, se llama Nexus7 por ser
--  el más avanzado de la familia ;) Vean Blade Runner.
--

--
--  Copyright (C) 2009 Juan Pedro Bolívar Puente
--  
--  This program is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program.  If not, see <http://www.gnu.org/licenses/>.
--

module Nexus.Nexus7 where

import Maybe
import List
import Data.Array

import qualified Mech.Warrior as W
import qualified Mech.Action  as A
import Mech.Info

import Mech.Util

import Nexus.Path
import Nexus.State
import Nexus.Shoot
import Nexus.Phisical
import Nexus.Debug
import Nexus.GoodMap
import Nexus.Attack
import Nexus.LOS

type Nexus7 = NexusState

instance W.Warrior Nexus7 where
    playMovement  w s = playMovement w s
    playReaction  w s = playReaction w s
    playWeapons   w s = playWeapons  w s
    playPhisical  w s = playPhisical w s
    playEnd       w s = playEnd      w s
    warName       w   = "nexus7"

--
-- Devuelve la función de bonanza a usar en este momento
--
getGoodFunc :: Nexus7 -> GoodFunc
getGoodFunc w = yingYangGoodFunc w (lastMovement w)

hexSquare :: Hex -> Hex -> [Hex]
hexSquare (Hex minx miny) (Hex maxx maxy) = 
    [ Hex x y | x <- [minx .. maxx], y <- [miny .. maxy]]

posSquare :: Hex -> Hex -> [Position]
posSquare min max = [ Pos p s | p <- hexSquare min max, s <- [North .. NorthWest] ]

--
-- Juega la fase de movimientos
--
playMovement w s | (heat . current) s > 12 = (A.defaultMovement, w)
                 | otherwise = playMovement' w s

playMovement' w s = (A.MovementAction movetype dstpos False steps,
                    w { lastMovement = movetype })
    where
      targetMech   = nearestMech s
      targetHex    = position targetMech

      tlvl = if (onFloor targetMech) then 0 else 1
      slvl = 1
      losfrom x = lineOfSight (smap s) targetHex tlvl (posHex x) slvl
      losfunc = (\(x,_)->(x,losfrom x))

      -- stand up?
      mustStandUp  = onFloor $ current s
      wp = (walkPoints . player) s
      rp = (runPoints . player) s
      ns = if mustStandUp 
           then s { player = (player s) { walkPoints = wp - 2, runPoints = rp - 2, jumpPoints = 0 }}
           else s
      
      -- Route
      (movetype, dstpos, st) = bestRoute ns goodmap targets
      steps = if mustStandUp 
              then 
                  if wp >= 2 
                  then (A.Step Up (1 + (fromEnum.side.current) s)) : st 
                  else (A.Step LeftDir 1) : st
              else st
      
      -- Route
      targets = map fst $ debug  analized

      analizeMin = Hex (hexX targetHex - 10) (hexY targetHex - 10)
      analizeMax = Hex (hexX targetHex + 10) (hexY targetHex + 10)
      
      analized = sortBy (\x y -> compare (snd x) (snd y))
                 [ (pos, goodmap ! pos) | 
                   pos <- posSquare analizeMin analizeMax, 
                   inRange (bounds goodmap) pos ]

      -- We are last
      weAreLast = debug $ (last.order) s == (playerNum.current) s
      newW = if weAreLast then w else w { killNeed = killNeed w ** 4 }
      goodmap = mkGoodMap s (getGoodFunc newW)

bestRoute :: State -> GoodMap -> [Position] -> (A.Movement, Position, [A.Step])
bestRoute s g (dst:xs) | src == dst = (A.None, src, [])
                       | Just st <- bwMove s g walkpm src dst,
                         t <- simSteps src st, dst == t = (A.Walk, t, st)
                       | Just st <- fwMove s g runpm src dst,
                         t <- simSteps src st, dst == t = (A.Run, t, st)
                       | canJump (smap s) jumppm src dst = (A.Jump, dst, [])
                       | Just st <- bwMove s g walkpm src dst = (A.Walk, simSteps src st, st)
                       | otherwise = bestRoute s g xs
                       
    where
      src    = Pos (position $ current s) (side $ current s)
      floor  = onFloor $ current s
      walkpm = walkPoints (player s)
      jumppm = jumpPoints (player s)
      runpm  = runPoints (player s)
      
--
-- Fase de reacción. TODO esto hay que mejorarlo mucho
--      
playReaction w s = (A.ReactionAction rot, w)
    where
      rot = snd $ head $ best (bcomp (<) fst) [
             (factor currside, A.NoneRot),
             (factor (prevSide currside), A.LeftRot),
             (factor (nextSide currside), A.RightRot)
            ]
      currside = side $ current s
      currpos = Pos (position (current s)) (currside)
      factor  = yingYangGoodFunc w (lastMovement w) s currpos

--
-- Fase de ataque con armas
--
playWeapons w s | (heat . current) s > 16 = (A.defaultWeapons, w)
                | otherwise = playWeapons' w s

playWeapons' w s = 
    (A.defaultWeapons { A.objective = position obj, A.shots = shots }, new)
    where
      shots = map action $
              filter better $
              -- filter ((<10) . attackModifier) $
              debug $ shootMech (smap s) (current s) (lastMovement w) obj
      obj = nearestMech s

      phisical = phisMech w (smap s) (current s) obj

      -- Comprobamos que no hay un ataque fisico mejor en esa localizacion
      better :: Attack A.Shot -> Bool
      better x = and $ map ((attackFactor x <) . attackFactor) $
                 filter ((== (loc . A.gun . action) x) . A.hitLoc . action) phisical

      new = w { usedLocations = map (loc . A.gun) shots }

--
-- Fase de ataques fisicos
--
playPhisical w s | (heat . current) s > 20 = (A.defaultPhisical, w)
                 | otherwise = playPhisical' w s

playPhisical' w s = (A.PhisicalAction phisical, w)
    where
      obj = nearestMech s
      phisical = map (\x -> A.Phisical (action x) (position obj) A.MechObj) $ 
                 phisMech w (smap s) (current s) obj

playEnd w s = (A.defaultEnd, w { 
                      lastMovement = A.None, 
                      usedLocations = [],
                      killNeed = newKillNeed (length $ filter (0/=) $ diff newLastP),
                      lastP = newLastP})
    where
      points = (sum . elems .internalPoints . current) s + 
               (sum . elems . armourPoints . current) s
      newLastP = (reverse . take 5 . (points :) . reverse . lastP) w
      
      diff [] = []
      diff [_] = []
      diff (x:y:xs) = diff' x y xs
      diff' x y [] = [(x-y)]
      diff' x y (z:xs) = (x-y) : diff' y z xs

      newKillNeed 0 = 1
      newKillNeed 1 = 0.7
      newKillNeed 4 = 0.3
      newKillNeed _ = 0.5

--
-- Constructor
--
warrior :: Nexus7
warrior = initialState
