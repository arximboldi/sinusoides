
#ifndef OUTPUTSPEAKER_H
#define OUTPUTSPEAKER_H

#include <dpmi.h>
#include <go32.h>

#include "types.h"
#include "dbuffer.h"
#include "out.h"

class OutputSpeaker : public Output
{
  DoubleBuffer<Sample> m_buffer;
  _go32_dpmi_seginfo m_old_isr;
  _go32_dpmi_seginfo m_new_isr;
  bool m_finished;
  
  void loop();
  int m_diff;
  int m_count;
  
  void registerISR();
  void unregisterISR();
 public:
  OutputSpeaker(int buf_size);
  
  bool open();
  bool start();
  void put(Sample*, int n_samples);
  bool stop();
  bool close();

  friend void timerISR();
};

#endif /* OUTPUTSPEAKER_H */
