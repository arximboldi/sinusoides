%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       edge_prewitt.m
%  Time-stamp: <2011-01-27 03:15:03 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Detector de fronteras de Prewitt.
%

function [img, gradmag, imgx, imgy, imgnorm] = edge_prewitt (img, threshold, dir)
    img = double (img);
    
    % Filtro de Prewitt
    mask = [-1 -1 -1; 0 0 0; 1 1 1];

    imgx = imfilter (img, mask,  'conv','replicate');
    imgy = imfilter (img, mask', 'conv','replicate');

    switch dir
      case 'both' %Ambos
        grad = sqrt (imgx.*imgx + imgy.*imgy);
      case 'vertical' %Horizontal
        grad = sqrt (imgy.*imgy);
      case 'horizontal' %Vertical
        grad = sqrt (imgx.*imgx);    
    end
    gradmag = grad;
    
    % Seleccionamos solo los pixeles que superan el threshold (si se ha
    % introducido si no devolveremos la img sin thresholdizar)

    if ~isnan (threshold)
        grad = grad > threshold * 256;
    end

    imgnorm = grad;
    img = grad .* 255;
