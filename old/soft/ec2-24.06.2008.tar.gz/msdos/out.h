
#ifndef OUTPUT_H
#define OUTPUT_H

#include "types.h"

class Output;

class OutputListener
{
 public:
  virtual void process(Output* out, int n_frames) = 0;
};

class Output
{
 public:
  enum State {
    NOTINIT,
    IDLE,
    RUNNING,
    N_STATES
  };

 private:
  OutputListener* m_listener;
  State m_state;
  float m_srate;
  
 protected:
  void process(int n_frames) {
    if (m_listener)
      m_listener->process(this, n_frames);
  }

  void setState(State state) {
    m_state = state;
  }
      
 public:

 Output() :
  m_listener(0),
    m_state(NOTINIT),
    m_srate(22100)
    {}

  virtual ~Output() {}
  virtual bool open() = 0;
  virtual bool start() = 0;
  virtual void put(Sample* buf, int n_samples) = 0;
  virtual bool stop() = 0;
  virtual bool close() = 0;

  void setSampleRate(float srate) {
    m_srate = srate;
  }

  float getSampleRate() const {
    return m_srate;
  }
  
  void setListener(OutputListener* list) {
    m_listener = list;
  }
  
  State getState() const {
    return m_state;
  }

  bool gotoState(State target);
};

#endif /* OUTPUT_H */

