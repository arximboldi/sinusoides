/**
 * @file   sdltimer.h
 * @author Juan Pedro Bolívar Puente
 * @date   April 2007
 */

#ifndef __SDLTIMER_H__
#define __SDLTIMER_H__

#include <SDL/SDL.h>

class SDLtimer {
    Uint32 framecount;
    Uint32 lastticks;
    Uint32 ms;
    Uint32 rate;
    Uint32 mscount;
    Uint32 totalms;
	float  rateticks;
	
public:
	SDLtimer();
	SDLtimer(int fpsrate);
	~SDLtimer();
	
	void setFPS(int fpsrate);
	void update();
	
	int msec() {
		return ms;
	};
};

#endif /* __SDLTIMER_H__ */
