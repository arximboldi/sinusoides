/*
 * Driver de sonido para Linux 2.6
 *
 * Autores:
 *   Juan Pedro Bolívar Puente
 *   Francisco Manuel Herrero Pérez
 */

#include <linux/module.h>
#include <asm/uaccess.h>

#include "ring_buf.h"

state_t
ring_buf_init (ring_buf_p buf, size_t size)
{
  buf->data = kmalloc (size, GFP_KERNEL);
  buf->write_pos = 0;
  buf->write_count = 0;
  buf->size = size;
  
  return OK;
}

void
ring_buf_clear (ring_buf_p buf)
{
  kfree (buf->data);
}

ssize_t
ring_buf_availible (ring_buf_p buf, ring_buf_reader_p reader)
{
  return buf->write_count - reader->read_count;
}

ssize_t
ring_buf_write_availible (ring_buf_p buf, ring_buf_reader_p reader)
{
  return buf->size - (buf->write_count - reader->read_count);
}

ring_buf_state_t
ring_buf_state (ring_buf_p buf, ring_buf_reader_p reader)
{
  if (reader->read_count < buf->write_count - buf->size)
    return RING_BUF_UNDERRUN;
  if (reader->read_count > buf->write_count)
    return RING_BUF_OVERRUN;
  return RING_BUF_OK;
}

ring_buf_reader_t
ring_buf_begin (ring_buf_p buf)
{
  ring_buf_reader_t reader;

  if (buf->write_count < buf->size) {
    reader.read_pos = 0;
    reader.read_count = 0;
  } else {
    reader.read_pos = buf->write_pos;
    reader.read_count = buf->write_count - buf->size;
  }
  
  return reader;
}

state_t
ring_buf_write (ring_buf_p buf, const char* data, size_t nwrite)
{
  int offset = 0;
  state_t ret;
  
  if (nwrite > buf->size) {
    offset = nwrite - buf->size;
    nwrite = buf->size;
  }
  
  if (buf->write_pos + nwrite > buf->size &&
      (copy_from_user (buf->data + buf->write_pos, data + offset,
		       buf->size - buf->write_pos) != 0 ||
       copy_from_user (buf->data, data + offset + buf->size - buf->write_pos, 
		       buf->write_pos + nwrite - buf->size) != 0))
    ret = ERROR;
  else
    if (copy_from_user (buf->data + buf->write_pos, data + offset, nwrite))
      ret = ERROR;
  
  buf->write_pos = (buf->write_pos + nwrite) % buf->size;
  buf->write_count += nwrite;

  return ret;
}

ssize_t
ring_buf_read (ring_buf_p buf, ring_buf_reader_p reader,
	       char* dest, size_t samples)
{
  int nread = min (ring_buf_availible (buf, reader), samples);

  if (nread > 0)
    {
      if (reader->read_pos + nread > buf->size)
	{
	  memcpy (dest, buf->data + reader->read_pos, buf->size - reader->read_pos);
	  memcpy (dest + buf->size - reader->read_pos, buf->data,
		  reader->read_pos + nread - buf->size);
	}
      else 
	memcpy (dest, buf->data + reader->read_pos, nread);
    }
  
  reader->read_pos = (reader->read_pos + nread) & buf->size;
  reader->read_count += nread;
  
  return nread;
}

char
ring_buf_read_one (ring_buf_p buf, ring_buf_reader_p reader)
{
  char val;

  val = buf->data [reader->read_pos++];
  if (reader->read_pos > buf->size)
    reader->read_pos = 0;
  reader->read_count++;

  return val;
}
