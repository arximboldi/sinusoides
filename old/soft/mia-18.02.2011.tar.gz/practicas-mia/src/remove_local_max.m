%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       remove_local_max.m
%  Time-stamp: <2011-01-27 05:52:18 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@gnu.org>
%
%  Elimina los máximos locales.
%

function [f, c] = remove_local_max (corners, dist)   
    [f, c, eigenvalue] = find (corners);
    corners = sortrows ([f, c, eigenvalue], -3);

    [nrows, ncols] = size (corners);
    
    removed = zeros (nrows);
    corners_final = zeros (1, 3);
    count = 1;

    for i = 1 : nrows-1
        for j = i+1 : nrows
            if (abs (corners(i,1) - corners(j,1)) < dist && ...
                abs (corners(i,2) - corners(j,2)) < dist)
                removed(j) = 1;       
            end
        end
        if (removed (i) == 0)
            corners_final (count, :) = [corners(i, 1) corners(i,2) corners(i,3)];
            count = count + 1;
        end
    end

    f = corners_final (:,1);
    c = corners_final (:,2);
