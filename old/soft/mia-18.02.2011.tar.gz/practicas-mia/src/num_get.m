%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       num_get.m
%  Time-stamp: <2011-01-23 23:49:18 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Obtiene de forma segura los numeros de un campo de edicion.
%

function res = num_get (hdl, min, max, except)
    if nargin < 4
        except = 1;
    end
    res = str2double (get (hdl, 'String'));
    if isnan (res) || res < min || res > max
        errmsg = strcat ('Parameter ', get (hdl, 'String'), ' not in range ', ...
                 num2str (min), ' - ', num2str (max)); 
        errordlg (errmsg, 'Bad input', 'modal');
        if except
            throw (MException ('num_get', errmsg));
        end
    end
end
