/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic;

import harmonic.gen.*;
import harmonic.dao.*;

import java.util.*;

public class CreateUserQuery extends BasicQuery
{
    static public class Factory implements QueryFactory
    {
	public Query create() {
	    return new CreateUserQuery();
	}
    }

    public Division createUserForm()
    {
	Division div = new Division("block");
	
	div.addContent(new Header(1, "Create user"));
	div.addContent(new Paragraph("Fill the following form with with information about your new user. " +
				     "Give a valid email or you won't be able to complete the registration process."));

	Form form = new Form("register");
	div.addContent(form);
	TwoColumn col = new TwoColumn();
	form.addContent(col);
	
	col.addLeft(new Text("User name: "));
	col.addRight(new Input("user", "user_name", "", 20));
	col.addLeft(new Text("Password: "));
	col.addRight(new Input("password", "user_pass", "", 20));
	col.addLeft(new Text("Repeat password: "));
	col.addRight(new Input("password", "user_pass_rep", "", 20));
	col.addLeft(new Text("E-mail: "));
	col.addRight(new Input("email", "user_email", "", 20));
	
	form.addContent(new Input("submit", "action", "create"));

	return div;
    }

    public Division createConfirmPage()
    {
	Division div = new Division("block");
	
	div.addContent(new Header(1, "Confirm your account"));
	div.addContent(new Paragraph("Congratulations!"));
	div.addContent(new Paragraph("Your account has been succesfully created. " +
				     "You will be able to use your account once you have confirmed it. " +
				     "We have just sent you an email that will guide you in the confirmation process."));
	div.addContent(new Paragraph("Your account will be deleted if not confirmed withing 48 hours."));
	return div;
    }

    public Division createWelcomePage()
    {
	Division div = new Division("block");
	
	div.addContent(new Header(1, "Welcome!"));
	div.addContent(new Paragraph("Your account has been activated."));
	div.addContent(new Paragraph("Use the user menu on the left to login into the system."));
	return div;
    }

    static int EXPIRATION_TIME = 48 * 3600 * 1000;
    
    public Page execute(QueryHandler hdl)
    {
	String action = hdl.getParameter("action");
	String confirm = hdl.getParameter("confirm");
	
	Page result = super.execute(hdl);
	
	if (action == null) {
	    if (confirm == null)
		result.getContent().addContent(createUserForm());
	    else {
		String user_name = hdl.getParameter("user");
		UserDAO dao = hdl.getDAOFactory().getUserDAO();
		User user = dao.find(user_name);
		if (user == null)
		    result.getContent().addContent(new Division("error", "The user does not exist"));
		else if (user.confirm_code == null)
		    result.getContent().addContent(new Division("error", "The account had already been activated."));
		else if (!user.confirm_code.equals(confirm))
		    result.getContent().addContent(new Division("error", "Wrong confirmation petition."));
		else if (user.create_date == null ||
			 getCurrentDate().getTime() - user.create_date.getTime()
			 > EXPIRATION_TIME) {
		    result.getContent().addContent(new Division("error", "The account has expired. Please register again."));
		    result.getContent().addContent(createUserForm());
		    try { dao.delete(user); } catch (Exception e) {}
		} else {
		    user.confirm_code = null;
		    try {
			dao.update(user);
			result.getContent().addContent(createWelcomePage());
		    } catch (Exception e) {
			result.getContent().addContent(new Division("error", e.getMessage()));
		    }
		}
	    }
	} else if (action.equals("create")) {
	    boolean error = false;
	    
	    String user_name = hdl.getParameter("user_name");
	    String user_pass = hdl.getParameter("user_pass");
	    String user_pass_rep = hdl.getParameter("user_pass_rep");
	    String user_email = hdl.getParameter("user_email");

	    if (user_name == null || user_name.equals("")) {
		error = true;
		result.getContent().addContent(new Division("error", "You must give a user name."));
	    }
	    
	    if (user_pass == null || user_pass.equals("")) {
		error = true;
		result.getContent().addContent(new Division("error", "You must give a password."));
	    }

	    if (user_pass_rep == null || user_pass_rep.equals("")) {
		error = true;
		result.getContent().addContent(new Division("error", "You must repeat the password."));
	    }

	    if (user_pass != null &&
		user_pass_rep != null &&
		!user_pass.equals(user_pass_rep)) {
		error = true;
		result.getContent().addContent(new Division("error", "The passwords do not match."));
	    }

	    if (user_email == null || user_email.equals("")) {
		error = true;
		result.getContent().addContent(new Division("error", "You must give a valid email address."));
	    }

	    if (!error) {
		User user = new User(0,
				     null,
				     user_name,
				     user_pass,
				     user_email,
				     generateConfirmCode());
		
		UserDAO dao = hdl.getDAOFactory().getUserDAO();
		try {
		    dao.create(user);
		    sendConfirmCode(user);
		    result.getContent().addContent(createConfirmPage());
		} catch (Exception e) {
		    error = true;
		    result.getContent().addContent(new Division("error", e.getMessage()));
		}
	    }
	    
	    if (error) {
		result.getContent().addContent(createUserForm());
	    }
	}

	return result;
    }

    public String generateConfirmCode()
    {
	return randomString(20, 20);
    }

    public Date getCurrentDate()
    {
	Calendar cal = Calendar.getInstance(); 
	return cal.getTime();
    }
    
    public static String randomString(int lo, int hi)
    {
	int n = rand(lo, hi);
	byte b[] = new byte[n];
	for (int i = 0; i < n; i++) {
	    int t = rand(0, 2);
	    switch (t) {
	    case 0:
		b[i] = (byte)rand('a', 'z');
		break;
	    case 1:
		b[i] = (byte)rand('0', '9');
		break;
	    case 2:
		b[i] = (byte)rand('A', 'Z');
		break;
	    }
	}
	return new String(b);
    }

    private static int rand(int lo, int hi)
    {
	java.util.Random rn = new java.util.Random();
	int n = hi - lo + 1;
	int i = rn.nextInt() % n;
	if (i < 0)
	    i = -i;
	return lo + i;
    }
    
    public void sendConfirmCode(User user)
	throws Exception
    {
	MailNotifier mail = new MailNotifier("127.0.0.1",
					     "127.0.0.1",
					     "noreply@harmonic.com",
					     user.email);
	System.out.println("SENDING MAIL: " + user.email);
	try {
	    mail.send("Harmonic: Account confirmation",
		      "Hi " + user.nick + "!\n\n" +
		      "Your account has been successfully created. You will be able to use it\n" +
		      "once you have confirmed it. To confirm it, please follow this link:" +
		      "   http://localhost:8180/harmonic/register?user=" + user.nick + "&confirm=" + user.confirm_code + "\n\n" +
		      "The account will expire if you don't confirm it withing 48 hours.\n" +
		      "Just ommit it if you think that you should not have received this email.\n\n" +
		      "  Thanks,\n" +
		      "   The Harmonic staff");
	} catch (Exception e) {
	    throw new Exception("There was an error while trying to send the confirmation email. Please contact the system administrator.");
	}
    }
}

