
#ifndef FILTER_H
#define FILTER_H

#include "types.h"

class Filter
{
 public:
  virtual ~Filter() {}
  virtual void process(Sample* buf, int n_frames) = 0;
};

#endif /* FILTER_H */
