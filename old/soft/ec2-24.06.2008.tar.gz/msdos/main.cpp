
#include <stdio.h>
#include <pc.h>

#include "spkapp.h"

int main(int argc, const char** argv)
{
  SpeakerApp app;
    
  return app.run(argc, argv);
}

