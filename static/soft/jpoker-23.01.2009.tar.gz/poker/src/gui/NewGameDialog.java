/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import java.util.Vector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

/**
 * Diálogo que permite crear una nueva partida. Devuelve la información
 * necesaria para construir la partida, no la instancia creada.
 * 
 * @author raskolnikov
 * 
 */
public class NewGameDialog extends Dialog
{
	/**
	 * Construye el diálogo.
	 * @param parent La ventana padre.
	 */
	public NewGameDialog (Shell parent)
	{
		super (parent);
		
		FormLayout form = new FormLayout ();
		m_shell = new Shell (getParent (), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
	    m_shell.setLayout (form);
	    
	    /* Crear contenidos */
	    Group players_group = buildPlayersGroup ();
	    Group options_group = buildOptionsGroup ();
	    
	    Button ok_button = new Button (m_shell, SWT.PUSH);
		ok_button.setText ("&Play");
		Button cancel_button = new Button (m_shell, SWT.PUSH);
		cancel_button.setText ("&Cancel");

	    /* Organizar contenidos */
		form.marginWidth = form.marginHeight = 12;
		
		FormData group_data = new FormData ();
		group_data.left = new FormAttachment (players_group, 12);
		options_group.setLayoutData (group_data);
		
		FormData ok_data = new FormData ();
		ok_data.top = new FormAttachment (players_group, 12);
		ok_button.setLayoutData (ok_data);
		
		FormData cancel_data = new FormData ();
		cancel_data.left = new FormAttachment (ok_button, 12);
		cancel_data.top = new FormAttachment (players_group, 12);
		cancel_button.setLayoutData (cancel_data);

		/* Anadimos eventos molones */
		cancel_button.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				NewGameDialog.this.m_shell.dispose ();
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
		
		ok_button.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				if (NewGameDialog.this.buildGame ())
	    					NewGameDialog.this.m_shell.dispose ();
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
		
		
		m_shell.setDefaultButton (ok_button);
	    m_shell.setText ("New Game");
	    m_shell.pack ();
	}
	
	/**
	 * Ejecuta el diálogo. Devuelve un GameInfo con la información de la
	 * partida.
	 * 
	 * @return Un GameInfo con los datos necesarios para construir una partida.
	 * @see GameInfo
	 */
	public Object open ()
	{
		m_shell.open ();
		
		Display display = getParent ().getDisplay ();
		while (!m_shell.isDisposed ()) {
			if (!display.readAndDispatch ())
				display.sleep ();
		}

		return m_game;
	}
	
	private class AddPlayerDialog extends Dialog
	{
		AddPlayerDialog (Shell parent)
		{
			super (parent);
			
			m_shell = new Shell (getParent (), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
			GridLayout grid = new GridLayout (2, false);
			m_shell.setLayout (grid);
			
			/* Crear contenidos */
			Label name_label = new Label (m_shell, SWT.NONE);
			name_label.setText ("Name: ");
			m_name_text = new Text (m_shell, SWT.BORDER | SWT.SINGLE);
			m_name_text.setText ("Player");
			m_name_text.setSelection (0, m_name_text.getCharCount());
			
			Label savings_label = new Label (m_shell, SWT.NONE);
			savings_label.setText ("Savings: ");
			m_savings_spinner = new Spinner (m_shell, SWT.BORDER);
			m_savings_spinner.setDigits (0);
			m_savings_spinner.setPageIncrement (100);
			m_savings_spinner.setIncrement (1);
			m_savings_spinner.setMinimum (0);
			m_savings_spinner.setMaximum (10000);
			m_savings_spinner.setSelection (2000);
			
			Label type_label = new Label (m_shell, SWT.NONE);
			type_label.setText ("Type: ");
			m_type_combo = new Combo (m_shell, SWT.READ_ONLY);
			m_type_combo.add ("Cool bot");
			m_type_combo.add ("Dumb bot");
			m_type_combo.add ("Human");
			m_type_combo.select (0);
			
			Button ok_button = new Button (m_shell, SWT.PUSH);
			ok_button.setText ("&Ok");
			Button cancel_button = new Button (m_shell, SWT.PUSH);
			cancel_button.setText ("&Cancel");

		    /* Organizar contenidos */
			grid.marginWidth = grid.marginHeight = 12;
			m_name_text.setLayoutData (new GridData (GridData.HORIZONTAL_ALIGN_FILL | 
												 GridData.GRAB_HORIZONTAL));
			
			/* Anadimos eventos */
			cancel_button.addSelectionListener(
		    		new SelectionListener () {
		    			public void widgetSelected (SelectionEvent e)
		    			{
		    				AddPlayerDialog.this.m_shell.dispose ();
		    			}
						public void widgetDefaultSelected (SelectionEvent e) {}
		    		}
		    		);
			
			ok_button.addSelectionListener(
		    		new SelectionListener () {
		    			public void widgetSelected (SelectionEvent e)
		    			{
		    				AddPlayerDialog.this.m_result = 
		    					new PlayerInfo (m_name_text.getText (),
		    									m_savings_spinner.getSelection (),
		    									PlayerInfo.Type.values()
		    									[m_type_combo.getSelectionIndex()]);
		    				AddPlayerDialog.this.m_shell.dispose ();
		    			}
						public void widgetDefaultSelected (SelectionEvent e) {}
		    		}
		    		);
			
			/* Finiquitamos */
			m_shell.setDefaultButton (ok_button);
			m_shell.setText ("Add player");
			m_shell.pack ();
		}
		
		Object open ()
		{
			m_shell.open ();
			
			Display display = getParent ().getDisplay ();
			while (!m_shell.isDisposed ()) {
				if (!display.readAndDispatch ())
					display.sleep ();
			}
			
			return m_result;
		}
		
		PlayerInfo m_result;
		Combo m_type_combo;
		Spinner m_savings_spinner;
		Text m_name_text;
		Shell m_shell;
	}
	
	private Group buildOptionsGroup ()
	{
		/* Crear el grupo */
		Group group = new Group (m_shell, SWT.NONE);
		FormLayout form = new FormLayout ();
		group.setLayout (form);
		
		/* Crear los contenidos */
		Label bet_label = new Label (group, SWT.NONE);
		bet_label.setText ("Start bet:");
		
		m_start_bet = new Spinner (group, SWT.BORDER);
		m_start_bet.setSelection (20);
		m_start_bet.setMinimum (0);
		m_start_bet.setMaximum (5000);
		m_start_bet.setIncrement (1);
		m_start_bet.setPageIncrement (10);
		m_start_bet.setDigits (0);
		
		m_public = new Button (group, SWT.CHECK);
		m_public.setText ("Public cards");
		
		m_non_stop = new Button (group, SWT.CHECK);
		m_non_stop.setText ("Non-stop mode");
		
		/* Organizar los contenidos */
		form.marginWidth = form.marginHeight = 12;

		FormData bet_data = new FormData ();
		bet_data.left = new FormAttachment (bet_label, 6);
		bet_data.top = new FormAttachment(bet_label, 0, SWT.CENTER);
		m_start_bet.setLayoutData (bet_data);
		
		FormData public_data = new FormData ();
		public_data.top = new FormAttachment (bet_label, 6);
		m_public.setLayoutData (public_data);
		
		FormData step_data = new FormData ();
		step_data.top = new FormAttachment (m_public, 6);
		m_non_stop.setLayoutData (step_data);
		
		/* Finiquitar */
		group.setText ("Options");
		group.pack();
		
		return group;	
	}
	
	private Group buildPlayersGroup ()
	{
		Group group = new Group (m_shell, SWT.SHADOW_OUT);
		FormLayout form = new FormLayout ();
		group.setLayout (form);
		
		/* Crear contenidos */
		m_player_list = new List (group, SWT.BORDER | SWT.SINGLE | SWT.V_SCROLL);
		Button add_button = new Button (group, SWT.PUSH);
		add_button.setText ("&Add");
		Button del_button = new Button (group, SWT.PUSH);
		del_button.setText ("&Remove");
		
		/* Organizando contenidos */
		form.marginWidth = form.marginHeight = 12;

		FormData list_data = new FormData ();
		list_data.height = 100;
		list_data.width = 100;
		m_player_list.setLayoutData (list_data);
		
		FormData add_data = new FormData ();
		add_data.top = new FormAttachment (m_player_list, 6);
		add_button.setLayoutData (add_data);
		
		FormData del_data = new FormData ();
		del_data.left = new FormAttachment (add_button, 6);
		del_data.top  = new FormAttachment (m_player_list, 6);
		del_button.setLayoutData (del_data);
		
		/* Envetillos */
		add_button.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				PlayerInfo info = null;
	    				AddPlayerDialog dia = 
	    					new AddPlayerDialog (NewGameDialog.this.m_shell);
	    				info = (PlayerInfo) dia.open ();
	    				if (info != null) {
	    					NewGameDialog.this.m_player_list.add (info.name);
	    					NewGameDialog.this.m_player_data.add (info);
	    				}
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
		
		del_button.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				int selection = 
	    					NewGameDialog.this.m_player_list.getSelectionIndex ();
	    				if (selection >= 0) {
	    					NewGameDialog.this.m_player_list.remove (selection);
	    					NewGameDialog.this.m_player_data.remove (selection);
	    				}
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
		
		/* Finiquitando */
		group.setText ("Players");
		group.pack ();
	
		return group;
	}
	
	private boolean buildGame ()
	{
		String error_message = null;
		
		if (m_player_data.size () < 2)
			error_message = "You need at least two players to play poker!";
		else if (m_player_data.size () > 5)
			error_message = "Too many players. The maximum is 5 players.";
		
		if (error_message == null) {
			m_game = new GameInfo (m_player_data,
					m_start_bet.getSelection(),
					m_public.getSelection (),
					m_non_stop.getSelection ());
		} else {
			MessageBox msg = new MessageBox (m_shell, SWT.ICON_ERROR);
			msg.setMessage (error_message);
			msg.open ();
			
			return false;
		}
		
		return true;
	}
	
	private Spinner m_start_bet;
	private Button m_public;
	private Button m_non_stop;
	private List  m_player_list;
	private Vector<PlayerInfo> m_player_data = new Vector<PlayerInfo> ();
	
	private Shell m_shell;
	private GameInfo m_game = null;
}
