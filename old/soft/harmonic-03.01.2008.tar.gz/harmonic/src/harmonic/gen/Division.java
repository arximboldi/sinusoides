/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.gen;

import org.w3c.dom.*;
import java.util.*;

public class Division extends ContentGenerator
{
    String m_id = null;
    String m_text = null;
    
    public Division(String id) {
	m_id = id;
    }

    public Division(String id, String text) {
	m_id = id;
	m_text = text;
    }

    public void setId(String new_id) {
	m_id = new_id;
    }
    
    public Node generate(Document doc)
    {
	Element el = doc.createElement("div");
	if (m_id != null)
	    el.setAttribute("id", m_id);
	
	if (m_text != null)
	    el.appendChild(doc.createTextNode(m_text));

	return generateContent(el);
    }
}
