--  File:       Warrior.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon Mar 16 14:36:16 2009
--  Time-stamp: <2009-05-29 20:49:43 raskolnikov>
--
--  Entorno de ejecución del bot
--

module Mech.Warrior where

import System.Time

import Mech.Info
import Mech.Action
import Mech.IO

--
-- Cualquier instancia de la clase Warrior implementa un jugador
-- automático capaz de ejecutar las cuatro fases.
--
class Warrior a where
    playMovement :: a -> State -> (MovementAction, a)
    playReaction :: a -> State -> (ReactionAction, a)
    playWeapons  :: a -> State -> (WeaponsAction, a)
    playPhisical :: a -> State -> (PhisicalAction, a)
    playEnd      :: a -> State -> (EndAction, a)
    warName      :: a -> String

--
-- Invoca un jugador automático para tomar su decisión
--
play :: (Warrior a, Show a, Read a) 
     => a        -- El jugador automático  
     -> Int      -- El número del jugador
     -> String   -- El nombre de la fase
     -> IO ()
play w id phase =
    do state   <- loadState id
       warrior <- loadWarrior w id
       
       case phase of
         "Movimiento" -> 
             do let (action, warrior') = playMovement warrior state
                storeAction id $ storeMovement action
                storeWarrior warrior' id
         "Reaccion" ->
             do let (action, warrior') = playReaction warrior state
                storeAction id $ storeReaction action
                storeWarrior warrior' id
         "AtaqueArmas" ->
             do let (action, warrior') = playWeapons warrior state
                storeAction id $ storeWeapons action
                storeWarrior warrior' id
         "AtaqueFisico" -> 
             do let (action, warrior') = playPhisical warrior state
                storeAction id $ storePhisical action
                storeWarrior warrior' id
         "FinalTurno" ->
             do let (action, warrior') = playEnd warrior state
                storeAction id $ storeEnd action
                storeWarrior warrior' id

stateFile :: (Warrior a) => a -> Int -> String
stateFile w id = warName w ++ "-" ++ show id ++ ".state"

--
--  Carga el estado actual del warrior
--
loadWarrior :: (Warrior a, Read a)
            => a      -- Valor por defecto del jugador
            -> Int    -- Identificador del jugador
            -> IO a   -- Estado del jugador
loadWarrior warrior id = 
    do str <- readFile $ stateFile warrior id
       warrior' <- readIO str
       return warrior'
    `catch`
    (\e -> return warrior)

--
-- Guarda el estado actual del jugador
--
storeWarrior :: (Warrior a, Show a)
            => a      -- Estado del jugador jugador
            -> Int    -- Identificador del jugador
            -> IO ()  -- Estado del jugador
storeWarrior warrior id =
    writeFile (stateFile warrior id) (show warrior)
