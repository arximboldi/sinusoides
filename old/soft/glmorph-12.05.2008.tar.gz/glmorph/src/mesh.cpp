/**
 * @file   mesh.cpp
 * @author Juan Pedro Bol�var Puente
 * @date   April 2007
 * 
 * Copyright (C) 2007 by Juan Pedro Bol�var Puente
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <iostream>
#include <fstream>

#include "glmorph.h"
#include "mesh.h"

using namespace std;

Mesh2D::Mesh2D(int w, int h)
{
	allocate(w, h);
}

Mesh2D::Mesh2D(int w, int h, int picw, int pich)
{
	allocate(w, h);
	defaults(picw, pich);
}

Mesh2D::Mesh2D(const Mesh2D& m)
{
	int i;
	
	allocate(m.w, m.h);
		
	for (i = 0; i < w; i++)
		memcpy(data[i], m.data[i], sizeof(Point2D)*h);
}

Mesh2D::~Mesh2D()
{
	freemem();
}

void Mesh2D::freemem()
{
	int i;
	
	for (i = 0; i < w; i++)
		delete [] data[i];
	
	delete [] data;
}

int Mesh2D::allocate(int w, int h)
{
	int i;
	
	try {
		data = new Point2D*[w];
	} catch(bad_alloc& e) {
		cerr << _("ERROR: Could not allocate memory for ") << w << _(" cells.") << endl;
		return false;
	}
		
	for (i = 0; i < w; i++) {
		try {
			data[i] = new Point2D[h];
		} catch(bad_alloc& e) {
			cerr << _("ERROR: Could not allocate memory for ") << h << _(" cells.") << endl;
			for (i--; i >= 0; i--)
				delete [] data[i];
			delete [] data;
			
			return false;
		}
	}
			
	this->w = w;
	this->h = h;
	
	return true;
}

void Mesh2D::defaults(int picw, int pich)
{
	int i, j;
	
	for (i = 0; i < w; i++) {
		for (j = 0; j < h; j++) {
			data[i][j].x = int( (float)(picw)/(w-1) * i );
			data[i][j].y = int( (float)(pich)/(h-1) * j );
		}
	}
}

/*
 * TODO: Check that format is correct.
 */
bool Mesh2D::load(const char* path)
{
	ifstream fin(path);
	
	if (!fin.is_open())
		return false;
	
	fin >> *this;
	
	fin.close();
	return true;
}

bool Mesh2D::store(const char* path) const
{
	ofstream fout(path);
	
	if (!fout.is_open())
		return false;
	
	fout << *this;
	
	fout.close();
	return true;
}

ostream& operator << (ostream& os, const Mesh2D &m)
{
	int i, j;
	
	os << m.w << " " 
	   << m.h << endl;
	
	for (j = 0; j < m.h; j++) {
		for (i = 0; i < m.w; i++) {
			os << m.data[i][j].x << " "
			   << m.data[i][j].y << "\t";
		}
		os << endl;
	}
	
	return os;
}

istream& operator >> (istream& is, Mesh2D &m)
{
	int w, h;
	int i, j;

	is >> w >> h;
	
	m.freemem();
	m.allocate(w, h);
	
	for (j = 0; j < h; j++) {
		for (i = 0; i < w; i++) {
			is >> m.data[i][j].x
			   >> m.data[i][j].y;
		}
	}
	
	return is;
}

Mesh2D& Mesh2D::operator= (const Mesh2D& m)
{
	int i;
	
	if (&m != this) {
		if (w != m.w || h != m.h) {
			freemem();
			allocate(m.w, m.h);
		}
		
		for (i = 0; i < w; i++)
			memcpy(data[i], m.data[i], sizeof(Point2D)*h);
	}
	return *this;
}
