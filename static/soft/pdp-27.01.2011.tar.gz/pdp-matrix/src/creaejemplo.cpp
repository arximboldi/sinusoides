/**
 *  Time-stamp:  <2010-11-17 21:48:40 raskolnikov>
 *
 *  @file        creaejemplo.cpp
 *  @author      Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
 *  @date        Wed Nov 17 21:48:34 2010
 *
 *  Crea un fichero de ejemplo.
 */

#include <fstream>
#include <string>
#include <cstdlib>

int main (int argc, char * argv [])
{
    int vertices;
    ofstream file;
    int aleatorio;
    string nombre = "input";

    vertices = atoi (argv[1]);
    nombre += string (argv[1]);

    int matriz [vertices][vertices];

    for (int i=0; i<vertices; i++)
    {
	for(int j=0; j<vertices; j++)
	{
	    if(i==j)
	    {
		matriz[i][j]=-1;
	    }
	    else
	    {
		aleatorio = (rand() % (vertices * 2)) + 1; 
		// (25% de huecos)
		if ( (aleatorio> (vertices*11/20)) ||(aleatorio < (vertices*9/20)))
		{
		    aleatorio=0;
		}				
		matriz[i][j]=aleatorio;
	    }
	}
    }

    file.open (nombre.c_str ());

    file << vertices << endl;
	
    for (int i=0; i<vertices; i++)
    {
	for (int j=0; j<vertices; j++)
	{
	    if (matriz[i][j]>0)
	    {
		file << i << " " << j << " " << matriz[i][j] << endl;	
	    }
	}
    }
	
    file.close ();
	
    return 0;
}
