/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.List;

/**
 * Define la interfaz que debe implementar cualquier objeto que quiera escuchar
 * eventos de una partida.
 * 
 * @author raskolnikov
 */
public interface GameListener 
{
	/**
	 * Este método será invocado cuando la partida comienze correctamente.
	 * @param g El juego que ha comenzado.
	 */
	public void handleGameStart (Game g);
	
	/**
	 * Este método será invocado cuando la partida termine correctamente.
	 * @param g El que juego que ha terminado.
	 */
	public void handleGameFinish (Game g);
	
	/**
	 * Este método será invocado cuando una ronda de la partida finalize. Notar
	 * que la semantica de "ronda" difiere este contexto del que tiene en Game.
	 * Aquí representa una subpartida, en la que los jugadores pueden
	 * interaccionar varias veces, pero en la que puede determinarse un ganador
	 * al menos parcial.
	 * 
	 * @param g
	 *            El juego en el que ha ocurrido la ronda.
	 * @param winner
	 *            Lista con los ganadores de la ronda.
	 */
	public void handleGameRound (Game g, List<Player> winner);
	
	/**
	 * Este método será invocado cuando un jugador se una a la partida.
	 * @param g El juego en el que sucede el evento.
	 * @param p El jugador que se une.
	 */
	public void handleGameJoin (Game g, Player p);
	
	/**
	 * Este método será invocado cuando un jugador abandone la partida.
	 * @param g El juego en el que sucede el evento.
	 * @param p El jugador que nos abandona.
	 */
	public void handleGameLeave (Game g, Player p);
}
