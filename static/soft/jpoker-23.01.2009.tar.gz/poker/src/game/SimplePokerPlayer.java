/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Jugador de poker automático que implementa heurísticas sencillas para decidir
 * sus jugadas.
 * 
 * @author raskolnikov
 */
public class SimplePokerPlayer extends PokerPlayer 
{
	/**
	 * Construye el jugador de poker.
	 * @param name El nombre del jugador.
	 * @param savings El dinero que tiene inicialmente el jugador.
	 */
	public SimplePokerPlayer (String name, double savings)
	{
		super (name, savings);
	}
	
	/**
	 * Construye el jugador de poker.
	 * @param name El nombre del jugador.
	 * @param savings El dinero que tiene inicialmente el jugador.
	 * @param random Aleatoriedad del jugador entre 0 y 1
	 * @param brave Valentía del jugador entre 0 y 1
	 */
	public SimplePokerPlayer (String name, double savings, 
			double random, double brave)
	{
		super (name, savings);
		m_random = random;
		m_brave = brave;
	}
	
	/**
	 * Elije la apuesta del jugador en la situación actual.
	 */
	@Override
	public double chooseBet () 
	{
		double random = 1 - m_gen.nextDouble () * m_random;
		double p = points () * 2;
		if (((PokerGame)getGame ()).getState () == PokerGame.State.FIRST_BET)
			p += 1;
		double q = p / NaivePokerEvaluator.BIG_FACTOR * m_brave * random;
		double min_bet = Math.max(getGame ().getMinBet (),
				((PokerGame) getGame ()).getStartBet ());
		
		if (q > 1.0 && min_bet < getSavings () * q * m_brave * random)
		{
			double bet = min_bet + min_bet * q * m_brave * random;
			return bet;
		}
		return 0.0;
	}

	/**
	 * Elije las cartas que el jugador devolvería en la situación actual.
	 */
	@Override
	public List<Card> chooseDrop () 
	{
		double random = m_gen.nextDouble () * m_random;
		List<Card> v =  new LinkedList<Card> ();
		PokerEvaluator ev = new NaivePokerEvaluator (m_cards);
		ev.evaluate ();
		double [] cp = ev.cardPoints ();
		int c = 0;
		for (int i = 0; i < 5 && c < 4; ++i)
			if (!(cp [i] > 0) && m_gen.nextDouble () > random) {
				v.add (m_cards.get (i));
				++c;
			}
		
		return v;
	}

	/**
	 * Decide si el jugador quiere abandonar la partida.
	 * @return @a true si quiere abandonar y @a false en caso contrario.
	 */
	@Override
	public boolean leave() {
		return false;
	}
	
	private double m_random = 0.0;
	private double m_brave  = 0.0;
	private Random m_gen = new Random ();
}
