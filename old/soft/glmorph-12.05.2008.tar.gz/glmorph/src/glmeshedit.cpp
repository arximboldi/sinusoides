/**
 * @file   morph.cpp
 * @author Juan Pedro Bol�var Puente
 * @date   April 2007
 * 
 * Copyright (C) 2007 by Juan Pedro Bol�var Puente
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <iostream>

#include "SDL_2dgl.h"
#include "glmeshedit.h"
#include "render.h"

using namespace std;

/**
 * Main function.
 */
int main(int argc, char* argv[])
{
	EdOptions ops;
	GL2D_SurfaceGL* pic;
	
	if (!parseArgs(ops, argc, argv)) {
		showHelp(basename(argv[0]));
		return 1; 
	}
	
	Mesh2D m(ops.meshw, ops.meshh);
	
	if (ops.infile == "")
		ops.infile = ops.outfile;
	
	initSDL();
	GL2D_InitScreenGL(ops.scrw, ops.scrh, 32, 0);
	
	if ((pic = loadPicture(ops.picfile.c_str()))) {
		ops.scrw = pic->w;
		ops.scrh = pic->h;
		
		GL2D_InitScreenGL(ops.scrw, ops.scrh, 32, 0);
	}
	
	if (!m.load(ops.infile.c_str())) {
		m.defaults(ops.scrw, ops.scrh);
	}
	
	SDL_WM_SetCaption(basename(argv[0]), NULL);
	
	editMesh(m, pic);
	
	if (!m.store(ops.outfile.c_str()))
		cerr << _("Could not store file:") << ops.outfile << endl;
	
	if (pic != NULL) {
		GL2D_FreeSurfaceGL(pic);
		pic = NULL;
	}
	
	return 0;
}

bool parseArgs(EdOptions &ops, int argc, char* argv[])
{
	bool ret = false;
	int i;
	
	ops.picfile = "";
	ops.infile  = "";
	ops.outfile = "";
    ops.meshw   = DEF_MESH_W; 
    ops.meshh   = DEF_MESH_H;
    ops.scrw    = DEF_SCR_W;
    ops.scrh    = DEF_SCR_H;
    
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
			switch (argv[i][1]) {
			case 'i':
				if ((i+1) < argc) {
					ops.infile = argv[i+1];
					i++;
				} break;
			case 'o':
				if ((i+1) < argc) {
					ops.outfile = argv[i+1];
					i++;
				} break;
			case 'p':
				if ((i+1) < argc) {
					ops.picfile = argv[i+1];
					i++;
				} break;
			case 'w':
				if ((i+1) < argc) {
					ops.meshw = atoi(argv[i+1]);
					i++;
				} break;
			case 'h':
				if ((i+1) < argc) {
					ops.meshh = atoi(argv[i+1]);
					i++;
				} break;
			case 'a':
				if ((i+1) < argc) {
					ops.scrw = atoi(argv[i+1]);
					i++;
				} break;
			case 'b':
				if ((i+1) < argc) {
					ops.scrh = atoi(argv[i+1]);
					i++;
				} break;
			case '?':
				ret = false; 
				break;
			}
        } else {
			ops.outfile = argv[i];
			ret = true;
        }
    }
    
    return ret;
}

/* TODO */
void showHelp(const char* appname)
{
	cout << _("Usage:") << endl
		 << appname << _(" mesh_to_edit [options]") << endl << endl
		 << _("Options:") << endl
		 << _("  -i <str>   Load a different mesh as input.") << endl
		 << _("  -p <str>   Use a picture as background.") << endl
		 << _("  -w <int>   Number of columns of the mesh.") << endl
		 << _("  -h <int>   Number of rows of the mesh.") << endl
		 << _("  -a <int>   Number of columns of the screen (if -p is not used).") << endl
		 << _("  -b <int>   Number of rows of the screen (if -p is not used).") << endl
		 << _("  -?         Show this help screen.") << endl;
}

void selectPoint(const Mesh2D& m, int x, int y, int &selx, int &sely)
{
	int i, j;
	
	for (j = 0; j < m.height(); j++) {
		for (i = 0; i < m.width(); i++) {
			if (m.get(i,j).x-4 < x &&
				m.get(i,j).x+4 > x &&
				m.get(i,j).y-4 < y &&
				m.get(i,j).y+4 > y) {
				
				selx = i;
				sely = j;
			}
		}
	}
}

void editMesh(Mesh2D& m, const GL2D_SurfaceGL* pic)
{
	bool done = false;
	SDL_Event e;
	
	int selx = -1;
	int sely = -1;
	
	while (!done) {
		SDL_WaitEvent(&e);
		do {
			switch(e.type) {
				case SDL_MOUSEBUTTONDOWN:
					selectPoint(m, e.button.x, e.button.y, selx, sely);
					break;
				
				case SDL_MOUSEBUTTONUP:
					selx = -1;
					sely = -1;
					break;
				
				case SDL_MOUSEMOTION:
					if (selx >= 0 && sely >= 0) {
						m.set(selx, sely, e.motion.x, e.motion.y);
					}
				
					break;
				
				case SDL_QUIT:
					done = true;
					break;
					
				case SDL_KEYDOWN:
					if (e.key.keysym.sym == SDLK_ESCAPE)
						done = true;
					break;
				
				default:
					break;
			}
			
		} while (SDL_PollEvent(&e));
		
		glClear(GL_COLOR_BUFFER_BIT);
		if (pic != NULL)
			GL2D_BlitGL(pic, 0, 0, 255);
		
		drawMesh2D(m);
		
		SDL_GL_SwapBuffers();
	}
}
