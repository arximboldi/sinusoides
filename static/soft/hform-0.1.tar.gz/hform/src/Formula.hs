--------------------------------------------------------------------------------
--
-- Fichero:    Formula.hs
-- Autor:      Juan Pedro Bolivar Puente
-- Time-stamp: <2009-02-02 20:15:38 raskolnikov>
--
--------------------------------------------------------------------------------

-- | 
-- Modulo de manejo de predicados de logica de primer orden.
module Formula where


--------------------------------------------------------------------------------
-- DATOS
--------------------------------------------------------------------------------

-- | 
-- Representa una fórmula bien formada de la lógica de primer órden.
-- El parámetro /t/ define el tipo de los átomos.
--
-- Nota:
--
-- Existen tres cambios respecto a la representación proporcionada por el
-- profesor, que son los siguientes.
--
-- 1. El más importante es que el tipo se ha parametrizado para que los
--    átomos puedan se de cualquier tipo. Así la biblioteca es más 
--    reutilizable ya que es probable que distintos contextos requieran
--    distintas formas de representación. 
--    
--    Por ejemplo si queremos utilizarla en un sistema de cálculo lógico es 
--    probable que sea interesante que el usuario pueda dotar a las variables 
--    de nombres, cadenas de caracteres, que sean representativas en el ámbito 
--    de su aplicación. En cambio en otro contexto puede que un entero que 
--    identifique el índice de la variable sea más correcto o eficiente.
--
--    En cualquier caso, el programador que use la biblioteca
--    gana libertad lo cual siempre es bueno. Además esto no tiene ningún coste
--    adicional de eficiencia -el profesor decía lo contrario en clase, sin
--    embargo los genéricos tienen coste cero.
--
-- 2. Los constructores de datos binarios son infijos y siguen la precedencia
--    normal de los operadores equivalentes de la lógica preposicional. Así
--    el uso de la biblioteca es más cómodo y natural. También se ha cambiado
--    el nómbre del constructor de los átomos por A, ya que F me parecía poco
--    representativo.
--
-- 3. Se ha añadido un nuevo constructor 'V Bool'. Este valor es necesario ya que
--    al reducir la expresión puede llegarse a que la expresión en su conjunto
--    es tautológica o contradictoria. Esto se notaría mediante V True de ser
--    tautológica y V False de ser falsa.
--
-- Espero que estos cambios no sean considerados un error sino una mejora :-)
--
data Formula t = A t                          -- ^ Un átomo
               | V Bool                       -- ^ Un valor lógico
               | N (Formula t)                -- ^ Negación
               | (Formula t) :| (Formula t)   -- ^ Disyunción
               | (Formula t) :& (Formula t)   -- ^ Conjunción
               | (Formula t) :<-> (Formula t) -- ^ Sii
               | (Formula t) :-> (Formula t)  -- ^ Si
                 deriving (Eq, Ord)

-- |
-- Especificamos la precedencia de los operadores infijos
infixr 9 :|
infixr 8 :&
infixr 7 :->
infixr 6 :<->

-- |
-- Formula pertenece a la clase Show
instance (Show t) => Show (Formula t) where
    showsPrec p f s = showsForm p f s

-- |
-- Formula pertenece a la clase Read
instance (Read t) => Read (Formula t) where
    readsPrec p = readsForm p


--------------------------------------------------------------------------------
-- REPRESENTACIÓN
--------------------------------------------------------------------------------

-- |
-- Operacion de tipo shows que muestra, utilizando parentizaciones mínimas, la
-- fórmula por patalla utilizando la siguiente representación para los
-- operadores, usando precedencias equivelentes a las de arriba.
--
--    1. Los átomos se muestran según la representación propia de su tipo.
--    2. Las tautologías se representan mediante T
--    3. Las contradicciones se representan mediante F
--    4. El operador NOT se representa como ~
--    5. El operador OR se representa como |
--    6. El operador AND se presenta como &
--    7. El operador IIF se presenta como <->
--    8. El operador IF se representa como ->
--
-- Definimos showsPrec para representación eficiente por composición de
-- funciones y no por concatenación de cadenas.
showsForm :: (Show t) => Int -> Formula t -> String -> String
-- Átomos
showsForm p (A x)     s =  shows x s
showsForm p (V True)  s =  'T':s
showsForm p (V False) s =  'F':s
-- Negación
showsForm p (N x) s  | p < 1     = '(':'~': showsForm 1 x (')':s)
                     | otherwise =     '~': showsForm 1 x s
-- Disyunción
showsForm p (l :| r) s | p > 9     =  '(': showsForm 9 l ('|': showsForm 9 r (')':s))
                       | otherwise =       showsForm 9 l ('|': showsForm 9 r s)
-- Conjunción
showsForm p (l :& r) s | p > 8     =  '(': showsForm 8 l (' ':'&':' ': showsForm 8 r (')':s))
                       | otherwise =       showsForm 8 l (' ':'&':' ': showsForm 8 r s)
-- Si
showsForm p (l :-> r) s | p > 7     =  '(': showsForm 7 l (' ':'-':'>':' ': showsForm 7 r (')':s))
                        | otherwise =        showsForm 7 l (' ':'-':'>':' ': showsForm 7 r s)
-- Sii
showsForm p (l :<-> r) s | p > 6     =  '(': showsForm 6 l (' ':'<':'-':'>':' ': showsForm 6 r (')' : s))
                         | otherwise =        showsForm 6 l (' ':'<':'-':'>':' ': showsForm 6 r s)

-- |
-- Función para la interpretación de las expresiones.
-- La sintáxis que acepta es justamente la misma que se emite desde la 
-- clase Show, pero aceptando también espacios entre los lexemas.
readsForm :: (Read t) => Int -> ReadS (Formula t)
readsForm d r = readParen (d > 10)
                (\r -> [(A a, t) |
                        (a, t) <- readsPrec (10+1) r]) r
                ++
                readParen (d > 10)
                (\r -> [(V True, t) |
                        ("T", t) <- lex r]) r
                ++
                readParen (d > 10)
                (\r -> [(V False, t) |
                        ("F", t) <- lex r]) r
                ++
                readParen (d > 10)
                (\r -> [(N f, t) |
                        ('~':s, sx) <- lex r,
                        (f, t)      <- readsForm (9+1) (s++sx)]) r
                ++
                readParen (d > 9)
                (\r -> [(u :| v, w) |
                        (u, s)      <- readsForm (9+1) r,
                        ('|':t, tx) <- lex s,
                        (v,  w)     <- readsForm (9) (t++tx)]) r
                ++
                readParen (d > 8)
                (\r -> [(u :& v, w) |
                        (u, s)      <- readsForm (8+1) r,
                        ('&':t, tx) <- lex s,
                        (v,  w)     <- readsForm (8) (t++tx)]) r
                ++
                readParen (d > 7)
                (\r -> [(u :-> v, w) |
                        (u, s)   <- readsForm (7+1) r,
                        ('-':'>':t, tx) <- lex s,
                        (v,  w)  <- readsForm (7) (t++tx)]) r
                ++
                readParen (d > 6)
                (\r -> [(u :<-> v, w) |
                        (u, s)        <- readsForm (6+1) r,
                        ('<':'-':'>':t, tx) <- lex s,
                        (v,  w)       <- readsForm (6) (t++tx)]) r

--------------------------------------------------------------------------------
-- MÉTODOS PÚBLICOS
--------------------------------------------------------------------------------

-- |
-- Reduce una Formula a su /Forma Normal Conjuntiva/
fnc :: (Eq t) => Formula t -> Formula t
fnc f = contra 
        (quitarTauto 
         (limpiaCon 
          (mapDis quitarContra 
           (mapDis limpiaDis 
            (simplificar f)))))

--------------------------------------------------------------------------------
-- UTILIDADES DE IMPLEMENTACION
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Forma conjuntiva no normal
-- 

-- | 
-- Obtiene la forma conjuntiva de una fórmula, con los dos niveles asociados
-- a la derecha, que es mejor
simplificar :: (Eq t) => Formula t -> Formula t
simplificar f = if f == simplifica f then f
                else simplificar (simplifica f)

-- |
-- Aplica la simplificación de un término
simplifica :: (Eq t) => Formula t -> Formula t

-- Simplificaciones varias, provienen directamente de la teoría
simplifica (a :<-> b)      = ((simplifica a) :-> (simplifica b)) :& 
                             ((simplifica b) :-> (simplifica a))
simplifica (a :-> b)       = N (simplifica a) :| (simplifica b)
simplifica (N (N a))       = simplifica a
simplifica (N (a :| b))    = N (simplifica a) :& N (simplifica b)
simplifica (N (a :& b))    = N (simplifica a) :| N (simplifica b)
simplifica (a :| (b :& c)) = ((simplifica a) :| (simplifica b)) :& 
                             ((simplifica a) :| (simplifica c))
simplifica ((b :& c) :| a) = ((simplifica a) :| (simplifica b)) :& 
                             ((simplifica a) :| (simplifica c))

-- Rotaciones para dejar la fórmula asociada por la derecha,
-- lo cual lo necesitaremos en los tediosos procedimientos para buscar
-- tautologias y repetidos si no queremos volvernos locos :-D
simplifica ((a :| b) :| c) = (simplifica a) :| ((simplifica b) :| (simplifica c))
simplifica ((a :& b) :& c) = (simplifica a) :& ((simplifica b) :& (simplifica c))

-- Términos no simplificables, los dejamos tal cual
simplifica (a :| b)        = (simplifica a) :| (simplifica b) 
simplifica (a :& b)        = (simplifica a) :& (simplifica b)
simplifica (N a)           = N (simplifica a)
simplifica (A a)           = A a
simplifica (V a)           = V a

--------------------------------------------------------------------------------
-- Aplicacion sobre las disjunciones
--

-- |
-- Procesa con la función dada como parámetro todas los bloques de disyunciones
-- de la forma normal
mapDis :: (Formula t -> Formula t) -> Formula t -> Formula t
mapDis func (a :& b) = (func a) :& (mapDis func b)
mapDis func a        = func a

--------------------------------------------------------------------------------
-- Elementos repetidos
--

-- |
-- Quita los elementos repetidos de las conjunciones
--
-- Tenemos eqDis que es una relación que nos dice
-- si una disyunción es igual o más simple que la segunda.
-- en cierto modo es una relación <=.
--
-- Lo que hacemos es dejar primero todos los mínimos y luego
-- eliminimaos los repetidos.
limpiaCon :: (Eq t) => Formula t -> Formula t
limpiaCon f = repes (minimos f f)
    where
      minimos f' (a :& b) = minimos (quitarDis f' (compLt a)) b
      minimos f' a        = quitarDis f' (compLt a)
      repes (a :& b) = a :& repes (quitarDis b (eqDis a))
      repes  a       = a
      compLt a b  = (eqDis a b) && not (eqDis b a)

-- |
-- Elimina los elementos de la conjunción que satisfacen cierta condición
quitarDis :: (Eq t) => Formula t -> (Formula t -> Bool) -> Formula t
quitarDis (a :& b) cmp | cmp a     = quitarDis b cmp
                       | otherwise = a :& (quitarDis b cmp)
quitarDis a cmp        | cmp a     = V True
                       | otherwise = a

-- |
-- Comprueba si la primera conjunción es mas simple que la segunda o es igual
eqDis :: (Eq t) => Formula t -> Formula t -> Bool
eqDis (a :| b) o | buscarDis a o = eqDis b o 
                 | otherwise     = False
eqDis a o = buscarDis a o

-- |
-- Busca una formula en una disyuncion
buscarDis :: (Eq t) => Formula t -> Formula t -> Bool 
buscarDis a (b :| c) | a == b    = True
                     | otherwise = buscarDis a c
buscarDis a b        | a == b    = True
                     | otherwise = False

-- |
-- Quita los elementos repetidos de una disyuncion
limpiaDis :: (Eq t) => Formula t -> Formula t
limpiaDis (a :| b) | siguiente == a = a
                   | otherwise      = a :| siguiente
    where
      siguiente = limpiaDis (quita a b)
      quita a (b :| c) | a == b    = quita a c
                       | otherwise = (b :| (quita a c))
      quita a c  | a == c    = V False -- Esto se elimina despues
                 | otherwise = c
limpiaDis f = f

--------------------------------------------------------------------------------
-- Contradicciones y tautologías
--

-- |
-- Reduce a contradicción una conjunción que lo sea. Notar que
-- la formula debe ser conjuntiva y no tener contradicciones
-- redundantes
contra :: (Eq t) => Formula t -> Formula t
contra f | tieneContra f = V False
         | otherwise     = f

-- |
-- Si la conjunción tiene una contradiccion entonces lo es
tieneContra :: Formula t -> Bool
tieneContra ((V False) :| b) = True
tieneContra (a :& b) = tieneContra b
tieneContra (V False) = True
tieneContra _ = False

-- |
-- Elimina las contradicciones redundantes de una disyuncion
quitarContra ((V False) :| b) = quitarContra b
quitarContra (a :| (V False)) = a
quitarContra (a :| b)         = a :| (quitarContra b)
quitarContra f                = f

-- |
-- Elimina las tautologías de una fórmula conjuntiva
quitarTauto :: (Eq t) => Formula t -> Formula t
quitarTauto (a :& b) | esTauto a                   = quitarTauto b
                     | (quitarTauto b) == (V True) = a
                     | otherwise                   = a :& (quitarTauto b) 
quitarTauto a        | esTauto a = (V True) 
                     | otherwise = a

-- |
-- Comprueba si una disyunción es una tautología
esTauto :: (Eq t) => Formula t -> Bool
esTauto ((V True) :| b) = True 
esTauto ((N a) :| b) | buscarDis a b = True
                     | otherwise  = esTauto b
esTauto (a :| b) | buscarDis (N a) b = True
                 | otherwise         = esTauto b
esTauto (V True) = True
esTauto _        = False

