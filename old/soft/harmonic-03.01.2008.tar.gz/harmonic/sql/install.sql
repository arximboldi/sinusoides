
/*
  Proyecto Harmonic
  =================
  Autores:
	Juan Pedro Bolivar Puente
	Luca Mefistofeles Conesa Martin-Aragon

  Instalacion de las tablas de la base de datos.
*/


drop table hm_plays_on;
drop table hm_ticket_buy;
drop table hm_ticket;
drop table hm_concert;
drop table hm_club;
drop table hm_inbox;
drop table hm_receives;
drop table hm_comm_member;
drop table hm_comm_admin;
drop table hm_playlist;
drop table hm_rating;
drop table hm_listen;
drop table hm_tag;
drop table hm_author;
drop table hm_artist_admin;
drop table hm_song;
drop table hm_artist;
drop table hm_taggeable;
drop table hm_user_artist;
drop table hm_user;
drop table hm_community;
drop table hm_person;
drop table hm_message;

drop sequence hm_person_id_seq;
drop sequence hm_taggeable_id_seq;
drop sequence hm_song_id_seq;
drop sequence hm_artist_id_seq;
drop sequence hm_club_id_seq;
drop sequence hm_concert_id_seq;
drop sequence hm_message_id_seq;

/*
** ENTITIES
*/

create table hm_person
(
	id		int,
	create_date 	date,
	primary key (id)
);

create table hm_message
(
	id	   int,
	sender_id  int,
	content	   varchar2(2048),
	send_date  date,
	private	   char check (private in ('t', 'f')),
	primary key (id)
);

create table hm_user
(
	/* system data */
	id    	     int,
	nick	     varchar(32) unique not null,
       	pass_hash    varchar(32) not null,
       	email	     varchar(32) unique not null,
       	confirm_code varchar(32),
	/* profile data */
	real_name    varchar(128),
	sex	     char(1) check (sex in ('M','F')),
	description  varchar(512),
	birth_date   date,
	homepage_url varchar(256),
	avatar_url   varchar(256),
	foreign key (id) references hm_person(id) 
		    	 on delete cascade,
       	primary key (id)
);

create table hm_community
(
	id	     int,
	com_name     varchar(128) unique not null,
	description  varchar(2048),
	avatar_url   varchar(256),
	foreign key (id) references hm_person(id) 
		    	 on delete cascade,
	primary key (id)
);

create table hm_user_artist
(
	id	int,
	foreign key (id) references hm_user(id) 
		    	 on delete cascade,
	primary key(id)
);

create table hm_taggeable
(
	id	int,
	primary key(id)
);

create table hm_artist
(
	id	    int,
	art_name    varchar(48) not null,
	description varchar(2048),
	foreign key (id) references hm_taggeable(id)
		    	 on delete cascade,
	primary key (id)
);

create table hm_song
(
	id	 int,
	title	 varchar(1024) not null,
	album	 varchar(1024),
	exe_date date,
	down_url varchar(256),
	foreign key (id) references hm_taggeable(id)
		    	 on delete cascade,
	primary key (id)
);

create table hm_club
(
	id	  int,
	club_name varchar(128),
	address   varchar(512),
	town	  varchar(32),
	zip_code  varchar(6),
	region	  varchar(32),
	country	  varchar(32),
	phone	  varchar(16),
	fax	  varchar(16),
	room_size int,
	primary key (id)
);

create table hm_concert
(
	id	   int,
	title	   varchar(1024),
	con_date   date,
	max_ticket int,
	club_id    int,
	foreign key (club_id) references hm_club (id)
		    	      on delete cascade,
	primary key (id)
);

create table hm_ticket
(
	concert_id int,
	num 	   int,
	price 	   int, /* TODO!!! */
	foreign key (concert_id) references hm_concert(id)
		    		 on delete set null,
	primary key (concert_id, num)
);

/*
** RELATIONSHIPS
*/

create table hm_receives
(
	message_id  int,
	receiver_id int,
	foreign key (message_id) references hm_message (id)
		    		 on delete cascade,
	foreign key (receiver_id) references hm_person (id)
		    		  on delete cascade,
	primary key (message_id, receiver_id)
);

create table hm_inbox
(
	message_id int,
	person_id  int,
	foreign key (message_id) references hm_message (id)
		    		 on delete cascade,
	foreign key (person_id) references hm_person (id)
		    		on delete cascade,
	primary key (message_id, person_id)
);

create table hm_comm_member
(
	comm_id	    int,
	user_id	    int,
	member_date date,
	foreign key (comm_id) references hm_community (id)
		    	      on delete cascade,
	foreign key (user_id) references hm_user (id)
		    	      on delete cascade,
	primary key (comm_id, user_id)
);

create table hm_comm_admin
(
	comm_id	    int,
	user_id	    int,
	foreign key (comm_id) references hm_community (id)
		    	      on delete cascade,
	foreign key (user_id) references hm_user (id)
		    	      on delete cascade,
	primary key (comm_id, user_id)	
);

create table hm_playlist
(
	user_id	  int,
	song_id	  int,
	pos	  int,
	list_name varchar(32),
	foreign key (user_id) references hm_user (id)
		    	      on delete cascade,
	foreign key (song_id) references hm_song (id)
		    	      on delete cascade,
	primary key (user_id, song_id, pos, list_name)
);

create table hm_rating
(
	user_id	  int,
	song_id   int,
	rating    int check (rating between 0 and 5),
	foreign key (user_id) references hm_user (id)
		    	      on delete cascade,
	foreign key (song_id) references hm_song (id)
		    	      on delete cascade,
	primary key (user_id, song_id)			
);

create table hm_listen
(
	user_id	     int,
	song_id      int,
	listen_date  date,
	foreign key (user_id) references hm_user (id)
		    	      on delete cascade,
	foreign key (song_id) references hm_song (id)
		    	      on delete cascade,
	primary key (user_id, song_id, listen_date)
);

create table hm_tag
(
	user_id       int,
	taggeable_id  int,
	tag           varchar(16),
	foreign key (user_id) references hm_user (id)
		    	      on delete cascade,
	foreign key (taggeable_id) references hm_taggeable (id)
		    		   on delete cascade,
	primary key (user_id, taggeable_id, tag)
);

create table hm_author
(
	artist_id   int,
	song_id     int,
	foreign key (artist_id) references hm_artist (id)
		    		on delete cascade,
	foreign key (song_id) references hm_song (id)
		    	      on delete cascade,
	primary key (artist_id, song_id)
);

create table hm_artist_admin
(
	user_artist_id int,
	artist_id int,
	foreign key (user_artist_id) references hm_user_artist (id)
		    		     on delete cascade,
	foreign key (artist_id) references hm_artist (id)
		    		on delete cascade,
	primary key (user_artist_id, artist_id)
);

create table hm_plays_on
(
	artist_id  int,
	concert_id int,
	percentage int, /* TODO!!*/
	foreign key (artist_id) references hm_artist (id)
		    		on delete cascade,
	foreign key (concert_id) references hm_concert (id)
		    		 on delete cascade,
	primary key (artist_id, concert_id)
);

create table hm_ticket_buy
(
	concert_id   int,
	ticket_num   int,
	user_id      int,
	payment      char, /* TODO!! */
	foreign key (concert_id, ticket_num)
		    references hm_ticket (concert_id, num)
		    on delete cascade,
	foreign key (user_id) references hm_user (id)
		    on delete cascade,
	primary key (concert_id, ticket_num, user_id)
);

create sequence hm_person_id_seq
       start with 1000
       increment by 1;

create sequence hm_taggeable_id_seq
       start with 1000
       increment by 1;

create sequence hm_club_id_seq
       start with 1000
       increment by 1;

create sequence hm_concert_id_seq
       start with 1000
       increment by 1;

create sequence hm_song_id_seq
       start with 1000
       increment by 1;

create sequence hm_artist_id_seq
       start with 1000
       increment by 1;

create sequence hm_message_id_seq
       start with 1000
       increment by 1;
