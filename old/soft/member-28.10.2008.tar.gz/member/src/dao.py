#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

from singleton import Singleton

class PaymentDao:
    def clear (self, member_id):
        pass

    def add (self, payment):
        pass

    def list (self, member_id):
        pass

class MemberDao:
    def add (self):
        pass
    
    def find (self, id):
        pass
    
    def find_data (self, id):
        pass

    def update (self, member):
        pass

    def update_data (self, data):
        pass
    
    def delete (self, id):
        pass

    def list (self):
        pass

    def list_birthday (self):
        pass

class DaoFactory:
    def connect (self, host, db, user, passwd):
        pass

    def is_connected (self):
        pass
    
    def disconnect (self):
        pass
    
    def check_db (self):
        pass
    
    def install_db (self):
        pass

    def create_payment_dao (self):
        pass

    def create_member_dao (self):
        pass

class DaoFactoryMgr:
    __metaclass__ = Singleton

    def __init__ (self):
        self._fmap = {}
        self._default = None
        self._conn = None

    def register (self, name, fact):
        self._fmap [name] = fact
    
    def default (self, name):
        self._default = self._fmap [name]
    
    def connect (self, host, db, user, passwd, name = None):
        if name:
            return self._fmap [name].connect (host, db, user, passwd)
        return self._default.connect (host, db, user, passwd)
    
    def is_connected (self, name = None):
        if name:
            return self._fmap [name].is_connected ()
        return self._default.is_connected ()

    def disconnect (self, name = None):
        if name:
            self._fmap [name].disconnect ()
        self._default.disconnect ()

    def check_db (self, name = None):
        if name:
            return self._fmap [name].check_db ()
        return self._default.check_db ()

    def install_db (self, name = None):
        if name:
            return self._fmap [name].install_db ()
        return self._default.install_db ()

    def uninstall_db (self, name = None):
        if name:
            return self._fmap [name].uninstall_db ()
        return self._default.uninstall_db ()

    def create_payment_dao (self, name = None):
        if name:
            return self._fmap [name].create_payment_dao ()
        return self._default.create_payment_dao ()

    def create_member_dao (self, name = None):
        if name:
            return self._fmap [name].create_member_dao ()
        return self._default.create_member_dao ()
