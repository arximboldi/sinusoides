%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  File:       edge_roberts.m
%  Time-stamp: <2011-01-29 05:45:36 raskolnikov>
%  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
%
%  Función de de deteción de Roberts.
%

function [img, gradmag, imgx, imgy, imgnorm] = edge_roberts (img, threshold, dir)
    img = double (img);
    
    % Filtramos la imagen con la siguiente mascara
    mask  = [0 0 0 ; 0 1  0; 0 0 -1];
    maskt = [0 0 0 ; 0 0 -1; 0 1  0];
    imgx = imfilter (img, mask,  'conv', 'replicate');
    imgy = imfilter (img, maskt, 'conv', 'replicate');

    switch dir
      case 'both' %Ambos
        grad = sqrt (imgx.*imgx + imgy.*imgy);
      case 'vertical' %45º        
        grad = sqrt (imgy.*imgy);
      case 'horizontal' %135º
        grad = sqrt (imgx.*imgx);
    end
    gradmag = grad;
    
    % Seleccionamos sólo los pixeles que superan el umbral (si se ha
    % introducido si no devolveremos la imagen sin umbralizar)
    if ~isnan (threshold)
        grad = grad >= threshold * 256;
    end
    imgnorm = grad;
    img = grad .* 255;
