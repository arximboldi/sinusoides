/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package gui;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import game.Card;
import game.ExternalPokerPlayer;
import game.Player;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Spinner;

/**
 * Implementa un jugador de poker interactivo que puede controlarse gráficamente
 * a través de una interfaz visual.
 * 
 * @author raskolnikov
 * 
 */
public class InteractivePlayerView 
	extends PlayerView 
	implements ExternalPokerPlayer
{
	private static int NUM_CARDS = 5;
	
	/**
	 * Constructor.
	 * @param parent El compuesto sobre el que instalarse.
	 * @param player El jugador a visualizar y controlar.
	 */
	InteractivePlayerView (Composite parent, Player player)
	{
		super (parent, player);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void buildGui (Composite parent) 
	{
		buildBet (parent);
		buildCards (parent);
		disableBet ();
		disableCards ();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void hideCards () {}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void showCards () {}

	/**
	 * {@inheritDoc}
	 */	
	@Override
	public double chooseBet()
	{
		Display display = m_bet_group.getDisplay ();
		enableBet ();
		
		while (!m_bet_group.isDisposed () && !m_has_bet) {
	    	if (!display.readAndDispatch ())
	    		display.sleep ();	
	    }
		
		m_has_bet = false;
		if (!m_bet_group.isDisposed ())
			disableBet ();
		return m_current_bet;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Collection<Card> chooseDrop()
	{
		Display display = m_bet_group.getDisplay ();
		LinkedList<Card> l = new LinkedList<Card> ();
		
		do {
			enableCards ();
			while (!m_bet_group.isDisposed () && !m_has_drop) {
		    	if (!display.readAndDispatch ())
		    		display.sleep ();
		    }
	
			l.clear ();
			if (!m_bet_group.isDisposed ()) {
				int i = 0;
				for (Button b : m_cards_pic) {
					if (b.getSelection ())
						l.add (m_cards.get (i));
					++i;
				}
				disableCards ();
			}
			m_has_drop = false;
			
			if (l.size () >= NUM_CARDS)
				SwtUtils.errorMessage(m_bet_group.getShell (),
						"Can not drop more than " + (NUM_CARDS-1) + " cards!");
		} while (l.size () >= NUM_CARDS);
		
		return l;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean leave()
	{
		return false;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void handlePlayerDrop(Player p, Collection<Card> d)
	{
		m_cards.removeAll (d);
		updateCards  (true);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void handlePlayerDropAll(Player p, List<Card> c)
	{
		m_cards.removeAll(c);
		updateCards (true);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void handlePlayerTake(Player p, Card c)
	{
		m_cards.add (c);
		updateCards (true);
	}
	
	private void buildCards(Composite parent)
	{
		m_cards_group = new Group (parent, SWT.NONE);
		m_cards_group.setLayout (new GridLayout (NUM_CARDS, false));
		
		for (int i = 0; i < NUM_CARDS; ++i) {
			Button but = new Button (m_cards_group, SWT.TOGGLE);
			m_cards_pic.add (but);
		}
		
		m_drop_but = new Button (parent, SWT.PUSH);
		m_drop_but.setText ("Drop cards");
		m_drop_but.setLayoutData (new GridData (SWT.CENTER));
		
		updateCards (true);
		
		m_drop_but.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				m_has_drop = true;
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);	
	}

	private void buildBet (Composite parent)
	{
		m_bet_group = new Group (parent, SWT.NONE);
		m_bet_group.setLayout (new GridLayout (3, false));
		
		m_bet_spin = new Spinner (m_bet_group, SWT.NONE);
		m_bet_spin.setDigits (0);
		m_bet_spin.setPageIncrement (20);
		m_bet_spin.setIncrement (1);
		
		m_bet_but = new Button (m_bet_group, SWT.PUSH);
		m_bet_but.setText ("Bet");
		
		m_fold_but = new Button (m_bet_group, SWT.PUSH);
		m_fold_but.setText ("Fold");
		
		m_bet_but.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				m_has_bet = true;
	    				m_current_bet = m_bet_spin.getSelection ();
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
		m_fold_but.addSelectionListener(
	    		new SelectionListener () {
	    			public void widgetSelected (SelectionEvent e)
	    			{
	    				m_has_bet = true;
	    				m_current_bet = 0;
	    			}
					public void widgetDefaultSelected (SelectionEvent e) {}
	    		}
	    		);
	}

	private void enableBet ()
	{
		int min_bet = (int) getPlayer ().getGame ().getMinBet ();
		
		SwtUtils.setEnabledRecursive(m_bet_group, true);
		if (min_bet > 0)
			m_fold_but.setEnabled (true);
		else
			m_fold_but.setEnabled (false);
	
		m_bet_spin.setMinimum (min_bet);
		m_bet_spin.setMaximum ((int) getPlayer ().getSavings ());
		m_bet_spin.setSelection (min_bet);
	}
	
	private void disableBet ()
	{
		SwtUtils.setEnabledRecursive(m_bet_group, false);
	}

	private void enableCards ()
	{
		SwtUtils.setEnabledRecursive (m_cards_group, true);
		for (Button b : m_cards_pic) {
			b.setSelection (false);
		}
		m_drop_but.setEnabled (true);
	}
	
	private void disableCards ()
	{
		m_drop_but.setEnabled (false);
		SwtUtils.setEnabledRecursive (m_cards_group, false);
	}
	
	private void updateCards (boolean show)
	{
		int i = 0;
		for (Button l : m_cards_pic) {
			if (i >= m_cards.size ())
				l.setImage (ImageFactory.getVoid ());
			else if (show)
				l.setImage (ImageFactory.getCard (m_cards.get(i)));
			else
				l.setImage (ImageFactory.getBackside ());
			++i;
		}
	}

	private Group m_bet_group;
	private Group m_cards_group;
	
	private Spinner m_bet_spin;
	private Button m_bet_but;
	private Button m_drop_but;
	private Button m_fold_but;
	
	private LinkedList<Button> m_cards_pic = new LinkedList<Button> ();
	private Vector<Card> m_cards = new Vector<Card> (NUM_CARDS);

	private double  m_current_bet = 0;
	private boolean m_has_drop = false;
	private boolean m_has_bet = false;
}
