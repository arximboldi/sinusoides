/*
 *  Copyright (C) 2008, 2009 Juan Pedro Bolívar Puente
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package game;

import java.util.Collection;

/**
 * Base de todo jugador de juegos de cartas.
 * @author raskolnikov
 */
public abstract class Player extends PlayerSubject
{
	/**
	 * Construye el jugador.
	 * @param name Nombre del jugador.
	 * @param savings Ganancias del jugador.
	 */
	Player (String name, double savings)
	{
		m_name = name;
		m_savings = savings;
	}
	
	/**
	 * Accede al nombre del jugador.
	 * @return El nomnbre del jugador.
	 */
	public String getName ()
	{
		return m_name;
	}
	
	/**
	 * Accede a las ganancias actuales del jugador.
	 * @return Las ganancias del jugador.
	 */
	public double getSavings () 
	{
		return m_savings;
	}
	
	/**
	 * Añade o quita ganancias al jugador.
	 * @param diff Cuanto añadir o quitar (si es negativo) al jugador.
	 */
	public void addSavings (double diff)
	{
		if (diff < 0)
			diff = Math.max (diff, -m_savings);
		m_savings += diff;
		if (m_savings < 0)
			m_savings = 0;
		notifyUpdateSavings (this, diff);
	}
	
	/**
	 * Accede al juego al que pertenece el jugador.
	 * @return Devuelve la partida que el jugador está jungando.
	 */
	public Game getGame ()
	{
		return m_game;
	}
	
	/**
	 * Establece la partida que el jugador está jugando. Normalmente la partida
	 * debe ser establecida por el juego.
	 * 
	 * @param g El juego al que pertenece el jugador.
	 */
	public void setGame (Game g)
	{
		m_game = g;
	}
	
	/**
	 * Devuelve si el jugador debe o no abandonar la partida.
	 * 
	 * @return true si el jugador debe abandonar la partida en el putno actual y
	 *         false en caso contrario.
	 */
	public abstract boolean leave ();
	
	/**
	 * El jugador realiza una apuesta. Debe actualizar también sus ganancias.
	 * @return La cantidad apostada.
	 */
	public abstract double bet ();
	
	/**
	 * Obliga a l jugador a realizar una apuesta de una cantidad fijada. Si el
	 * jugador no tiene suficiente dinero debe apostar todo el dinero que tenga.
	 * 
	 * @param bet La apuesta que tiene que realizar el jugador.
	 * @return La cantidad apostada por el jugador.
	 */
	public abstract double forceBet (double bet);
	
	/**
	 * El jugador recibe una carta.
	 * @param c La carta recibida.
	 */
	public abstract void take (Card c);
	
	/**
	 * El jugador devuelve ciertas cartas a su elección, eliminándolas de su
	 * mano.
	 * 
	 * @return Las cartas devueltas.
	 */
	public abstract Collection<Card> drop ();
	
	/**
	 * El jugador devuelve forzosamente todas las cartas que tiene.
	 * 
	 * @return Las cartas devueltas.
	 */
	public abstract Collection<Card> dropAll ();
	
	/**
	 * Calcula la puntuación del jugador.
	 * @return El valor computado.
	 */
	public abstract double points ();

	/** El nombre del jugador */
	private String m_name;
	/** Sus ganancias */
	private double m_savings;
	/** El juego al que pertenece */
	private Game   m_game;
}
