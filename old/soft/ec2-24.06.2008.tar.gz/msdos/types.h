
#ifndef TYPES_H
#define TYPES_H

typedef unsigned char Sample;

#endif /* TYPES_H */
