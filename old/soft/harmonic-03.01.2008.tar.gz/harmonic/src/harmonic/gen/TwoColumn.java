/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic.gen;

import org.w3c.dom.*;
import java.util.*;

public class TwoColumn implements Generator
{
    List<Generator> m_left = new LinkedList<Generator>();
    List<Generator> m_right = new LinkedList<Generator>();

    String m_left_id = "form_left_col";
    String m_right_id = "form_right_col";

    public TwoColumn() {}
    
    public TwoColumn(String left_id, String right_id) {
	m_left_id = left_id;
	m_right_id = right_id;
    }
    
    public void addLeft(Generator gen) {
	m_left.add(gen);
    }

    public void addRight(Generator gen) {
	m_right.add(gen);
    }
    
    public Node generate(Document doc)
    {
	Iterator<Generator> lit = m_left.iterator();
	Iterator<Generator> rit = m_right.iterator();

	Element root_el = doc.createElement("div");
	Element left_el, right_el, break_el;
	while(lit.hasNext() || rit.hasNext()) {
	    left_el = doc.createElement("div");
	    left_el.setAttribute("id", m_left_id);
	    root_el.appendChild(left_el);

	    right_el = doc.createElement("div");
	    right_el.setAttribute("id", m_right_id);
	    root_el.appendChild(right_el);

	    break_el = doc.createElement("div");
	    break_el.setAttribute("id", "col_br");
	    root_el.appendChild(break_el);
	    
	    if (lit.hasNext()) {
		Generator gen = lit.next();
		if (gen != null)
		    left_el.appendChild(gen.generate(doc));
	    }

	    if (rit.hasNext()) {
		Generator gen = rit.next();
		if (gen != null)
		    right_el.appendChild(gen.generate(doc));
	    }
	}

	return root_el;
    }
}
