--
--  File:       Astar.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Mon Mar 30 13:09:48 2009
--  Time-stamp: <2009-05-30 18:02:34 raskolnikov>
--
--  Implementación del algoritmo A*, utilizando como base la vista en:
-- http://www.haskell.org/haskellwiki/Haskell_Quiz/Astar/Solution_Dolio
--

module Nexus.AStar (aStar, aStar') where

import Nexus.Debug

import Data.List (findIndex)
import qualified Data.Set as S
import qualified Data.Map as M
import Maybe

import Control.Monad
import qualified Nexus.PriorityQueue as Q
import qualified Data.Graph.AStar as Old

--
-- Old Astar
--
aStar' :: (Show a, Show c, Ord a, Ord c, Num c) => 
          (a -> [a])      -- adjacencies in graph
       -> (a -> a -> c)   -- distance function
       -> (a -> c)        -- heuristic distance to goal
       -> (a -> Bool)     -- goal
       -> a               -- starting vertex
       -> Maybe [a]       -- final state
aStar' graph dist heur goal start = 
    case Old.aStar (S.fromList.graph) dist heur goal start of
      Just r -> Just (start : r)
      _      -> Nothing

--
-- Wrapper para que este aStar funcione como el de la librería
--
aStar :: (Show a, Show c, Ord a, Ord c, Num c) => 
         (a -> [a])   -- adjacencies in graph
      -> (a -> a -> c)    -- distance function
      -> (a -> c)         -- heuristic distance to goal
      -> (a -> Bool)      -- goal
      -> a                -- starting vertex
      -> Maybe [a]        -- final state
aStar graph dist heur goal start = 
    liftM reverse $ aStarImpl start graph goal dist heur

aStarImpl :: (Show a, Show c, Ord a, Ord c, Num c) => 
         a 
      -> (a -> [a])      -- graph
      -> (a -> Bool) 
      -> (a -> a -> c) 
      -> (a -> c) 
      -> Maybe [a]
aStarImpl start succ end cost heur 
    = astar' (S.singleton start) (Q.singleton (heur start) [start])
    where
      astar' seen q
          | Q.null q  = Nothing
          | end n     = Just next
          | otherwise = astar' seen' q'
          where
            ((c,next), dq) = Q.deleteFindMin q
            n       = head next
            succs   = filter (`S.notMember` seen) $ succ n
            costs   = map costF succs
            costF x = c + cost n x + heur x - heur n
            q'      = dq `Q.union` Q.fromList (zip costs (map (:next) succs))
            seen'   = seen `S.union` S.fromList succs

