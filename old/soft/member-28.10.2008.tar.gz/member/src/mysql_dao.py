#
# Copyright (c) 2008 by Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#
# This file is part of MemberManager.
#
# MemberManager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Django-graph is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MemberManager.  If not, see <http://www.gnu.org/licenses/>.
#

from dao import *
from member import *
import MySQLdb
import datetime

MYSQL_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'

class MysqlPaymentDao (PaymentDao):
    def __init__ (self, conn):
        self._conn = conn

    def clear (self, member_id):
        cur = self._conn.cursor ()
        cur.execute ('delete from mm_payment where member_id = %s', [member_id])

    def add (self, payment):
        cur = self._conn.cursor ()
        cur.execute ('insert into mm_payment (member_id, pay_date, amount, notes) values (%s, %s, %s, %s)',
                     [payment.id, payment.date, payment.amount, payment.notes])

    def list (self, member_id):
        cur = self._conn.cursor (MySQLdb.cursors.DictCursor)
        cur.execute ('select member_id, pay_date, amount, notes from mm_payment where member_id=%s',
                     [member_id])
        li = []
        rows = cur.fetchall ()
        for row in rows:
            pay = Payment ()
            pay.id = row ["member_id"]
            pay.date = row ["pay_date"]
            pay.amount = row ["amount"]
            pay.notes = row ["notes"]
            li.append (pay)
        return li

class MysqlMemberDao (MemberDao):
    def __init__ (self, conn):
        self._conn = conn
    
    def add (self):
        cur = self._conn.cursor ()
        cur.execute ('insert into mm_member (id) values (null)')
        cur.execute ('select LAST_INSERT_ID()')
        mem = Member ()
        mem.id = cur.fetchone ()[0]
        return mem

    def find (self, id):
        cur = self._conn.cursor (MySQLdb.cursors.DictCursor)
        cur.execute ('select id, comname, surname, nif, up_date, down_date, birth_date from mm_member where id=%s', [id])
        row = cur.fetchone ()
        mem = Member ()
        mem.id = row["id"]
        mem.name = row["comname"]
        mem.surname = row["surname"]
        mem.nif = row["nif"]
        mem.up_date = row["up_date"]
        mem.down_date = row["down_date"]
        mem.birth_date = row["birth_date"]
        return mem
    
    def find_data (self, id):
        dat = MemberData ()
        cur = self._conn.cursor (MySQLdb.cursors.DictCursor)
        cur.execute ('select address, zip, city, province, phone, mobile, email, web, bank, notes, picture from mm_member where id=%s', [id])
        row = cur.fetchone ()
        dat.address = row["address"]
        dat.zip = row["zip"]
        dat.city = row["city"]
        dat.province = row["province"]
        dat.phone = row["phone"]
        dat.mobile = row["mobile"]
        dat.email = row["email"]
        dat.web = row["web"]
        dat.bank = row["bank"]
        dat.notes = row["notes"]
        dat.picture = row["picture"]
        return dat

    def update (self, mem):
        cur = self._conn.cursor ()
        cur.execute ('update mm_member set nif=%s, comname=%s, surname=%s, up_date=%s, down_date=%s, birth_date=%s where id=%s',
                     [mem.nif, mem.name, mem.surname, mem.up_date, mem.down_date, mem.birth_date, mem.id])
    
    def update_data (self, dat):
        cur = self._conn.cursor ()
        cur.execute ('update mm_member set address=%s, zip=%s, city=%s, province=%s, phone=%s, mobile=%s, email=%s, web=%s, bank=%s, notes=%s, picture=%s where id=%s',
                     [dat.address, dat.zip, dat.city, dat.province, dat.phone, dat.mobile, dat.email, dat.web, dat.bank, dat.notes, dat.picture, dat.id])
        
    def delete (self, id):
        cur = self._conn.cursor ()
        cur.execute ('delete from mm_member where id=%s', [id])
        
    def list (self):
        cur = self._conn.cursor (MySQLdb.cursors.DictCursor)
        cur.execute ('select id, comname, surname, nif, up_date, down_date, birth_date from mm_member')
        li = []
        rows = cur.fetchall ()
        for row in rows:
            mem = Member ()
            mem.id = row["id"]
            mem.name = row["comname"]
            mem.surname = row["surname"]
            mem.nif = row["nif"]
            mem.up_date = row["up_date"]
            mem.down_date = row["down_date"]
            mem.birth_date = row["birth_date"]
            li.append (mem)
        return li

    def list_birthday (self):
        cur = self._conn.cursor (MySQLdb.cursors.DictCursor)
        cur.execute ('select id, comname, surname, nif, up_date, down_date, birth_date from mm_member where day(birth_date) = day(sysdate()) and month(birth_date) = month(sysdate())')
        li = []
        rows = cur.fetchall ()
        for row in rows:
            mem = Member ()
            mem.id = row["id"]
            mem.name = row["comname"]
            mem.surname = row["surname"]
            mem.nif = row["nif"]
            mem.up_date = row["up_date"]
            mem.down_date = row["down_date"]
            mem.birth_date = row["birth_date"]
            li.append (mem)
        return li
    
class MysqlDaoFactory (DaoFactory):
    def __init__ (self):
        self._conn = None

    def connect (self, host, db, user, passwd):
        if (self._conn):
            self._conn.close ()
        self._conn = MySQLdb.connect (host, user, passwd, db)
    
    def is_connected (self):
        if (self._conn):
            return True
        return False

    def disconnect (self):
        if (self._conn):
            self._conn.close ()
        self._conn = None
    
    def check_db (self):
        try:
            cursor = self._conn.cursor ()
            cursor.execute ("select * from mm_control")
        except MySQLdb.Error, e:
            return False
        return True

    def execute_file (self, filename):
        source = open (filename)
        content = source.read ().split ('*/')
        content = content [1].split (';')
        for command in content:
            command = command.strip('\n\t\f\r\v ')
            if command != "":
                cursor = self._conn.cursor ()
                cursor.execute (command)
    
    def install_db (self):
        self.execute_file ('sql/install.sql')

    def uninstall_db (self):
        self.execute_file ('sql/uninstall.sql')

    def create_member_dao (self):
        return MysqlMemberDao (self._conn)

    def create_payment_dao (self):
        return MysqlPaymentDao (self._conn)
