%
%  Modelos de la Inteligencia Artificial
%  =====================================
%
%  (c) 2010-2011 Juan Pedro Bolívar Puente
%
%  Time-stamp: <2011-01-24 02:15:43 raskolnikov>
%  Autor:      Juan Pedro Bolívar Puente
%  File:       image_diff.m
%
%

function res = image_diff (imga, imgb)
    if size (imga) ~= size (imgb)
        errordlg ('Both images must be of the same size', 'Bad input', 'modal')
        res = [];
    else
        res = bound_gray (double (imga) - double (imgb));
    end    
end
