--
--  File:       State.hs
--  Author:     Juan Pedro Bolívar Puente <raskolnikov@es.gnu.org>
--  Date:       Thu May  7 18:24:08 2009
--  Time-stamp: <2009-06-24 00:24:36 raskolnikov>
--
--  Estado que almacena el Bot  
--

module Nexus.State where

import Mech.Info
import Mech.Action

data NexusState = NexusState { usedLocations :: [Location]
                             , lastMovement :: Movement
                             , killNeed :: Double
                             , funcBase :: Double
                             , lastP :: [Int]}
                  deriving (Show, Read)

initialState = NexusState [] None 1.0 0.0 []


