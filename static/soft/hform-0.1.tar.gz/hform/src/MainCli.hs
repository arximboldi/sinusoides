--------------------------------------------------------------------------------
--
-- Fichero:    MainCli.hs
-- Autor:      Juan Pedro Bolivar Puente
-- Time-stamp: <2009-02-02 19:57:40 raskolnikov>
--
--------------------------------------------------------------------------------

-- |
-- Modulo principal
module MainCli where

import Prelude          hiding (putStrLn, putStr, readLn, getLine)
import System.IO        hiding (putStrLn, putStr, readLn, getLine)
import System.IO.UTF8   -- Permite meter cadenas UTF 8

import Formula
import FormulaParser

-- |
-- Muestra la información general del programa, indicable para visualizar
-- al principio de la ejecución del prompt.
--
info :: IO ()
info = do putStrLn "hform 0.1"
          putStrLn "(c) Juan Pedro Bolívar Puente 2008"
          putStrLn ""

-- |
-- Muestra la información sobre la sintáxis del programa
--
sintaxis :: IO ()
sintaxis = do putStrLn "- Operadores válidos: ~, |, &, ->, <-> en ese orden de precedencia"
              putStrLn "- Identifique las variables con números."
              putStrLn "- Puede parentizar las expresiones."
              putStrLn "- Puede usar T y F para notar subfórmulas tautológicas o contradictorias"

-- |
-- Muestra el prompt y lee y procesa una entrada
prompt :: IO ()
prompt = do putStrLn ""
            putStr "> "
            hFlush stdout
            s <- getLine
            f <- parseIO s (formulaParser numberParser) :: IO (Formula Integer)
            putStrLn (show f)
            putStrLn "Se simplifica en:"
            putStrLn (show (fnc f))
        `catch` excepcion
    where excepcion e = do putStrLn "Fórmula mal formada."

-- |
-- Ejecuta el prompt en bucle
--
bucle :: IO ()
bucle = do prompt 
           bucle

-- |
-- Programa principal
--
main :: IO ()
main = do info
          sintaxis
          bucle 
