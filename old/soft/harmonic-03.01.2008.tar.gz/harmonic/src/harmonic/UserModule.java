/*
    HARMONIC - Online music communities system
    ========
    
    Copyright (C) 2008  Juan Pedro Bolivar Puente,
                        Luca Mefistofeles Conesa Martin-Aragon

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package harmonic;

import harmonic.gen.*;

public class UserModule extends Module
{
    QueryHandler m_hdl = null;
    
    UserModule(QueryHandler hdl)
    {
	m_hdl = hdl;
    }

    public void buildUserModule(Division div, String usr_id)
    {
	
	div.addContent(new Text("Welcome "));
	div.addContent(new Link("user?nick=" + usr_id, usr_id));
	div.addContent(new Break());
	ItemList lst = new ItemList();
	div.addContent(lst);
	lst.addItem(new Link("user?action=edit_user&nick=" +  usr_id, "Edit user"));
	lst.addItem(new Link("user?action=edit_password&nick=" +  usr_id, "Change password"));
	lst.addItem(new Link("user?action=delete&nick=" +  usr_id, "Delete acount"));

	Form form = new Form("login");
	div.addContent(form);
	form.addContent(new Input("submit", "action", "logout"));
	String query = m_hdl.extractQuery();
	form.addContent(new Input("hidden", "target", query.substring(1, query.length())));
    }

    public void buildLoginModule(Division div)
    {
	Form form = new Form("login");
	div.addContent(form);

	form.addContent(new Text("User: "));
	form.addContent(new Input("user", "user_id", "", 14));
	form.addContent(new Break());
	form.addContent(new Text("Pass: "));
	form.addContent(new Input("password", "user_pass", "", 14));
	form.addContent(new Break());
	form.addContent(new Input("submit", "action", "login"));

	String query = m_hdl.extractQuery();
	form.addContent(new Input("hidden", "target", query.substring(1, query.length())));
	
	div.addContent(new Link("register", "Create new user"));
    }
    
    public void build(Division div)
    {
	div.addContent(new Header(2, "User"));
	
	UserSession session = m_hdl.getUserSession();
	String usr_id = session.getID();

	if (usr_id != null)
	    buildUserModule(div, usr_id);
	else
	    buildLoginModule(div);
    }
}
